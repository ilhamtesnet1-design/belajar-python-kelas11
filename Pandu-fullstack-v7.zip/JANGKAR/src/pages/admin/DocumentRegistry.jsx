import React from 'react';
import { Link } from 'react-router-dom';
import { FilePlus, Search, Filter, Eye, Edit, Trash2 } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import './Admin.css';

export const DocumentRegistry = () => {
  return (
    <div className="admin-page">
      <div className="admin-header">
        <div>
          <h2>Dokumen Resmi</h2>
          <p className="admin-subtitle">Kelola basis data dokumen untuk RAG Pandu.</p>
        </div>
        <Link to="/admin/documents/add">
          <Button variant="primary" icon={<FilePlus size={16} />}>Tambah Dokumen</Button>
        </Link>
      </div>

      <Card padding="md">
        <div className="section-title-row">
          <div className="flex gap-4 w-full" style={{ maxWidth: '600px' }}>
            <Input icon={<Search size={16} />} placeholder="Cari dokumen..." className="flex-1" />
            <Button variant="outline" icon={<Filter size={16} />}>Filter</Button>
          </div>
        </div>
        
        <div className="table-card mt-4">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Nama Dokumen</th>
                <th>Kategori</th>
                <th>Versi/Tahun</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <strong>Panduan Akademik Fakultas Teknik</strong>
                  <br />
                  <span className="text-muted" style={{ fontSize: '12px' }}>Diunggah: 12 Jan 2026</span>
                </td>
                <td>Panduan</td>
                <td>2026</td>
                <td><Badge variant="success">Berlaku</Badge></td>
                <td>
                  <div className="flex gap-2">
                    <Link to="/admin/documents/1"><Button variant="ghost" size="sm" icon={<Eye size={16} />} /></Link>
                    <Button variant="ghost" size="sm" icon={<Edit size={16} />} />
                    <Button variant="ghost" size="sm" icon={<Trash2 size={16} />} className="text-warning" />
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Peraturan Akademik UNP No. 4</strong>
                  <br />
                  <span className="text-muted" style={{ fontSize: '12px' }}>Diunggah: 05 Jan 2026</span>
                </td>
                <td>Peraturan</td>
                <td>2024</td>
                <td><Badge variant="success">Berlaku</Badge></td>
                <td>
                  <div className="flex gap-2">
                    <Link to="/admin/documents/2"><Button variant="ghost" size="sm" icon={<Eye size={16} />} /></Link>
                    <Button variant="ghost" size="sm" icon={<Edit size={16} />} />
                    <Button variant="ghost" size="sm" icon={<Trash2 size={16} />} className="text-warning" />
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Panduan Tugas Akhir FMIPA</strong>
                  <br />
                  <span className="text-muted" style={{ fontSize: '12px' }}>Diunggah: 10 Des 2025</span>
                </td>
                <td>Panduan</td>
                <td>2025</td>
                <td><Badge variant="default">Tidak Berlaku</Badge></td>
                <td>
                  <div className="flex gap-2">
                    <Link to="/admin/documents/3"><Button variant="ghost" size="sm" icon={<Eye size={16} />} /></Link>
                    <Button variant="ghost" size="sm" icon={<Edit size={16} />} />
                    <Button variant="ghost" size="sm" icon={<Trash2 size={16} />} className="text-warning" />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
