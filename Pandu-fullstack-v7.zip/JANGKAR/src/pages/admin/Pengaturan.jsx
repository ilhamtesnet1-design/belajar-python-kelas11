import React, { useEffect, useState } from 'react';
import { User, Shield, AppWindow, Save, AlertCircle, CheckCircle2 } from 'lucide-react';
import { api, auth } from '../../api/client';
import { formatBytes, UPLOAD_LIMITS } from '../../config/uploads';
import '../../components/layout/AdminTable.css';
import './Pengaturan.css';

const TABS = [
  { id: 'profil', label: 'Profil Admin', icon: User },
  { id: 'akun', label: 'Keamanan Akun', icon: Shield },
  { id: 'sistem', label: 'Konfigurasi Sistem', icon: AppWindow },
];

const Notice = ({ notice }) => (notice ? (
  <div className={`admin-banner ${notice.tone}`} role="status">
    {notice.tone === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
    <span>{notice.text}</span>
  </div>
) : null);

const Pengaturan = () => {
  const [activeTab, setActiveTab] = useState('profil');
  const [me, setMe] = useState(auth.user);
  const [name, setName] = useState(auth.user?.name || '');
  const [profileNotice, setProfileNotice] = useState(null);
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [pwNotice, setPwNotice] = useState(null);
  const [system, setSystem] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api('/api/auth/me').then(u => { setMe(u); setName(u.name); }).catch(() => {});
  }, []);

  useEffect(() => {
    if (activeTab === 'sistem' && !system) {
      api('/api/dashboard/system').then(setSystem).catch(() => setSystem({ error: true }));
    }
  }, [activeTab, system]);

  const saveProfile = async (e) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setProfileNotice(null);
    try {
      const u = await api('/api/auth/me', { method: 'PATCH', body: { name: name.trim() } });
      setMe(u);
      auth.set(auth.token, u); /* keep the sidebar and header in step */
      setProfileNotice({ tone: 'success', text: 'Profil tersimpan.' });
    } catch (err) {
      setProfileNotice({ tone: 'error', text: err.message });
    } finally {
      setSaving(false);
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    if (saving) return;
    if (pw.next.length < 8) { setPwNotice({ tone: 'error', text: 'Kata sandi baru minimal 8 karakter.' }); return; }
    if (pw.next !== pw.confirm) { setPwNotice({ tone: 'error', text: 'Konfirmasi kata sandi tidak sama.' }); return; }
    setSaving(true);
    setPwNotice(null);
    try {
      await api('/api/auth/password', { method: 'POST', body: { current_password: pw.current, new_password: pw.next } });
      setPw({ current: '', next: '', confirm: '' });
      setPwNotice({ tone: 'success', text: 'Kata sandi diganti. Gunakan kata sandi baru saat login berikutnya.' });
    } catch (err) {
      setPwNotice({ tone: 'error', text: err.message });
    } finally {
      setSaving(false);
    }
  };

  const setPwField = k => e => setPw({ ...pw, [k]: e.target.value });
  const initials = (me?.name || 'Admin').split(' ').slice(0, 2).map(p => p[0]).join('').toUpperCase();

  const rows = system && !system.error ? [
    ['Model bahasa', system.llm_provider === 'fake' ? 'Mode offline (fake) — untuk uji, bukan jawaban model' : `${system.llm_provider} · ${system.llm_model}`],
    ['Model embedding', system.embedding_provider === 'fake' ? 'Mode offline (fake)' : `${system.embedding_provider} · ${system.embedding_model}`],
    ['Basis data', system.database],
    ['Potongan diambil (top-k)', system.top_k],
    ['Ambang kemiripan', system.similarity_threshold],
    ['Ambang grounding', system.grounding_threshold],
    ['Ukuran potongan teks', `${system.chunk_size} karakter, tumpang tindih ${system.chunk_overlap}`],
    ['Batas pertanyaan', `${system.chat_rate_per_minute}/menit per pengguna${system.daily_question_limit ? ` · ${system.daily_question_limit}/hari total` : ''}`],
    ['Batas unggah PDF', formatBytes(UPLOAD_LIMITS.document.maxBytes)],
    ['Batas unggah ZIP', `${formatBytes(UPLOAD_LIMITS.archive.maxBytes)}, maks. ${UPLOAD_LIMITS.archive.maxEntries} dokumen`],
  ] : [];

  return (
    <div className="admin-page-container">
      <div className="admin-page-header">
        <h2>Pengaturan</h2>
        <p className="subtitle">Kelola profil admin, kata sandi, dan lihat konfigurasi sistem Pandu.</p>
      </div>

      <div className="settings-layout">
        <div className="settings-nav" role="tablist">
          {TABS.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={activeTab === t.id}
                className={`settings-nav-item ${activeTab === t.id ? 'active' : ''}`}
                onClick={() => setActiveTab(t.id)}
              >
                <Icon size={18} /> {t.label}
              </button>
            );
          })}
        </div>

        <div className="settings-content">
          {activeTab === 'profil' && (
            <form className="settings-content-card fadeIn" onSubmit={saveProfile}>
              <div className="settings-card-header">
                <h3>Informasi Profil</h3>
                <p>Nama ini tampil di panel admin.</p>
              </div>
              <div className="settings-card-body">
                <Notice notice={profileNotice} />
                <div className="profile-avatar-upload">
                  <div className="avatar-preview">{initials}</div>
                </div>
                <div className="form-group">
                  <label htmlFor="set-name">Nama Lengkap</label>
                  <input id="set-name" type="text" className="form-input" value={name} onChange={e => setName(e.target.value)} minLength={2} required />
                </div>
                <div className="form-group">
                  <label htmlFor="set-email">Email Login</label>
                  <input id="set-email" type="email" className="form-input" value={me?.email || ''} readOnly />
                  <span className="settings-hint">Email adalah identitas login; diubah lewat ADMIN_EMAIL di .env backend.</span>
                </div>
              </div>
              <div className="settings-footer">
                <button type="submit" className="admin-btn-primary" disabled={saving || name.trim().length < 2}>
                  <Save size={16} /> {saving ? 'Menyimpan…' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          )}

          {activeTab === 'akun' && (
            <form className="settings-content-card fadeIn" onSubmit={savePassword}>
              <div className="settings-card-header">
                <h3>Ganti Kata Sandi</h3>
                <p>Ganti kata sandi bawaan sebelum sistem dipakai di luar pengembangan.</p>
              </div>
              <div className="settings-card-body">
                <Notice notice={pwNotice} />
                <div className="form-group">
                  <label htmlFor="pw-current">Kata sandi saat ini</label>
                  <input id="pw-current" type="password" className="form-input" autoComplete="current-password" value={pw.current} onChange={setPwField('current')} required />
                </div>
                <div className="form-group">
                  <label htmlFor="pw-new">Kata sandi baru</label>
                  <input id="pw-new" type="password" className="form-input" autoComplete="new-password" value={pw.next} onChange={setPwField('next')} minLength={8} required />
                  <span className="settings-hint">Minimal 8 karakter.</span>
                </div>
                <div className="form-group">
                  <label htmlFor="pw-confirm">Ulangi kata sandi baru</label>
                  <input id="pw-confirm" type="password" className="form-input" autoComplete="new-password" value={pw.confirm} onChange={setPwField('confirm')} required />
                </div>
              </div>
              <div className="settings-footer">
                <button type="submit" className="admin-btn-primary" disabled={saving}>
                  <Shield size={16} /> {saving ? 'Menyimpan…' : 'Ganti Kata Sandi'}
                </button>
              </div>
            </form>
          )}

          {activeTab === 'sistem' && (
            <div className="settings-content-card fadeIn">
              <div className="settings-card-header">
                <h3>Konfigurasi Sistem</h3>
                <p>Hanya baca. Nilai diatur lewat berkas .env backend, lalu server dijalankan ulang.</p>
              </div>
              <div className="settings-card-body">
                {!system && <p className="settings-hint">Memuat konfigurasi…</p>}
                {system?.error && <Notice notice={{ tone: 'error', text: 'Konfigurasi tidak bisa dimuat dari server.' }} />}
                {rows.length > 0 && (
                  <dl className="settings-config">
                    {rows.map(([label, value]) => (
                      <div key={label}>
                        <dt>{label}</dt>
                        <dd className="tabular">{value}</dd>
                      </div>
                    ))}
                  </dl>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Pengaturan;
