import React, { useState, useEffect, useRef } from 'react';
import { Search, Filter, Upload, Edit2, Archive, Eye, ShieldAlert, X, FileText, Info, AlertCircle, FileSearch, FileArchive, CheckCircle2 } from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './Registri.css';
import { api, auth, mapDocument } from '../../api/client';
import { UPLOAD_LIMITS, limitHint, validateFile, formatBytes, kindForFile } from '../../config/uploads';

const Registri = () => {
  const [modalType, setModalType] = useState(null); // 'tambah' | 'detail' | null
  const [selectedDoc, setSelectedDoc] = useState(null);

  // ---- Data dari backend (menggantikan mockDocuments) ----
  const [mockDocuments, setDocs] = useState([]);
  const [q, setQ] = useState('');
  const [preview, setPreview] = useState([]);
  const [saving, setSaving] = useState(false);
  const emptyForm = { name: '', category: 'Pedoman', doc_number: '', version: '', year: '', status: 'Menunggu Validasi', valid_from: '', valid_until: '' };
  const [form, setForm] = useState(emptyForm);
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState('');
  const [dragging, setDragging] = useState(false);
  const [statusFilter, setStatusFilter] = useState('Semua');
  const [loading, setLoading] = useState(true);
  const fileRef = useRef(null);

  const [batchResult, setBatchResult] = useState(null);
  const [notice, setNotice] = useState(null);
  const [formError, setFormError] = useState('');
  const isArchive = file ? kindForFile(file) === 'archive' : false;

  const chooseFile = (candidate) => {
    if (!candidate) return;
    const result = validateFile(candidate, kindForFile(candidate));
    if (!result.ok) {
      setFile(null);
      setFileError(result.message);
      return;
    }
    setFile(candidate);
    setFileError('');
  };
  const setField = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const load = () => {
    setLoading(true);
    return api(`/api/documents${q ? `?q=${encodeURIComponent(q)}` : ''}`)
      .then(rows => setDocs(rows.map(mapDocument)))
      .catch(e => console.error('Gagal memuat registri:', e.message))
      .finally(() => setLoading(false));
  };
  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [q]);

  const sleep = (ms) => new Promise(res => setTimeout(res, ms));

  /* A ZIP goes to /api/documents/batch: one request, many documents. Shared
     metadata applies to every PDF inside; names come from the file names. */
  const saveBatch = async (isAnnouncement) => {
    const fd = new FormData();
    fd.append('file', file);
    fd.append('category', form.category);
    fd.append('doc_type', isAnnouncement ? 'pengumuman' : 'aturan');
    ['version', 'year', 'valid_from', 'valid_until'].forEach(k => { if (form[k]) fd.append(k, form[k]); });
    setSaving(true);
    try {
      const res = await api('/api/documents/batch', { method: 'POST', form: fd });
      setBatchResult(res);
      setForm(emptyForm); setFile(null);
      closeModal();
      load();
    } catch (e) {
      setFileError(`Gagal mengunggah ZIP: ${e.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleSave = async () => {
    if (saving) return;
    if (!file) { setFileError('Pilih berkas PDF atau ZIP terlebih dahulu.'); return; }
    const isAnnouncement = form.category.startsWith('Pengumuman');
    if (isAnnouncement && !form.valid_until) { setFormError('Pengumuman wajib memiliki Tanggal Berakhir.'); return; }
    if (isArchive) return saveBatch(isAnnouncement);
    if (!form.name.trim()) { setFormError('Nama dokumen wajib diisi.'); return; }
    const fd = new FormData();
    fd.append('file', file);
    fd.append('name', form.name);
    fd.append('category', form.category);
    fd.append('doc_type', isAnnouncement ? 'pengumuman' : 'aturan');
    ['doc_number', 'version', 'year', 'valid_from', 'valid_until'].forEach(k => { if (form[k]) fd.append(k, form[k]); });
    setSaving(true);
    try {
      const doc = await api('/api/documents', { method: 'POST', form: fd });
      let ingestNote = null;
      // Bila admin memilih "Terverifikasi": tunggu dokumen selesai diolah, lalu verifikasi
      if (form.status === 'Terverifikasi') {
        let d = doc;
        for (let i = 0; i < 60 && (d.ingest_status === 'belum' || d.ingest_status === 'diproses'); i++) {
          await sleep(2000);
          d = await api(`/api/documents/${doc.id}`);
        }
        if (d.ingest_status === 'selesai') await api(`/api/documents/${doc.id}/verify`, { method: 'POST' });
        else ingestNote = `Dokumen tersimpan, tetapi gagal diolah: ${d.ingest_error || d.ingest_status}. Status tetap Menunggu Validasi — lengkapi lewat halaman OCR.`;
      }
      setNotice(ingestNote ? { tone: 'warning', text: ingestNote } : { tone: 'success', text: `"${form.name.trim()}" ditambahkan ke registri.` });
      setForm(emptyForm); setFile(null);
      closeModal();
      load();
    } catch (e) {
      setFormError(`Gagal menyimpan: ${e.message}`);
    } finally {
      setSaving(false);
    }
  };

  const validate = async (doc) => {
    try {
      await api(`/api/documents/${doc.id}/verify`, { method: 'POST' });
      setNotice({ tone: 'success', text: `"${doc.name}" tervalidasi dan siap dipakai menjawab.` });
      closeModal();
      load();
    } catch (e) { setNotice({ tone: 'error', text: `Gagal memvalidasi: ${e.message}` }); }
  };

  const revoke = async (doc) => {
    if (!window.confirm(`Cabut dokumen "${doc.name}"? Dokumen tidak akan dipakai sebagai sumber jawaban.`)) return;
    try {
      await api(`/api/documents/${doc.id}/revoke`, { method: 'POST', body: { note: 'Dicabut oleh admin dari registri' } });
      setNotice({ tone: 'success', text: `"${doc.name}" dicabut dan tidak lagi dipakai menjawab.` });
      load();
    } catch (e) { setNotice({ tone: 'error', text: `Gagal mencabut: ${e.message}` }); }
  };

  const openPdf = (doc) => window.open(`/api/documents/${doc.id}/admin-file?token=${encodeURIComponent(auth.token || '')}`, '_blank');

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Terverifikasi': return <span className="admin-status-badge success">{status}</span>;
      case 'Menunggu Validasi': return <span className="admin-status-badge warning">{status}</span>;
      case 'Kedaluwarsa': return <span className="admin-status-badge danger">{status}</span>;
      case 'Dicabut': return <span className="admin-status-badge neutral">{status}</span>;
      /* An unfamiliar status from the backend still shows its own name rather
         than leaving the cell blank. */
      default: return <span className="admin-status-badge neutral">{status || '—'}</span>;
    }
  };

  const openDetail = (doc) => {
    setSelectedDoc(doc);
    setModalType('detail');
    setPreview([]);
    api(`/api/documents/${doc.id}/chunks`).then(c => setPreview(c.slice(0, 4))).catch(() => setPreview([]));
  };

  const [editingId, setEditingId] = useState(null);
  const isEdit = modalType === 'edit';

  /* Edit opens the same form, pre-filled, and saves with PATCH. The file and
     the status are not editable here: a new file is a new version, and status
     changes go through validation. */
  const openEdit = (doc) => {
    setForm({
      name: doc.name || '',
      category: doc.category || 'Pedoman',
      doc_number: doc.docNumber || '',
      version: doc.version || '',
      year: doc.year && doc.year !== '-' ? String(doc.year) : '',
      status: doc.status,
      valid_from: doc.validFrom || '',
      valid_until: doc.validUntilRaw || '',
    });
    setEditingId(doc.id);
    setSelectedDoc(null);
    setModalType('edit');
  };

  const handleUpdate = async () => {
    if (saving) return;
    if (!form.name.trim()) { setFormError('Nama dokumen wajib diisi.'); return; }
    const isAnnouncement = form.category.startsWith('Pengumuman');
    if (isAnnouncement && !form.valid_until) { setFormError('Pengumuman wajib memiliki Tanggal Berakhir.'); return; }
    setSaving(true);
    try {
      await api(`/api/documents/${editingId}`, {
        method: 'PATCH',
        body: {
          name: form.name.trim(),
          category: form.category,
          doc_number: form.doc_number || null,
          version: form.version || 'V.1',
          year: form.year ? Number(form.year) : null,
          doc_type: isAnnouncement ? 'pengumuman' : 'aturan',
          valid_from: form.valid_from || null,
          valid_until: form.valid_until || null,
        },
      });
      setNotice({ tone: 'success', text: 'Metadata dokumen tersimpan.' });
      setForm(emptyForm);
      closeModal();
      load();
    } catch (e) {
      setFormError(`Gagal menyimpan perubahan: ${e.message}`);
    } finally {
      setSaving(false);
    }
  };

  const closeModal = () => {
    setEditingId(null);
    setFormError('');
    setModalType(null);
    setSelectedDoc(null);
    setFileError('');
    setDragging(false);
  };

  const visibleDocs = statusFilter === 'Semua'
    ? mockDocuments
    : mockDocuments.filter(doc => doc.status === statusFilter);

  const statusOptions = ['Semua', 'Terverifikasi', 'Menunggu Validasi', 'Kedaluwarsa', 'Dicabut'];

  return (
    <div className="admin-page-container">
      {/* Tambah/Edit Modal */}
      {(modalType === 'tambah' || isEdit) && (
        <div className="registri-modal-overlay" onClick={closeModal}>
          <div className="registri-modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{isEdit ? 'Edit Metadata Dokumen' : 'Tambah Dokumen Registri'}</h3>
              <button className="close-btn" onClick={closeModal}><X size={20}/></button>
            </div>
            <div className="registri-modal-body">
              <div className="doc-info-notice">
                <Info size={16} />
                Dokumen yang digunakan sebagai sumber jawaban sistem AI harus berstatus Terverifikasi.
              </div>
              <div className="registri-form-grid">
                <div className="form-group">
                  <label htmlFor="registri-name">Nama Dokumen {isArchive ? '' : '*'}</label>
                  <input
                    id="registri-name"
                    type="text"
                    className="form-input"
                    placeholder={isArchive ? 'Diambil dari nama tiap berkas di dalam ZIP' : 'Masukkan nama resmi dokumen'}
                    value={form.name}
                    onChange={setField('name')}
                    disabled={isArchive}
                  />
                </div>
                <div className="form-group">
                  <label>Kategori</label>
                  <select className="form-input" value={form.category} onChange={setField('category')}>
                    <option>Pedoman</option>
                    <option>Tugas Akhir</option>
                    <option>PKL / Magang</option>
                    <option>SOP</option>
                    <option>Peraturan</option>
                    <option>Pengumuman / Informasi</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Nomor Dokumen</label>
                  <input type="text" className="form-input" placeholder="Contoh: UNP/PED/01" value={form.doc_number} onChange={setField('doc_number')} />
                </div>
                <div className="form-group">
                  <label>Versi</label>
                  <input type="text" className="form-input" placeholder="Contoh: V.1" value={form.version} onChange={setField('version')} />
                </div>
                <div className="form-group">
                  <label>Tahun Terbit *</label>
                  <input type="number" className="form-input" placeholder="2026" value={form.year} onChange={setField('year')} />
                </div>
                {!isEdit && <div className="form-group">
                  <label>Status Dokumen</label>
                  <select className="form-input" value={isArchive ? 'Menunggu Validasi' : form.status} onChange={setField('status')} disabled={isArchive}>
                    <option>Menunggu Validasi</option>
                    <option>Terverifikasi</option>
                  </select>
                </div>}
                <div className="form-group">
                  <label>Tanggal Berlaku</label>
                  <input type="date" className="form-input" value={form.valid_from} onChange={setField('valid_from')} />
                </div>
                <div className="form-group">
                  <label>Tanggal Berakhir (Masa Berlaku)</label>
                  <input type="date" className="form-input" value={form.valid_until} onChange={setField('valid_until')} />
                </div>
                {!isEdit && <div className="form-group full-width">
                  <label htmlFor="registri-file">Unggah Berkas Dokumen *</label>
                  <div
                    className={`file-upload-area${dragging ? ' is-dragging' : ''}${file ? ' has-file' : ''}${fileError ? ' has-error' : ''}`}
                    role="button"
                    tabIndex={0}
                    onClick={() => fileRef.current?.click()}
                    onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileRef.current?.click(); } }}
                    onDragOver={e => { e.preventDefault(); setDragging(true); }}
                    onDragLeave={() => setDragging(false)}
                    onDrop={e => { e.preventDefault(); setDragging(false); chooseFile(e.dataTransfer.files[0]); }}
                  >
                    {file ? (
                      <>
                        {isArchive ? <FileArchive size={28} color="var(--success)" /> : <FileText size={28} color="var(--success)" />}
                        <p className="file-upload-name">{file.name}</p>
                        <span className="file-upload-meta">
                          {formatBytes(file.size)} · {isArchive ? 'ZIP — setiap PDF di dalamnya didaftarkan terpisah' : 'siap diunggah'}
                        </span>
                        <button
                          type="button"
                          className="file-upload-clear"
                          onClick={e => { e.stopPropagation(); setFile(null); setFileError(''); if (fileRef.current) fileRef.current.value = ''; }}
                        >
                          Ganti berkas
                        </button>
                      </>
                    ) : (
                      <>
                        <Upload size={28} color="var(--text-muted)" />
                        <p className="file-upload-name">Seret berkas ke sini atau klik untuk memilih</p>
                        <span className="file-upload-meta">{limitHint('document')}</span>
                        <span className="file-upload-meta">atau {limitHint('archive')}</span>
                      </>
                    )}
                    <input
                      id="registri-file"
                      ref={fileRef}
                      type="file"
                      accept={`${UPLOAD_LIMITS.document.accept},${UPLOAD_LIMITS.archive.accept}`}
                      hidden
                      onChange={e => chooseFile(e.target.files[0])}
                    />
                  </div>
                  {fileError && (
                    <p className="form-error" role="alert">
                      <AlertCircle size={14} /> {fileError}
                    </p>
                  )}
                </div>}
              </div>
            </div>
            {formError && (
              <p className="form-error registri-form-error" role="alert"><AlertCircle size={14} /> {formError}</p>
            )}
            <div className="modal-footer">
               <button className="admin-btn-primary" style={{ backgroundColor: 'var(--surface)', color: 'var(--text-primary)', border: '1px solid var(--border)' }} onClick={closeModal}>Batal</button>
               <button className="admin-btn-primary" onClick={isEdit ? handleUpdate : handleSave}>
                 {saving ? 'Menyimpan...' : isEdit ? 'Simpan Perubahan' : 'Simpan Dokumen'}
               </button>
            </div>
          </div>
        </div>
      )}

      {/* Detail Dokumen Modal */}
      {modalType === 'detail' && selectedDoc && (
        <div className="registri-modal-overlay" onClick={closeModal}>
          <div className="registri-modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Detail Dokumen Resmi</h3>
              <button className="close-btn" onClick={closeModal}><X size={20}/></button>
            </div>
            <div className="registri-modal-body">
              <div className="modal-info-grid">
                <div className="info-group full-width">
                  <label>Nama Dokumen</label>
                  <p className="highlight-text">{selectedDoc.name}</p>
                </div>
                <div className="info-group">
                  <label>Kategori & Versi</label>
                  <p>{selectedDoc.category} - {selectedDoc.version}</p>
                </div>
                <div className="info-group">
                  <label>Status Keabsahan</label>
                  <p>{getStatusBadge(selectedDoc.status)}</p>
                </div>
                <div className="info-group">
                  <label>Asal / Sumber</label>
                  <p>{selectedDoc.origin}</p>
                </div>
                <div className="info-group">
                  <label>Masa Berlaku</label>
                  <p>{selectedDoc.year} s/d {selectedDoc.validUntil}</p>
                </div>
                
                {/* Mock PDF Preview */}
                <div className="mock-pdf-preview" style={{ marginTop: '20px' }}>
                  <div className="preview-content">
                    <h1 style={{ textAlign: 'center', fontSize: '14px', marginBottom: '10px' }}>{selectedDoc.name.toUpperCase()}</h1>
                    <p style={{ textAlign: 'center' }}>UNIVERSITAS NEGERI PADANG</p>
                    <hr style={{ margin: '10px 0' }}/>
                    {preview.length === 0 && <p>{selectedDoc.ingestStatus === 'gagal' ? `Dokumen gagal diolah: ${selectedDoc.ingestError || ''}` : 'Isi dokumen belum tersedia (sedang diolah).'}</p>}
                    {preview.map(c => (
                      <React.Fragment key={c.id}>
                        <p>{c.section || `Halaman ${c.page}`}</p>
                        <p>{c.text.length > 300 ? c.text.slice(0, 300) + '...' : c.text}</p>
                        <br/>
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
               <button className="admin-btn-primary" style={{ backgroundColor: 'var(--surface)', color: 'var(--text-primary)', border: '1px solid var(--border)' }} onClick={closeModal}>Tutup</button>
               {selectedDoc.status === 'Menunggu Validasi' && (
                 <button className="admin-btn-primary" style={{ backgroundColor: 'var(--success)' }} onClick={() => validate(selectedDoc)}>
                   <ShieldAlert size={16} style={{marginRight: '6px'}}/> Validasi Dokumen
                 </button>
               )}
               <button className="admin-btn-primary" style={{ backgroundColor: 'var(--surface)', color: 'var(--primary)', border: '1px solid var(--primary)' }} onClick={() => openPdf(selectedDoc)}>
                 Lihat PDF Utuh
               </button>
               <button className="admin-btn-primary" style={{ backgroundColor: 'var(--primary)' }} onClick={() => openEdit(selectedDoc)}>
                 <Edit2 size={16} style={{marginRight: '6px'}}/> Edit
               </button>
            </div>
          </div>
        </div>
      )}

      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Registri Dokumen</h2>
          <p className="subtitle">Kelola master data dokumen resmi yang menjadi sumber informasi dan referensi pengetahuan Pandu.</p>
        </div>
        
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" />
            <input type="text" placeholder="Cari nama dokumen..." value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="admin-filter-dropdown">
            <Filter size={16} aria-hidden="true" />
            <label htmlFor="registri-status" className="sr-only">Saring menurut status</label>
            <select
              id="registri-status"
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
            >
              {statusOptions.map(option => (
                <option key={option} value={option}>
                  {option === 'Semua' ? 'Semua status' : option}
                </option>
              ))}
            </select>
          </div>
          <button className="admin-btn-primary" onClick={() => { setForm(emptyForm); setFile(null); setModalType('tambah'); }}>
            <Upload size={16} style={{marginRight: '4px'}}/> Tambah Dokumen
          </button>
        </div>
      </div>

      {notice && (
        <div className={`admin-banner ${notice.tone}`} role="status">
          {notice.tone === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{notice.text}</span>
          <button type="button" onClick={() => setNotice(null)} aria-label="Tutup pesan"><X size={16} /></button>
        </div>
      )}

      {batchResult && (
        <div className={`admin-banner ${batchResult.created.length ? 'success' : 'warning'}`} role="status">
          {batchResult.created.length ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>
            <strong className="tabular">{batchResult.created.length}</strong> dokumen dari ZIP masuk antrean validasi
            {batchResult.skipped.length > 0 && (
              <> · <strong className="tabular">{batchResult.skipped.length}</strong> dilewati:{' '}
                {batchResult.skipped.map(sk => `${sk.file} (${sk.reason})`).join('; ')}
              </>
            )}
          </span>
          <button type="button" onClick={() => setBatchResult(null)} aria-label="Tutup pesan">
            <X size={16} />
          </button>
        </div>
      )}

      <div className="admin-table-meta">
        <span>
          Menampilkan <strong className="tabular">{visibleDocs.length}</strong> dari{' '}
          <strong className="tabular">{mockDocuments.length}</strong> dokumen
          {statusFilter !== 'Semua' && <> · status <strong>{statusFilter}</strong></>}
          {q && <> · pencarian <strong>&ldquo;{q}&rdquo;</strong></>}
        </span>
        {(statusFilter !== 'Semua' || q) && (
          <button type="button" className="admin-link-btn" onClick={() => { setStatusFilter('Semua'); setQ(''); }}>
            Bersihkan filter
          </button>
        )}
      </div>

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Dokumen Resmi</th>
              <th>Kategori</th>
              <th>Versi & Tahun</th>
              <th>Masa Berlaku</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading && mockDocuments.length === 0 && (
              [0, 1, 2].map(row => (
                <tr key={`skeleton-${row}`} className="admin-row-skeleton">
                  <td colSpan={6}><span className="skeleton-bar" /></td>
                </tr>
              ))
            )}
            {!loading && visibleDocs.length === 0 && (
              <tr>
                <td colSpan={6}>
                  <div className="admin-empty-state">
                    <FileSearch size={32} color="var(--text-muted)" />
                    <h4>{mockDocuments.length === 0 ? 'Registri masih kosong' : 'Tidak ada dokumen yang cocok'}</h4>
                    <p>
                      {mockDocuments.length === 0
                        ? 'Tambahkan dokumen resmi pertama agar Pandu punya sumber jawaban.'
                        : 'Ubah kata kunci pencarian atau pilih status yang berbeda.'}
                    </p>
                    {mockDocuments.length === 0 ? (
                      <button className="admin-btn-primary" onClick={() => { setForm(emptyForm); setFile(null); setModalType('tambah'); }}>
                        <Upload size={16} style={{ marginRight: '6px' }} /> Tambah Dokumen
                      </button>
                    ) : (
                      <button type="button" className="admin-link-btn" onClick={() => { setStatusFilter('Semua'); setQ(''); }}>
                        Bersihkan filter
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            )}
            {visibleDocs.map((doc) => (
              <tr key={doc.id}>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                     <FileText size={16} color="var(--primary)" style={{ flexShrink: 0 }} />
                     <strong style={{ fontSize: '13px', lineHeight: 1.4 }}>{doc.name}</strong>
                  </div>
                </td>
                <td>{doc.category}</td>
                <td>
                  <div style={{ fontSize: '12px', fontWeight: 600 }}>{doc.version}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>{doc.year}</div>
                </td>
                <td style={{ fontSize: '13px' }}>{doc.validUntil}</td>
                <td>{getStatusBadge(doc.status)}</td>
                <td>
                  <div className="admin-table-actions">
                    <button className="action-btn" title="Lihat Detail" onClick={() => openDetail(doc)}><Eye size={16} /></button>
                    <button className="action-btn" title="Edit Metadata" onClick={() => openEdit(doc)}><Edit2 size={16} /></button>
                    {doc.status !== 'Kedaluwarsa' && doc.status !== 'Dicabut' && (
                       <button className="action-btn" title="Arsipkan / Cabut Dokumen" onClick={() => revoke(doc)}><Archive size={16} /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Registri;
