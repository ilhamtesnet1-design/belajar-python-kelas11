import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Users, Activity, FilePlus } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import './Admin.css';

export const AdminDashboard = () => {
  return (
    <div className="admin-page">
      <div className="admin-header">
        <div>
          <h2>Ringkasan Sistem</h2>
          <p className="admin-subtitle">Pantau aktivitas dan statistik dokumen Pandu.</p>
        </div>
        <Link to="/admin/documents/add">
          <Button variant="primary" icon={<FilePlus size={16} />}>Tambah Dokumen</Button>
        </Link>
      </div>

      <div className="admin-stats-grid">
        <Card padding="md" className="stat-card">
          <div className="stat-card-icon bg-primary-light">
            <FileText size={24} className="text-primary" />
          </div>
          <div>
            <p className="stat-card-label">Total Dokumen</p>
            <h3 className="stat-card-value">24</h3>
          </div>
        </Card>
        
        <Card padding="md" className="stat-card">
          <div className="stat-card-icon bg-success-light">
            <Activity size={24} className="text-success" />
          </div>
          <div>
            <p className="stat-card-label">Pertanyaan Hari Ini</p>
            <h3 className="stat-card-value">156</h3>
          </div>
        </Card>
        
        <Card padding="md" className="stat-card">
          <div className="stat-card-icon bg-warning-light">
            <Users size={24} className="text-warning" />
          </div>
          <div>
            <p className="stat-card-label">Pengguna Aktif</p>
            <h3 className="stat-card-value">1,204</h3>
          </div>
        </Card>
      </div>

      <div className="admin-content-section">
        <div className="section-title-row">
          <h3>Aktivitas Terbaru</h3>
          <Link to="/admin/documents" className="view-all-link">Lihat Semua Dokumen</Link>
        </div>
        
        <Card padding="none" className="table-card">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Aktivitas</th>
                <th>Dokumen/Subjek</th>
                <th>Waktu</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Pembaruan Dokumen</td>
                <td>Panduan Akademik FT</td>
                <td>10 menit yang lalu</td>
                <td><span className="status-text text-success">Berhasil</span></td>
              </tr>
              <tr>
                <td>Penambahan Dokumen</td>
                <td>SK Rektor No 15/2026</td>
                <td>2 jam yang lalu</td>
                <td><span className="status-text text-success">Berhasil</span></td>
              </tr>
              <tr>
                <td>Pertanyaan Gagal Dijawab</td>
                <td>"Nilai IPK semester lalu"</td>
                <td>5 jam yang lalu</td>
                <td><span className="status-text text-warning">Ditolak</span></td>
              </tr>
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
};
