import React, { useState } from 'react';
import { Search, Filter, Check, X, FileText, ChevronRight, User } from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './Proposal.css';

const Proposal = () => {
  const [selectedProposal, setSelectedProposal] = useState(null);

  const proposals = [
    { id: '1', nim: '20010045', name: 'Budi Santoso', title: 'Penerapan Machine Learning untuk Deteksi Penyakit Daun', supervisor: 'Dr. Hendra', date: '10 Okt 2026', status: 'Diajukan', prodi: 'Teknik Informatika', desc: 'Penelitian ini menggunakan CNN resnet-50 untuk mendeteksi penyakit daun tomat dari gambar...' },
    { id: '2', nim: '20010046', name: 'Siti Aminah', title: 'Sistem Informasi Akademik Berbasis Blockchain', supervisor: 'Prof. Dina', date: '08 Okt 2026', status: 'Sedang diperiksa', prodi: 'Sistem Informasi', desc: 'Membangun sistem akademik yang aman menggunakan teknologi smart contract ethereum...' },
    { id: '3', nim: '19010023', name: 'Reza Rahadian', title: 'Optimasi Jaringan Menggunakan Algoritma Genetika', supervisor: 'Dr. Budi', date: '01 Okt 2026', status: 'Disetujui', prodi: 'Teknik Informatika', desc: 'Fokus pada optimasi routing pada jaringan mesh topology di lingkungan kampus...' },
    { id: '4', nim: '21010012', name: 'Ahmad Faisal', title: 'Rancang Bangun E-Commerce Terintegrasi OCR', supervisor: 'Dr. Hendra', date: '28 Sep 2026', status: 'Ditolak', prodi: 'Teknik Informatika', desc: 'Sistem jual beli dengan fitur scan KTP untuk verifikasi seller.' },
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Diajukan': return <span className="admin-status-badge warning">Diajukan</span>;
      case 'Sedang diperiksa': return <span className="admin-status-badge" style={{ backgroundColor: 'var(--primary-light)', color: 'var(--primary-dark)' }}>Diperiksa</span>;
      case 'Disetujui': return <span className="admin-status-badge success">Disetujui</span>;
      case 'Ditolak': return <span className="admin-status-badge danger">Ditolak</span>;
      default: return null;
    }
  };

  return (
    <div className="admin-page-container">
      {/* Modal Detail Proposal */}
      {selectedProposal && (
        <div className="proposal-modal-overlay" onClick={() => setSelectedProposal(null)}>
          <div className="proposal-modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Detail Pengajuan Proposal</h3>
              <button className="close-btn" onClick={() => setSelectedProposal(null)}><X size={20}/></button>
            </div>
            <div className="modal-body">
              <div className="modal-info-grid">
                <div className="info-group">
                  <label>Mahasiswa</label>
                  <p>{selectedProposal.name} ({selectedProposal.nim})</p>
                </div>
                <div className="info-group">
                  <label>Program Studi</label>
                  <p>{selectedProposal.prodi}</p>
                </div>
                <div className="info-group" style={{ gridColumn: 'span 2' }}>
                  <label>Judul Tugas Akhir</label>
                  <p className="highlight-text">{selectedProposal.title}</p>
                </div>
                <div className="info-group">
                  <label>Calon Pembimbing</label>
                  <p>{selectedProposal.supervisor}</p>
                </div>
                <div className="info-group">
                  <label>Status Saat Ini</label>
                  <p>{getStatusBadge(selectedProposal.status)}</p>
                </div>
                <div className="info-group" style={{ gridColumn: 'span 2' }}>
                  <label>Deskripsi / Abstrak Singkat</label>
                  <p className="desc-box">{selectedProposal.desc}</p>
                </div>
                <div className="info-group" style={{ gridColumn: 'span 2' }}>
                  <label>Dokumen Lampiran</label>
                  <button className="admin-btn-primary" style={{ backgroundColor: 'var(--secondary)', width: 'fit-content' }}>
                    <FileText size={16}/> Lihat Draft Proposal.pdf
                  </button>
                </div>
              </div>
            </div>
            <div className="modal-footer">
               <button className="admin-btn-primary" style={{ backgroundColor: 'var(--danger)', display: 'flex', alignItems: 'center', gap: '8px' }} onClick={() => setSelectedProposal(null)}>
                 <X size={16}/> Tolak Proposal
               </button>
               <button className="admin-btn-primary" style={{ backgroundColor: 'var(--success)', display: 'flex', alignItems: 'center', gap: '8px' }} onClick={() => setSelectedProposal(null)}>
                 <Check size={16}/> Setujui Proposal
               </button>
            </div>
          </div>
        </div>
      )}

      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Proposal & Tugas Akhir</h2>
          <p className="subtitle">Verifikasi dan kelola pengajuan judul Tugas Akhir mahasiswa.</p>
        </div>
        
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" />
            <input type="text" placeholder="Cari judul/NIM..." />
          </div>
          <button className="admin-filter-dropdown">
            <Filter size={16} /> Status
          </button>
        </div>
      </div>

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Mahasiswa</th>
              <th>Judul Proposal</th>
              <th>Pembimbing</th>
              <th>Tgl. Pengajuan</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {proposals.map((prop) => (
              <tr key={prop.id}>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--secondary-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--secondary)'}}>
                      <User size={16} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 600 }}>{prop.name}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>{prop.nim}</div>
                    </div>
                  </div>
                </td>
                <td style={{ maxWidth: '250px' }}>
                  <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 500 }}>
                    {prop.title}
                  </div>
                </td>
                <td>{prop.supervisor}</td>
                <td>{prop.date}</td>
                <td>{getStatusBadge(prop.status)}</td>
                <td>
                  <button 
                    className="admin-btn-primary" 
                    style={{ padding: '6px 12px', fontSize: '12px', backgroundColor: 'var(--surface)', color: 'var(--primary)', border: '1px solid var(--primary)' }}
                    onClick={() => setSelectedProposal(prop)}
                  >
                    Detail <ChevronRight size={14}/>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Proposal;
