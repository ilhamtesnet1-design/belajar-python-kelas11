import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Edit, Trash2, ShieldCheck, Download, RefreshCw, FileText } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import './Admin.css';

export const DocumentDetail = () => {
  return (
    <div className="admin-page">
      <div className="admin-header">
        <div className="flex items-center gap-4">
          <Link to="/admin/documents">
            <Button variant="ghost" icon={<ArrowLeft size={16} />} />
          </Link>
          <div>
            <h2>Detail Dokumen</h2>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" icon={<Edit size={16} />}>Edit Metadata</Button>
          <Button variant="ghost" icon={<Trash2 size={16} />} className="text-warning">Hapus</Button>
        </div>
      </div>

      <div className="grid gap-6" style={{ gridTemplateColumns: '2fr 1fr' }}>
        <Card padding="lg">
          <div className="doc-detail-header">
            <div>
              <h3 className="text-xl font-bold mb-2">Panduan Akademik Fakultas Teknik</h3>
              <p className="text-muted">Universitas Negeri Padang</p>
            </div>
            <Badge variant="success">Berlaku</Badge>
          </div>
          
          <div className="doc-meta-info">
            <div className="meta-block">
              <p>Kategori</p>
              <h4>Panduan Akademik</h4>
            </div>
            <div className="meta-block">
              <p>Tahun / Versi</p>
              <h4>2026</h4>
            </div>
            <div className="meta-block">
              <p>Tanggal Diunggah</p>
              <h4>12 Jan 2026, 09:45 WIB</h4>
            </div>
            <div className="meta-block">
              <p>Terakhir Diperbarui</p>
              <h4>15 Jan 2026, 14:20 WIB</h4>
            </div>
          </div>
          
          <hr style={{ borderColor: 'var(--border)', margin: '24px 0' }} />
          
          <div>
            <h4 className="font-semibold mb-2">Deskripsi</h4>
            <p className="text-muted leading-relaxed">
              Dokumen ini berisi panduan komprehensif mengenai aturan akademik, persyaratan kelulusan, yudisium, serta hak dan kewajiban mahasiswa di lingkungan Fakultas Teknik Universitas Negeri Padang untuk tahun ajaran 2026/2027.
            </p>
          </div>
        </Card>
        
        <div className="flex flex-col gap-6">
          <Card padding="md">
            <h4 className="font-semibold mb-4">Status Indeksasi RAG</h4>
            
            <div className="flex items-center gap-3 mb-6 p-3 rounded" style={{ backgroundColor: 'var(--success-bg)' }}>
              <ShieldCheck size={20} className="text-success" />
              <div>
                <p className="font-medium text-success" style={{ fontSize: '14px' }}>Berhasil diindeks</p>
                <p style={{ fontSize: '12px', color: 'var(--success)' }}>Siap digunakan untuk menjawab</p>
              </div>
            </div>
            
            <div className="flex flex-col gap-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted">Total Halaman</span>
                <span className="text-sm font-medium">45</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted">Jumlah Chunk</span>
                <span className="text-sm font-medium">124</span>
              </div>
            </div>
            
            <Button variant="outline" fullWidth className="mt-6" icon={<RefreshCw size={14} />}>
              Indeks Ulang
            </Button>
          </Card>
          
          <Card padding="md">
            <h4 className="font-semibold mb-4">File Dokumen</h4>
            <div className="flex items-center gap-3 mb-4 p-3 border rounded">
              <div className="bg-secondary p-2 rounded text-primary">
                <FileText size={20} />
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-sm font-medium truncate">Panduan_Akademik_FT_2026.pdf</p>
                <p className="text-xs text-muted">2.4 MB</p>
              </div>
            </div>
            <Button variant="outline" fullWidth icon={<Download size={14} />}>
              Unduh Dokumen
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
};
