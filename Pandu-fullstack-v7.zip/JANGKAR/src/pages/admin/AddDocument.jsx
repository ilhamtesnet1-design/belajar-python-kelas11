import { limitHint } from '../../config/uploads';
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, Save } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Textarea } from '../../components/ui/Input';
import './Admin.css';

export const AddDocument = () => {
  const navigate = useNavigate();

  const handleSave = (e) => {
    e.preventDefault();
    navigate('/admin/documents');
  };

  return (
    <div className="admin-page">
      <div className="admin-header">
        <div className="flex items-center gap-4">
          <Link to="/admin/documents">
            <Button variant="ghost" icon={<ArrowLeft size={16} />} />
          </Link>
          <div>
            <h2>Tambah Dokumen Baru</h2>
            <p className="admin-subtitle">Unggah dokumen resmi untuk diindeks oleh sistem Pandu.</p>
          </div>
        </div>
      </div>

      <div className="admin-form-container">
        <Card padding="lg">
          <form onSubmit={handleSave}>
            <div className="admin-form-group">
              <Input label="Nama Dokumen" placeholder="Contoh: Peraturan Rektor No. X Tahun Y" required />
            </div>
            
            <div className="admin-form-group flex gap-4">
              <Input label="Kategori" placeholder="Contoh: Peraturan" className="flex-1" required />
              <Input label="Tahun/Versi" placeholder="Contoh: 2026" className="flex-1" required />
            </div>
            
            <div className="admin-form-group">
              <Input label="Lembaga Penerbit" placeholder="Contoh: Universitas Negeri Padang" required />
            </div>
            
            <div className="admin-form-group">
              <Textarea label="Deskripsi Singkat" placeholder="Dokumen ini mengatur tentang..." />
            </div>
            
            <div className="admin-form-group">
              <label className="input-label">Unggah Berkas (PDF)</label>
              <div 
                className="mt-2 flex flex-col items-center justify-center p-8 border-2" 
                style={{ borderStyle: 'dashed', borderColor: 'var(--border)', borderRadius: 'var(--radius-md)', backgroundColor: 'var(--bg-main)' }}
              >
                <Upload size={32} className="text-muted mb-4" />
                <p className="font-medium text-main mb-1">Pilih berkas atau seret ke sini</p>
                <p className="text-sm text-muted mb-4">{limitHint('document')}</p>
                <Button variant="outline" type="button">Pilih Berkas</Button>
              </div>
            </div>
            
            <div className="admin-form-actions">
              <Link to="/admin/documents" className="flex-1">
                <Button variant="outline" fullWidth type="button">Batal</Button>
              </Link>
              <Button variant="primary" fullWidth type="submit" icon={<Save size={16} />} className="flex-1">
                Simpan & Indeks
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};
