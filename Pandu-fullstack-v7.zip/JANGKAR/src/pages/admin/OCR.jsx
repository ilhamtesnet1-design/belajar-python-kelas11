import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, Search, Copy, RefreshCw, Check, AlertCircle, CheckCircle2, X, ScanText } from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './OCR.css';
import { api, mapDocument } from '../../api/client';

const INGEST = {
  belum: { label: 'Antre', tone: 'neutral' },
  diproses: { label: 'Diproses', tone: 'warning' },
  selesai: { label: 'Selesai', tone: 'success' },
  gagal: { label: 'Gagal', tone: 'danger' },
};

/* Pages in pasted OCR text are separated by a line holding only "---". */
const splitPages = text => text.split(/\n\s*-{3,}\s*\n/).map(p => p.trim()).filter(Boolean);

const OCR = () => {
  const [docs, setDocs] = useState([]);
  const [q, setQ] = useState('');
  const [selected, setSelected] = useState(null);
  const [chunks, setChunks] = useState([]);
  const [chunksLoading, setChunksLoading] = useState(false);
  const [ocrText, setOcrText] = useState('');
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const loadDocs = () => api('/api/documents')
    .then(rows => {
      const mapped = rows.map(mapDocument);
      setDocs(mapped);
      setSelected(cur => (cur ? mapped.find(d => d.id === cur.id) || null : mapped[0] || null));
    })
    .catch(e => setFeedback({ tone: 'error', text: `Gagal memuat dokumen: ${e.message}` }));

  useEffect(() => { loadDocs(); }, []);

  useEffect(() => {
    if (!selected) { setChunks([]); return; }
    setChunksLoading(true);
    api(`/api/documents/${selected.id}/chunks`)
      .then(setChunks)
      .catch(() => setChunks([]))
      .finally(() => setChunksLoading(false));
  }, [selected?.id, selected?.ingestStatus]);

  /* Keep polling while anything is still queued or being processed. */
  const processing = docs.some(d => d.ingestStatus === 'belum' || d.ingestStatus === 'diproses');
  useEffect(() => {
    if (!processing) return undefined;
    const t = setInterval(loadDocs, 4000);
    return () => clearInterval(t);
  }, [processing]);

  const reingest = async () => {
    if (!selected || busy) return;
    setBusy(true);
    try {
      await api(`/api/documents/${selected.id}/reingest`, { method: 'POST' });
      setFeedback({ tone: 'success', text: `${selected.name} diproses ulang.` });
      await loadDocs();
    } catch (e) {
      setFeedback({ tone: 'error', text: `Proses ulang gagal: ${e.message}` });
    } finally {
      setBusy(false);
    }
  };

  const submitOcr = async () => {
    const pages = splitPages(ocrText);
    if (!selected || busy || pages.length === 0) return;
    setBusy(true);
    try {
      const res = await api(`/api/documents/${selected.id}/ocr-text`, { method: 'POST', body: { pages } });
      setFeedback({ tone: 'success', text: `Teks ${pages.length} halaman tersimpan · ${res.chunk_count} bagian terindeks.` });
      setOcrText('');
      await loadDocs();
    } catch (e) {
      setFeedback({ tone: 'error', text: `Gagal menyimpan teks OCR: ${e.message}` });
    } finally {
      setBusy(false);
    }
  };

  const copyAll = async () => {
    try {
      await navigator.clipboard.writeText(chunks.map(c => c.text).join('\n\n'));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard blocked */ }
  };

  const visible = docs.filter(d => !q || d.name.toLowerCase().includes(q.toLowerCase()));
  const failedCount = docs.filter(d => d.ingestStatus === 'gagal').length;
  const pagesPasted = splitPages(ocrText).length;

  return (
    <div className="admin-page-container">
      <div className="admin-page-header">
        <h2>Pengolahan Teks Dokumen</h2>
        <p className="subtitle">
          Periksa teks yang diekstrak dari setiap PDF. PDF hasil pindai yang gagal diekstrak bisa dilengkapi dengan teks OCR.
          {failedCount > 0 && ` ${failedCount} dokumen perlu teks OCR.`}
        </p>
      </div>

      {feedback && (
        <div className={`admin-banner ${feedback.tone}`} role="status">
          {feedback.tone === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{feedback.text}</span>
          <button type="button" onClick={() => setFeedback(null)} aria-label="Tutup pesan"><X size={16} /></button>
        </div>
      )}

      <div className="admin-ocr-layout">
        <div className="admin-ocr-upload-section">
          <div className="ocr-list-header">
            <h3>Dokumen</h3>
            <div className="admin-search-input" style={{ width: '200px' }}>
              <Search size={14} color="var(--text-muted)" aria-hidden="true" />
              <label htmlFor="ocr-search" className="sr-only">Cari dokumen</label>
              <input id="ocr-search" type="text" placeholder="Cari dokumen..." value={q} onChange={e => setQ(e.target.value)} />
            </div>
          </div>

          <div className="admin-table-container">
            <table className="admin-table text-small">
              <thead>
                <tr>
                  <th>Dokumen</th>
                  <th>Halaman</th>
                  <th>Bagian</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {visible.length === 0 && (
                  <tr>
                    <td colSpan={4}>
                      <div className="admin-empty-state">
                        <ScanText size={28} color="var(--text-muted)" />
                        <p>{docs.length === 0 ? 'Belum ada dokumen. ' : 'Tidak ada yang cocok.'}
                          {docs.length === 0 && <Link to="/admin/registri">Unggah di Registri</Link>}
                        </p>
                      </div>
                    </td>
                  </tr>
                )}
                {visible.map(doc => {
                  const st = INGEST[doc.ingestStatus] || INGEST.belum;
                  return (
                    <tr
                      key={doc.id}
                      className={`ocr-row${selected?.id === doc.id ? ' is-selected' : ''}`}
                      onClick={() => setSelected(doc)}
                      tabIndex={0}
                      onKeyDown={e => { if (e.key === 'Enter') setSelected(doc); }}
                      aria-selected={selected?.id === doc.id}
                    >
                      <td>
                        <div className="cell-title">
                          <FileText size={14} color="var(--primary)" />
                          <span style={{ fontWeight: 500 }}>{doc.name}</span>
                        </div>
                      </td>
                      <td className="num">{doc.pages || '—'}</td>
                      <td className="num">{doc.chunkCount ?? 0}</td>
                      <td><span className={`admin-status-badge ${st.tone}`}>{st.label}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="admin-ocr-result-section">
          <div className="admin-ocr-result">
            <div className="ocr-result-header">
              <h3><FileText size={16} /> {selected ? selected.name : 'Pilih dokumen'}</h3>
              <div className="admin-header-actions" style={{ gap: '8px' }}>
                <button className="page-btn" type="button" title="Proses ulang" onClick={reingest} disabled={!selected || busy}>
                  <RefreshCw size={14} />
                </button>
                <button className="page-btn" type="button" title="Salin teks" onClick={copyAll} disabled={chunks.length === 0}>
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            <div className="ocr-result-body">
              {!selected && <p>Pilih dokumen di sebelah kiri untuk melihat teks hasil ekstraksi.</p>}

              {selected?.ingestStatus === 'gagal' && (
                <div className="ocr-manual">
                  <p className="ocr-manual-why">
                    <AlertCircle size={14} /> Teks tidak bisa diekstrak{selected.ingestError ? `: ${selected.ingestError}` : ''}.
                    Biasanya karena PDF berupa hasil pindai. Tempel teks OCR di bawah — pisahkan tiap halaman dengan baris <code>---</code>.
                  </p>
                  <label htmlFor="ocr-text" className="sr-only">Teks OCR</label>
                  <textarea
                    id="ocr-text"
                    rows={10}
                    value={ocrText}
                    onChange={e => setOcrText(e.target.value)}
                    placeholder={'BAB I\nPasal 1\n...\n---\nBAB II\nPasal 5\n...'}
                  />
                  <div className="ocr-manual-actions">
                    <span className="tabular">{pagesPasted} halaman terdeteksi</span>
                    <button type="button" className="admin-btn-primary" onClick={submitOcr} disabled={busy || pagesPasted === 0}>
                      {busy ? 'Menyimpan…' : 'Simpan & indeks'}
                    </button>
                  </div>
                </div>
              )}

              {selected && (selected.ingestStatus === 'belum' || selected.ingestStatus === 'diproses') && (
                <p>Dokumen sedang diolah. Halaman ini memperbarui diri setiap beberapa detik.</p>
              )}

              {selected && chunksLoading && <p>Memuat teks…</p>}

              {selected && !chunksLoading && chunks.map(c => (
                <section key={c.id} className="ocr-chunk">
                  <span className="ocr-chunk-meta tabular">
                    Hlm. {c.page}{c.section ? ` · ${c.section}` : ''} · bagian #{c.index + 1}
                  </span>
                  <p>{c.text}</p>
                </section>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OCR;
