import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck, Search, Filter, AlertCircle, CheckCircle2,
  FileText, X, ExternalLink, Inbox,
} from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './Validasi.css';
import { api, auth, mapDocument } from '../../api/client';

/* What an admin is actually confirming when they approve a document. Each
   item has to be ticked before the approve button unlocks, so "validated"
   means something specific rather than "someone clicked yes". */
const CHECKLIST = [
  { id: 'resmi', label: 'Dokumen resmi dari instansi berwenang' },
  { id: 'lengkap', label: 'Metadata dokumen lengkap dan benar' },
  { id: 'versi', label: 'Versi dokumen valid dan terkini' },
  { id: 'berlaku', label: 'Masa berlaku sesuai ketentuan' },
];

const Validasi = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [sourceFilter, setSourceFilter] = useState('Semua');
  const [review, setReview] = useState(null);
  const [checked, setChecked] = useState({});
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const load = useCallback(({ silent = false } = {}) => {
    if (!silent) setLoading(true);
    return api('/api/documents')
      .then(rows => {
        const docs = rows.map(mapDocument);
        setDocuments(docs);
        /* Keep an open review panel in step with the server copy. */
        setReview(current => (current ? docs.find(d => d.id === current.id) || current : current));
      })
      .catch(e => setFeedback({ tone: 'error', text: `Gagal memuat antrean: ${e.message}` }))
      .finally(() => { if (!silent) setLoading(false); });
  }, []);

  useEffect(() => { load(); }, [load]);

  /* While any queued document is still being ingested, re-check every 5s so
     the approve button unlocks by itself when processing finishes. */
  const stillProcessing = documents.some(d =>
    d.status === 'Menunggu Validasi' && (d.ingestStatus === 'belum' || d.ingestStatus === 'diproses'));
  useEffect(() => {
    if (!stillProcessing) return undefined;
    const timer = setInterval(() => load({ silent: true }), 5000);
    return () => clearInterval(timer);
  }, [stillProcessing, load]);

  const pending = documents.filter(doc => doc.status === 'Menunggu Validasi');

  const sources = ['Semua', ...Array.from(new Set(pending.map(d => d.origin).filter(Boolean)))];

  const visible = pending.filter(doc => {
    const matchesQuery = !q || doc.name.toLowerCase().includes(q.toLowerCase());
    const matchesSource = sourceFilter === 'Semua' || doc.origin === sourceFilter;
    return matchesQuery && matchesSource;
  });

  const openReview = (doc) => {
    setReview(doc);
    setChecked({});
    setNote('');
  };

  const closeReview = () => {
    setReview(null);
    setChecked({});
    setNote('');
  };

  const allChecked = CHECKLIST.every(item => checked[item.id]);
  const ingestReady = review?.ingestStatus === 'selesai';
  const ingestLabel = {
    belum: 'Menunggu diolah',
    diproses: 'Sedang diolah',
    selesai: 'Selesai diolah',
    gagal: 'Gagal diolah',
  }[review?.ingestStatus] || '—';

  const approve = async () => {
    if (!allChecked || !ingestReady || busy) return;
    setBusy(true);
    try {
      await api(`/api/documents/${review.id}/verify`, { method: 'POST', body: { note: note.trim() || null } });
      setFeedback({ tone: 'success', text: `"${review.name}" tervalidasi dan siap dipakai menjawab.` });
      closeReview();
      load();
    } catch (e) {
      setFeedback({ tone: 'error', text: `Gagal memvalidasi: ${e.message}` });
    } finally {
      setBusy(false);
    }
  };

  const reject = async () => {
    if (busy) return;
    if (!note.trim()) {
      setFeedback({ tone: 'error', text: 'Tulis alasan penolakan pada catatan sebelum menolak dokumen.' });
      return;
    }
    setBusy(true);
    try {
      await api(`/api/documents/${review.id}/revoke`, { method: 'POST', body: { note: `Ditolak saat validasi: ${note.trim()}` } });
      setFeedback({ tone: 'success', text: `"${review.name}" ditolak dan dikembalikan ke pengaju.` });
      closeReview();
      load();
    } catch (e) {
      setFeedback({ tone: 'error', text: `Gagal menolak: ${e.message}` });
    } finally {
      setBusy(false);
    }
  };

  const openPdf = (doc) =>
    window.open(`/api/documents/${doc.id}/admin-file?token=${encodeURIComponent(auth.token || '')}`, '_blank');

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Validasi Dokumen</h2>
          <p className="subtitle">Periksa dokumen baru sebelum dipakai sebagai sumber jawaban Pandu.</p>
        </div>

        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" aria-hidden="true" />
            <label htmlFor="validasi-search" className="sr-only">Cari antrean validasi</label>
            <input
              id="validasi-search"
              type="text"
              placeholder="Cari antrean validasi..."
              value={q}
              onChange={e => setQ(e.target.value)}
            />
          </div>
          <div className="admin-filter-dropdown">
            <Filter size={16} aria-hidden="true" />
            <label htmlFor="validasi-source" className="sr-only">Saring menurut sumber</label>
            <select id="validasi-source" value={sourceFilter} onChange={e => setSourceFilter(e.target.value)}>
              {sources.map(source => (
                <option key={source} value={source}>
                  {source === 'Semua' ? 'Semua sumber' : source}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {feedback && (
        <div className={`admin-banner ${feedback.tone}`} role="status">
          {feedback.tone === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{feedback.text}</span>
          <button type="button" onClick={() => setFeedback(null)} aria-label="Tutup pesan">
            <X size={16} />
          </button>
        </div>
      )}

      {!loading && pending.length > 0 && (
        <div className="admin-banner warning">
          <AlertCircle size={18} />
          <span>
            <strong className="tabular">{pending.length}</strong> dokumen menunggu validasi Anda sebelum bisa dipakai menjawab pertanyaan mahasiswa.
          </span>
        </div>
      )}

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Nama Dokumen</th>
              <th>Versi</th>
              <th>Sumber</th>
              <th>Masa Berlaku</th>
              <th>Diajukan</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              [0, 1].map(row => (
                <tr key={`skeleton-${row}`} className="admin-row-skeleton">
                  <td colSpan={7}><span className="skeleton-bar" /></td>
                </tr>
              ))
            )}

            {!loading && visible.length === 0 && (
              <tr>
                <td colSpan={7}>
                  <div className="admin-empty-state">
                    <Inbox size={32} color="var(--text-muted)" />
                    <h4>{pending.length === 0 ? 'Antrean kosong' : 'Tidak ada yang cocok'}</h4>
                    <p>
                      {pending.length === 0
                        ? 'Semua dokumen di registri sudah divalidasi. Dokumen baru akan muncul di sini setelah diunggah.'
                        : 'Ubah kata kunci atau pilih sumber yang berbeda.'}
                    </p>
                  </div>
                </td>
              </tr>
            )}

            {!loading && visible.map((doc) => (
              <tr key={doc.id}>
                <td>
                  <div className="cell-title">
                    <FileText size={16} color="var(--primary)" />
                    <strong>{doc.name}</strong>
                  </div>
                </td>
                <td>{doc.version || '—'}</td>
                <td>{doc.origin || '—'}</td>
                <td>{doc.validUntil}</td>
                <td>{doc.updated || '—'}</td>
                <td>
                  <span className="admin-status-badge warning">Menunggu Validasi</span>
                  {doc.ingestStatus !== 'selesai' && (
                    <span className="cell-sub">{doc.ingestStatus === 'gagal' ? 'Gagal diolah' : 'Sedang diolah'}</span>
                  )}
                </td>
                <td>
                  <button type="button" className="admin-btn-sm primary" onClick={() => openReview(doc)}>
                    <ShieldCheck size={14} /> Periksa
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {review && (
        <div className="validasi-overlay" onClick={closeReview}>
          <section
            className="validasi-panel"
            onClick={e => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="validasi-title"
          >
            <header className="validasi-panel-header">
              <div>
                <span className="eyebrow">Tinjau dokumen</span>
                <h3 id="validasi-title">{review.name}</h3>
              </div>
              <button type="button" className="close-btn" onClick={closeReview} aria-label="Tutup">
                <X size={20} />
              </button>
            </header>

            <div className="validasi-panel-body">
              <dl className="validasi-meta">
                <div><dt>Kategori</dt><dd>{review.category || '—'}</dd></div>
                <div><dt>Nomor</dt><dd>{review.docNumber || review.id}</dd></div>
                <div><dt>Versi</dt><dd>{review.version || '—'}</dd></div>
                <div><dt>Sumber</dt><dd>{review.origin || '—'}</dd></div>
                <div><dt>Masa berlaku</dt><dd>{review.validity}</dd></div>
                <div><dt>Halaman terindeks</dt><dd className="tabular">{review.chunkCount ?? 0} bagian</dd></div>
                <div><dt>Pengolahan teks</dt><dd>{ingestLabel}</dd></div>
              </dl>

              {!ingestReady && (
                <div className={`admin-banner ${review.ingestStatus === 'gagal' ? 'error' : 'warning'}`}>
                  <AlertCircle size={18} />
                  <span>
                    {review.ingestStatus === 'gagal'
                      ? `Teks dokumen gagal diekstrak${review.ingestError ? `: ${review.ingestError}` : ''}. Proses lewat halaman OCR sebelum divalidasi.`
                      : 'Dokumen masih diolah. Validasi baru bisa dilakukan setelah teksnya selesai diindeks.'}
                  </span>
                </div>
              )}

              <button type="button" className="validasi-open-pdf" onClick={() => openPdf(review)}>
                <ExternalLink size={16} /> Buka berkas PDF
              </button>

              <fieldset className="validasi-checklist">
                <legend>Daftar pemeriksaan</legend>
                {CHECKLIST.map(item => (
                  <label key={item.id} className="validasi-check">
                    <input
                      type="checkbox"
                      checked={Boolean(checked[item.id])}
                      onChange={e => setChecked({ ...checked, [item.id]: e.target.checked })}
                    />
                    <span>{item.label}</span>
                  </label>
                ))}
              </fieldset>

              <div className="validasi-note">
                <label htmlFor="validasi-catatan">Catatan validasi</label>
                <textarea
                  id="validasi-catatan"
                  rows={3}
                  placeholder="Wajib diisi bila menolak dokumen."
                  value={note}
                  onChange={e => setNote(e.target.value)}
                />
              </div>
            </div>

            <footer className="validasi-panel-footer">
              <button type="button" className="admin-btn-ghost danger" onClick={reject} disabled={busy}>
                Tolak
              </button>
              <button type="button" className="admin-btn-primary" onClick={approve} disabled={!allChecked || !ingestReady || busy}>
                <ShieldCheck size={16} />
                {busy ? 'Memproses...' : 'Setujui & Validasi'}
              </button>
            </footer>

            {ingestReady && !allChecked && (
              <p className="validasi-hint">Centang seluruh daftar pemeriksaan untuk mengaktifkan tombol validasi.</p>
            )}
          </section>
        </div>
      )}
    </div>
  );
};

export default Validasi;
