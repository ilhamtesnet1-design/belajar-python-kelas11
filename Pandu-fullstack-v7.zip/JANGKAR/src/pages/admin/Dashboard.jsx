import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckCircle, Clock, AlertTriangle, MessageSquare,
  ShieldAlert, FileSearch, ArrowRight, Cpu, UserCheck, AlertCircle, RefreshCw,
} from 'lucide-react';
import './Dashboard.css';
import '../../components/layout/AdminTable.css';
import BarChart from '../../components/charts/BarChart';
import { api, mapDocument } from '../../api/client';
import { formatWhen } from '../../utils/time';

const STATUS_TONE = {
  'Terverifikasi': 'success',
  'Selesai': 'success',
  'Menunggu Validasi': 'warning',
  'Kedaluwarsa': 'danger',
  'Gagal': 'danger',
  'Dicabut': 'neutral',
};

const StatusBadge = ({ status }) => (
  <span className={`admin-status-badge ${STATUS_TONE[status] || 'neutral'}`}>{status}</span>
);

const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [activity, setActivity] = useState([]);
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    setError('');
    return Promise.all([
      api('/api/dashboard/summary'),
      api('/api/dashboard/activity?limit=6'),
      api(`/api/documents?status=${encodeURIComponent('Menunggu Validasi')}`),
    ])
      .then(([s, a, p]) => {
        setSummary(s);
        setActivity(a);
        setPending(p.map(mapDocument));
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const counts = summary?.documents || {};
  const verified = counts['Terverifikasi'] || 0;
  const waiting = counts['Menunggu Validasi'] || 0;
  const totalDocs = Object.values(counts).reduce((sum, n) => sum + n, 0);
  const expiring = summary?.expiring_soon || 0;
  const questions = summary?.questions || 0;

  const stats = [
    {
      title: 'Dokumen Terverifikasi',
      value: verified,
      note: totalDocs ? `${Math.round((verified / totalDocs) * 100)}% dari ${totalDocs} dokumen registri` : 'Registri masih kosong',
      icon: <CheckCircle size={20} />,
      tone: 'success',
      to: '/admin/registri',
    },
    {
      title: 'Menunggu Validasi',
      value: waiting,
      note: waiting > 0 ? 'Belum dipakai menjawab sampai divalidasi' : 'Tidak ada antrean',
      icon: <Clock size={20} />,
      tone: 'warning',
      to: '/admin/validasi',
    },
    {
      title: 'Akan Kedaluwarsa',
      value: expiring,
      note: expiring > 0 ? 'Habis masa berlaku dalam 30 hari' : 'Tidak ada dalam 30 hari ke depan',
      icon: <AlertTriangle size={20} />,
      tone: 'danger',
      to: '/admin/registri',
    },
    {
      title: `Pertanyaan ${summary?.period_days || 30} Hari`,
      value: questions,
      note: questions
        ? `${Math.round((summary.refusal_rate || 0) * 100)}% ditolak karena tidak ada sumber`
        : 'Belum ada pertanyaan masuk',
      icon: <MessageSquare size={20} />,
      tone: 'info',
      to: '/admin/evaluasi',
    },
  ];

  const statusChart = [
    { label: 'Terverifikasi', value: verified, color: 'var(--success)' },
    { label: 'Menunggu', value: waiting, color: 'var(--warning)' },
    { label: 'Kedaluwarsa', value: counts['Kedaluwarsa'] || 0, color: 'var(--danger)' },
    { label: 'Dicabut', value: counts['Dicabut'] || 0, color: 'var(--text-muted)' },
  ];

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Dashboard Overview</h2>
          <p className="subtitle">Ringkasan aktivitas dan status sistem Pandu.</p>
        </div>
        <div className="admin-header-actions">
          <button type="button" className="admin-btn-sm" onClick={load} disabled={loading}>
            <RefreshCw size={14} /> {loading ? 'Memuat…' : 'Muat ulang'}
          </button>
        </div>
      </div>

      {error && (
        <div className="admin-banner error" role="alert">
          <AlertCircle size={18} />
          <span>Gagal memuat dashboard: {error}. Pastikan backend berjalan di localhost:8000.</span>
        </div>
      )}

      <div className="admin-stat-grid">
        {stats.map((stat) => (
          <Link className={`admin-stat-card tone-${stat.tone}`} key={stat.title} to={stat.to}>
            <div className="admin-stat-top">
              <div className="admin-stat-icon">{stat.icon}</div>
              <ArrowRight size={16} className="admin-stat-arrow" />
            </div>
            <div className="admin-stat-content">
              <h3>{loading && !summary ? '–' : stat.value}</h3>
              <p>{stat.title}</p>
              <span className="admin-stat-note">{loading && !summary ? 'Memuat…' : stat.note}</span>
            </div>
          </Link>
        ))}
      </div>

      <div className="admin-dashboard-two-col">
        <div className="admin-dashboard-card chart-card">
          <div className="card-header">
            <div>
              <h3>Status Dokumen Registri</h3>
              <p className="card-subtitle">{totalDocs} dokumen terdaftar</p>
            </div>
          </div>
          <div className="card-body">
            <BarChart data={statusChart} height={236} caption="Jumlah dokumen registri menurut status" />
          </div>
        </div>

        <div className="admin-dashboard-card">
          <div className="card-header">
            <h3>Aktivitas Terbaru</h3>
          </div>
          <div className="card-body no-padding">
            {activity.length === 0 ? (
              <div className="admin-empty-state">
                <FileSearch size={28} color="var(--text-muted)" />
                <p>{loading ? 'Memuat aktivitas…' : 'Belum ada aktivitas. Unggah dokumen pertama di Registri.'}</p>
              </div>
            ) : (
              <ul className="admin-activity-list">
                {activity.map((act, i) => (
                  <li key={`${act.kind}-${act.document_id}-${i}`} className="admin-activity-item">
                    <span className={`activity-avatar ${act.actor === 'admin' ? 'admin' : 'engine'}`}>
                      {act.actor === 'admin' ? <UserCheck size={14} /> : <Cpu size={14} />}
                    </span>
                    <div className="activity-details">
                      <h4>{act.text}</h4>
                      <p>
                        {act.actor === 'admin' ? 'Admin' : act.actor === 'system' ? 'Sistem' : 'Mesin Pandu'}
                        {' · '}{formatWhen(act.at)}
                      </p>
                    </div>
                    <div className="activity-status"><StatusBadge status={act.status} /></div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className="admin-dashboard-card" style={{ marginTop: 'var(--space-20)' }}>
        <div className="card-header">
          <div>
            <h3>Dokumen yang Memerlukan Perhatian</h3>
            <p className="card-subtitle">Belum bisa dipakai sebagai sumber jawaban sampai divalidasi</p>
          </div>
          <Link to="/admin/validasi" className="admin-link-btn">Buka antrean validasi</Link>
        </div>
        <div className="card-body no-padding">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Nama Dokumen</th>
                <th>Status</th>
                <th>Masa Berlaku</th>
                <th>Terakhir Diperbarui</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {!loading && pending.length === 0 && (
                <tr>
                  <td colSpan={5}>
                    <div className="admin-empty-state">
                      <FileSearch size={32} color="var(--text-muted)" />
                      <h4>Tidak ada yang menunggu</h4>
                      <p>Semua dokumen di registri sudah divalidasi dan siap dipakai menjawab.</p>
                    </div>
                  </td>
                </tr>
              )}
              {pending.slice(0, 5).map(doc => (
                <tr key={doc.id}>
                  <td>
                    <strong>{doc.name}</strong>
                    <span className="cell-sub">
                      {doc.version}
                      {doc.ingestStatus !== 'selesai' && ` · ${doc.ingestStatus === 'gagal' ? 'gagal diolah' : 'sedang diolah'}`}
                    </span>
                  </td>
                  <td><StatusBadge status={doc.status} /></td>
                  <td>{doc.validUntil}</td>
                  <td>{doc.updated || '—'}</td>
                  <td>
                    <Link to="/admin/validasi" className="admin-btn-sm primary">
                      <ShieldAlert size={14} /> Validasi
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
