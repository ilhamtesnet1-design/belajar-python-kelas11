import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Target, Search, Filter, BarChart4, Play, Upload, AlertCircle, CheckCircle2,
  ChevronDown, X, ClipboardList,
} from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './Evaluasi.css';
import TrendLine from '../../components/charts/TrendLine';
import { api } from '../../api/client';
import { formatWhen } from '../../utils/time';

/* Charter targets — the same numbers scripts/ragas_eval.py checks against. */
const METRICS = [
  { key: 'answer_accuracy', title: 'Akurasi Jawaban', target: 0.85,
    missing: 'Jalankan: python -m scripts.ragas_eval <id run>' },
  { key: 'citation_accuracy', title: 'Akurasi Sitasi', target: 0.90,
    missing: 'Butuh pertanyaan berlabel dokumen sumber' },
  { key: 'refusal_accuracy', title: 'Akurasi Penolakan', target: 0.90,
    missing: 'Belum ada evaluasi' },
  { key: 'faithfulness', title: 'Faithfulness RAGAS', target: 0.85,
    missing: 'Jalankan ragas_eval dengan --ragas' },
];

const pct = v => (v === null || v === undefined ? null : Math.round(v * 1000) / 10);

const tone = (value, target) => {
  if (value === null || value === undefined) return 'neutral';
  if (value >= target) return 'success';
  if (value >= target - 0.1) return 'warning';
  return 'danger';
};

/* What one question's latest result means, in words a reviewer can act on. */
function verdict(result, question) {
  if (!result) return { label: 'Belum diuji', tone: 'neutral', ok: null };
  if (question.should_refuse) {
    return result.refused
      ? { label: 'Benar menolak', tone: 'success', ok: true }
      : { label: 'Seharusnya menolak', tone: 'danger', ok: false };
  }
  if (result.refused) return { label: 'Salah menolak', tone: 'danger', ok: false };
  if (result.citation_correct === false) return { label: 'Sitasi meleset', tone: 'warning', ok: false };
  return { label: 'Dijawab', tone: 'success', ok: true };
}

const Evaluasi = () => {
  const [runs, setRuns] = useState([]);
  const [latest, setLatest] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('Semua');
  const [openRow, setOpenRow] = useState(null);
  const csvRef = useRef(null);

  const load = async () => {
    setLoading(true);
    try {
      const [r, qs, s] = await Promise.all([
        api('/api/eval/runs'),
        api('/api/eval/questions'),
        api('/api/dashboard/summary'),
      ]);
      setRuns(r);
      setQuestions(qs);
      setSummary(s);
      setLatest(r.length ? await api(`/api/eval/runs/${r[0].id}`) : null);
    } catch (e) {
      setFeedback({ tone: 'error', text: `Gagal memuat evaluasi: ${e.message}` });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const runEvaluation = async () => {
    if (running) return;
    setRunning(true);
    setFeedback(null);
    try {
      const res = await api('/api/eval/runs', { method: 'POST', body: {} });
      setFeedback({ tone: 'success', text: `Evaluasi #${res.run_id} selesai untuk ${res.summary.n} pertanyaan.` });
      await load();
    } catch (e) {
      setFeedback({ tone: 'error', text: `Evaluasi gagal: ${e.message}` });
    } finally {
      setRunning(false);
    }
  };

  const importCsv = async (file) => {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const res = await api('/api/eval/questions/import', { method: 'POST', form: fd });
      setFeedback({ tone: 'success', text: `${res.imported} pertanyaan diimpor dari ${file.name}.` });
      await load();
    } catch (e) {
      setFeedback({ tone: 'error', text: `Impor CSV gagal: ${e.message}` });
    } finally {
      if (csvRef.current) csvRef.current.value = '';
    }
  };

  const latestSummary = latest?.summary || runs[0]?.summary || {};

  /* Oldest to newest, last six runs. */
  const recentRuns = [...runs].reverse().slice(-6);
  const trendSeries = [
    { name: 'Akurasi Penolakan', color: 'var(--viz-1)', values: recentRuns.map(r => pct(r.summary?.refusal_accuracy)) },
    { name: 'Akurasi Sitasi', color: 'var(--viz-2)', values: recentRuns.map(r => pct(r.summary?.citation_accuracy)) },
    { name: 'Akurasi Jawaban', color: 'var(--viz-3)', values: recentRuns.map(r => pct(r.summary?.answer_accuracy)) },
  ].filter(s => s.values.some(v => v !== null));
  const trendMin = Math.max(0, Math.floor(Math.min(
    60, ...trendSeries.flatMap(s => s.values.filter(v => v !== null)),
  ) / 10) * 10);

  const resultsById = useMemo(() => {
    const map = {};
    (latest?.results || []).forEach(r => { map[r.question_id] = r; });
    return map;
  }, [latest]);

  const categories = ['Semua', ...Array.from(new Set(questions.map(x => x.category).filter(Boolean)))];
  const visible = questions.filter(item =>
    (!q || item.question.toLowerCase().includes(q.toLowerCase()))
    && (category === 'Semua' || item.category === category));

  const needsReview = questions.filter(item => verdict(resultsById[item.id], item).ok === false).length;

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Evaluasi Sistem RAG</h2>
          <p className="subtitle">
            {latest
              ? `Hasil evaluasi #${latest.id} · ${latestSummary.n} pertanyaan · ${formatWhen(runs[0]?.created_at)}`
              : 'Belum ada evaluasi. Tambahkan set pertanyaan lalu jalankan evaluasi.'}
          </p>
        </div>
        <div className="admin-header-actions">
          <input ref={csvRef} type="file" accept=".csv,text/csv" hidden onChange={e => importCsv(e.target.files[0])} />
          <button type="button" className="admin-btn-sm" onClick={() => csvRef.current?.click()}>
            <Upload size={14} /> Impor CSV
          </button>
          <button type="button" className="admin-btn-primary" onClick={runEvaluation} disabled={running || questions.length === 0}>
            <Play size={16} /> {running ? 'Menjalankan…' : 'Jalankan evaluasi'}
          </button>
        </div>
      </div>

      {feedback && (
        <div className={`admin-banner ${feedback.tone}`} role="status">
          {feedback.tone === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{feedback.text}</span>
          <button type="button" onClick={() => setFeedback(null)} aria-label="Tutup pesan"><X size={16} /></button>
        </div>
      )}

      <div className="evaluasi-metrics-grid">
        {METRICS.map(m => {
          const value = latestSummary[m.key];
          const t = tone(value, m.target);
          return (
            <div className={`evaluasi-metric-card status-${t}`} key={m.key}>
              <h3>{m.title}</h3>
              <div className={`metric-value ${t}`}>
                {value === null || value === undefined ? '—' : `${pct(value)}%`}
              </div>
              {(value === null || value === undefined) && (
                <span className="metric-missing">{loading ? 'Memuat…' : m.missing}</span>
              )}
              <div className="metric-target">
                <Target size={14} style={{ marginRight: '4px' }} /> Target ≥ {Math.round(m.target * 100)}%
              </div>
            </div>
          );
        })}
      </div>

      <div className="evaluasi-two-col">
        <div className="admin-dashboard-card">
          <div className="card-header">
            <div>
              <h3>Tren Kualitas</h3>
              <p className="card-subtitle">{recentRuns.length} evaluasi terakhir</p>
            </div>
          </div>
          <div className="card-body">
            {recentRuns.length < 2 || trendSeries.length === 0 ? (
              <div className="admin-empty-state">
                <BarChart4 size={28} color="var(--text-muted)" />
                <p>Tren muncul setelah minimal dua evaluasi dijalankan.</p>
              </div>
            ) : (
              <TrendLine
                series={trendSeries}
                labels={recentRuns.map(r => `#${r.id}`)}
                target={85}
                targetLabel="Target min. 85%"
                min={trendMin}
                max={100}
                unit="%"
                height={268}
                caption="Tren metrik kualitas pada evaluasi terakhir"
              />
            )}
          </div>
        </div>

        <div className="admin-dashboard-card">
          <div className="card-header">
            <div>
              <h3><BarChart4 size={18} style={{ marginRight: '8px', verticalAlign: 'text-bottom' }} /> Penggunaan Nyata</h3>
              <p className="card-subtitle">Pertanyaan mahasiswa, {summary?.period_days || 30} hari terakhir</p>
            </div>
          </div>
          <div className="card-body">
            <div className="perf-grid">
              <div className="perf-item">
                <span className="perf-label">Waktu respons p95</span>
                <strong className="perf-val tabular">
                  {summary?.latency_p95_ms ? `${(summary.latency_p95_ms / 1000).toFixed(1)} detik` : '—'}
                </strong>
              </div>
              <div className="perf-item">
                <span className="perf-label">Dijawab &lt; 5 detik</span>
                <strong className="perf-val tabular">
                  {summary?.under_5s_rate === null || summary?.under_5s_rate === undefined ? '—' : `${pct(summary.under_5s_rate)}%`}
                </strong>
              </div>
              <div className="perf-item">
                <span className="perf-label">Tingkat penolakan</span>
                <strong className="perf-val tabular">{summary ? `${pct(summary.refusal_rate)}%` : '—'}</strong>
              </div>
              <div className="perf-item">
                <span className="perf-label">Umpan balik positif / negatif</span>
                <strong className="perf-val tabular">
                  {summary ? `${summary.feedback_up} / ${summary.feedback_down}` : '—'}
                </strong>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h3>Set Pertanyaan Evaluasi</h3>
          <p className="subtitle">
            {questions.length} pertanyaan{needsReview > 0 && ` · ${needsReview} perlu ditinjau`}
          </p>
        </div>
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" aria-hidden="true" />
            <label htmlFor="eval-search" className="sr-only">Cari pertanyaan</label>
            <input id="eval-search" type="text" placeholder="Cari pertanyaan..." value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="admin-filter-dropdown">
            <Filter size={16} aria-hidden="true" />
            <label htmlFor="eval-category" className="sr-only">Saring kategori</label>
            <select id="eval-category" value={category} onChange={e => setCategory(e.target.value)}>
              {categories.map(c => <option key={c} value={c}>{c === 'Semua' ? 'Semua kategori' : c}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Pertanyaan Pengujian</th>
              <th>Kategori</th>
              <th>Harapan</th>
              <th>Hasil Terakhir</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {!loading && visible.length === 0 && (
              <tr>
                <td colSpan={6}>
                  <div className="admin-empty-state">
                    <ClipboardList size={32} color="var(--text-muted)" />
                    <h4>{questions.length === 0 ? 'Set evaluasi masih kosong' : 'Tidak ada yang cocok'}</h4>
                    <p>
                      {questions.length === 0
                        ? 'Impor CSV dengan kolom question, expected_answer, should_refuse, expected_document_id, expected_page, expected_section, category.'
                        : 'Ubah kata kunci atau kategori.'}
                    </p>
                  </div>
                </td>
              </tr>
            )}
            {visible.map(item => {
              const result = resultsById[item.id];
              const v = verdict(result, item);
              const isOpen = openRow === item.id;
              return (
                <React.Fragment key={item.id}>
                  <tr>
                    <td className="num" style={{ color: 'var(--text-secondary)' }}>Q-{String(item.id).padStart(2, '0')}</td>
                    <td style={{ fontWeight: 500, maxWidth: '320px' }}>{item.question}</td>
                    <td>{item.category || '—'}</td>
                    <td>{item.should_refuse ? 'Ditolak' : 'Dijawab'}</td>
                    <td><span className={`admin-status-badge ${v.tone}`}>{v.label}</span></td>
                    <td>
                      <button
                        type="button"
                        className="admin-btn-sm"
                        disabled={!result}
                        aria-expanded={isOpen}
                        onClick={() => setOpenRow(isOpen ? null : item.id)}
                      >
                        Detail <ChevronDown size={13} style={{ transform: isOpen ? 'rotate(180deg)' : 'none' }} />
                      </button>
                    </td>
                  </tr>
                  {isOpen && result && (
                    <tr className="eval-detail-row">
                      <td colSpan={6}>
                        <div className="eval-detail">
                          <div>
                            <span className="eyebrow">Jawaban sistem</span>
                            <p>{result.answer}</p>
                          </div>
                          {item.expected_answer && (
                            <div>
                              <span className="eyebrow">Jawaban acuan</span>
                              <p>{item.expected_answer}</p>
                            </div>
                          )}
                          <div>
                            <span className="eyebrow">Sumber dipakai</span>
                            <p>
                              {result.citations?.length
                                ? result.citations.map(c => `${c.document_name}${c.section ? `, ${c.section}` : ''}, hlm. ${c.page}`).join(' · ')
                                : 'Tidak ada'}
                            </p>
                          </div>
                          <div className="eval-detail-meta tabular">{result.latency_ms} ms</div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Evaluasi;
