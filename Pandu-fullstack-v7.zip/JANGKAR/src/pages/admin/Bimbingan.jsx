import React from 'react';
import { Search, Filter, MessageSquare, History } from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './Bimbingan.css';

const Bimbingan = () => {
  const monitoringData = [
    { id: 1, name: 'Budi Santoso', nim: '20010045', supervisor: 'Dr. Hendra', title: 'Penerapan Machine Learning...', pertemuan: 8, progress: 80, lastUpdate: '2 hari yang lalu', status: 'Lancar' },
    { id: 2, name: 'Siti Aminah', nim: '20010046', supervisor: 'Prof. Dina', title: 'Sistem Informasi Akademik...', pertemuan: 3, progress: 30, lastUpdate: '1 minggu yang lalu', status: 'Perlu Perhatian' },
    { id: 3, name: 'Ahmad Faisal', nim: '21010012', supervisor: 'Dr. Budi', title: 'Rancang Bangun E-Commerce...', pertemuan: 12, progress: 100, lastUpdate: 'Hari ini', status: 'Selesai' },
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Lancar': return <span className="admin-status-badge success">Lancar</span>;
      case 'Perlu Perhatian': return <span className="admin-status-badge warning">Perlu Perhatian</span>;
      case 'Selesai': return <span className="admin-status-badge" style={{ backgroundColor: 'var(--primary-light)', color: 'var(--primary-dark)' }}>Selesai</span>;
      default: return null;
    }
  };

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Monitoring Bimbingan</h2>
          <p className="subtitle">Pantau aktivitas bimbingan mahasiswa dan dosen secara real-time.</p>
        </div>
        
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" />
            <input type="text" placeholder="Cari mahasiswa atau dosen..." />
          </div>
          <button className="admin-filter-dropdown">
            <Filter size={16} /> Filter
          </button>
        </div>
      </div>

      <div className="admin-bimbingan-stats">
        <div className="b-stat-card">
          <div className="b-stat-val">156</div>
          <div className="b-stat-label">Bimbingan Aktif</div>
        </div>
        <div className="b-stat-card">
          <div className="b-stat-val" style={{color: 'var(--warning)'}}>24</div>
          <div className="b-stat-label">Kurang Pertemuan</div>
        </div>
        <div className="b-stat-card">
          <div className="b-stat-val" style={{color: 'var(--success)'}}>45</div>
          <div className="b-stat-label">Siap Sidang</div>
        </div>
      </div>

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Mahasiswa</th>
              <th>Pembimbing</th>
              <th>Pertemuan</th>
              <th>Progress</th>
              <th>Update Terakhir</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {monitoringData.map((data) => (
              <tr key={data.id}>
                <td>
                  <div style={{ fontWeight: 600 }}>{data.name}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>{data.nim}</div>
                </td>
                <td>{data.supervisor}</td>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <MessageSquare size={14} color="var(--primary)" />
                    <strong>{data.pertemuan}</strong> / 12
                  </div>
                </td>
                <td>
                  <div className="progress-container">
                    <div className="progress-bar-bg">
                      <div 
                        className="progress-bar-fill" 
                        style={{ 
                          width: `${data.progress}%`,
                          backgroundColor: data.progress === 100 ? 'var(--primary-dark)' : 'var(--primary)'
                        }}
                      ></div>
                    </div>
                    <span className="progress-text">{data.progress}%</span>
                  </div>
                </td>
                <td>{data.lastUpdate}</td>
                <td>{getStatusBadge(data.status)}</td>
                <td>
                  <button className="admin-btn-primary" style={{ padding: '6px 12px', fontSize: '12px', backgroundColor: 'var(--surface)', color: 'var(--secondary)', border: '1px solid var(--border)' }}>
                    <History size={14} style={{ marginRight: '6px' }}/> Log
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Bimbingan;
