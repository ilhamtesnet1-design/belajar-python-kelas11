import React, { useEffect, useState } from 'react';
import { Search, Filter, Plus, Edit2, Trash2, HelpCircle, X, Eye, EyeOff, AlertCircle, CheckCircle2 } from 'lucide-react';
import '../../components/layout/AdminTable.css';
import './FAQ.css';
import { api } from '../../api/client';
import { formatWhen } from '../../utils/time';

const EMPTY = { question: '', answer: '', category: 'Umum', is_published: true, sort_order: 0 };

const FAQAdmin = () => {
  const [faqs, setFaqs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('Semua');
  const [editing, setEditing] = useState(null); // null | 'new' | id
  const [form, setForm] = useState(EMPTY);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState(null);

  const load = () => {
    setLoading(true);
    return api('/api/faq/all')
      .then(setFaqs)
      .catch(e => setNotice({ tone: 'error', text: `Gagal memuat FAQ: ${e.message}` }))
      .finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const open = (faq) => {
    setForm(faq ? { question: faq.question, answer: faq.answer, category: faq.category, is_published: faq.is_published, sort_order: faq.sort_order } : EMPTY);
    setFormError('');
    setEditing(faq ? faq.id : 'new');
  };
  const close = () => { setEditing(null); setFormError(''); };

  const save = async (e) => {
    e.preventDefault();
    if (saving) return;
    if (form.question.trim().length < 5 || form.answer.trim().length < 5) {
      setFormError('Pertanyaan dan jawaban masing-masing minimal 5 karakter.');
      return;
    }
    setSaving(true);
    const body = { ...form, question: form.question.trim(), answer: form.answer.trim(), category: form.category.trim() || 'Umum', sort_order: Number(form.sort_order) || 0 };
    try {
      if (editing === 'new') await api('/api/faq', { method: 'POST', body });
      else await api(`/api/faq/${editing}`, { method: 'PATCH', body });
      setNotice({ tone: 'success', text: editing === 'new' ? 'FAQ ditambahkan.' : 'Perubahan FAQ tersimpan.' });
      close();
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const togglePublished = async (faq) => {
    try {
      await api(`/api/faq/${faq.id}`, { method: 'PATCH', body: { is_published: !faq.is_published } });
      load();
    } catch (e) { setNotice({ tone: 'error', text: e.message }); }
  };

  const remove = async (faq) => {
    if (!window.confirm(`Hapus FAQ "${faq.question}"? Tindakan ini tidak bisa dibatalkan.`)) return;
    try {
      await api(`/api/faq/${faq.id}`, { method: 'DELETE' });
      setNotice({ tone: 'success', text: 'FAQ dihapus.' });
      load();
    } catch (e) { setNotice({ tone: 'error', text: e.message }); }
  };

  const categories = ['Semua', ...Array.from(new Set(faqs.map(f => f.category)))];
  const visible = faqs.filter(f =>
    (!q || `${f.question} ${f.answer}`.toLowerCase().includes(q.toLowerCase()))
    && (category === 'Semua' || f.category === category));
  const setField = k => e => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Manajemen FAQ</h2>
          <p className="subtitle">Pertanyaan seputar layanan Pandu yang tampil di halaman FAQ mahasiswa.</p>
        </div>
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" aria-hidden="true" />
            <label htmlFor="faq-search" className="sr-only">Cari FAQ</label>
            <input id="faq-search" type="text" placeholder="Cari pertanyaan..." value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="admin-filter-dropdown">
            <Filter size={16} aria-hidden="true" />
            <label htmlFor="faq-cat" className="sr-only">Saring kategori</label>
            <select id="faq-cat" value={category} onChange={e => setCategory(e.target.value)}>
              {categories.map(c => <option key={c} value={c}>{c === 'Semua' ? 'Semua kategori' : c}</option>)}
            </select>
          </div>
          <button type="button" className="admin-btn-primary" onClick={() => open(null)}>
            <Plus size={16} /> Tambah FAQ
          </button>
        </div>
      </div>

      {notice && (
        <div className={`admin-banner ${notice.tone}`} role="status">
          {notice.tone === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{notice.text}</span>
          <button type="button" onClick={() => setNotice(null)} aria-label="Tutup pesan"><X size={16} /></button>
        </div>
      )}

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Pertanyaan</th>
              <th>Kategori</th>
              <th>Status</th>
              <th>Diperbarui</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {!loading && visible.length === 0 && (
              <tr><td colSpan={5}>
                <div className="admin-empty-state">
                  <HelpCircle size={32} color="var(--text-muted)" />
                  <h4>{faqs.length === 0 ? 'Belum ada FAQ' : 'Tidak ada yang cocok'}</h4>
                  <p>{faqs.length === 0 ? 'Tambahkan pertanyaan pertama untuk halaman FAQ mahasiswa.' : 'Ubah kata kunci atau kategori.'}</p>
                </div>
              </td></tr>
            )}
            {visible.map(faq => (
              <tr key={faq.id}>
                <td>
                  <div className="faq-question-cell">
                    <HelpCircle size={16} color="var(--primary)" style={{ flexShrink: 0 }} />
                    <span>
                      <strong style={{ fontWeight: 500 }}>{faq.question}</strong>
                      <span className="cell-sub">{faq.answer.length > 90 ? `${faq.answer.slice(0, 90)}…` : faq.answer}</span>
                    </span>
                  </div>
                </td>
                <td><span className="faq-category">{faq.category}</span></td>
                <td>
                  <span className={`admin-status-badge ${faq.is_published ? 'success' : 'neutral'}`}>
                    {faq.is_published ? 'Ditampilkan' : 'Disembunyikan'}
                  </span>
                </td>
                <td style={{ color: 'var(--text-secondary)' }}>{formatWhen(faq.updated_at)}</td>
                <td>
                  <div className="admin-table-actions">
                    <button type="button" className="action-btn" title={faq.is_published ? 'Sembunyikan' : 'Tampilkan'} onClick={() => togglePublished(faq)}>
                      {faq.is_published ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                    <button type="button" className="action-btn" title="Edit" onClick={() => open(faq)}><Edit2 size={16} /></button>
                    <button type="button" className="action-btn delete" title="Hapus" onClick={() => remove(faq)}><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing !== null && (
        <div className="validasi-overlay" onClick={close}>
          <form className="validasi-panel" onClick={e => e.stopPropagation()} onSubmit={save} role="dialog" aria-modal="true" aria-labelledby="faq-form-title">
            <header className="validasi-panel-header">
              <div>
                <span className="eyebrow">{editing === 'new' ? 'FAQ baru' : 'Edit FAQ'}</span>
                <h3 id="faq-form-title">{editing === 'new' ? 'Tambah pertanyaan' : 'Ubah pertanyaan'}</h3>
              </div>
              <button type="button" className="close-btn" onClick={close} aria-label="Tutup"><X size={20} /></button>
            </header>
            <div className="validasi-panel-body">
              <div className="validasi-note">
                <label htmlFor="faq-q">Pertanyaan</label>
                <textarea id="faq-q" rows={2} value={form.question} onChange={setField('question')} />
              </div>
              <div className="validasi-note">
                <label htmlFor="faq-a">Jawaban</label>
                <textarea id="faq-a" rows={6} value={form.answer} onChange={setField('answer')} />
              </div>
              <div className="faq-form-row">
                <div className="validasi-note">
                  <label htmlFor="faq-c">Kategori</label>
                  <input id="faq-c" className="form-input" list="faq-categories" value={form.category} onChange={setField('category')} />
                  <datalist id="faq-categories">
                    {categories.filter(c => c !== 'Semua').map(c => <option key={c} value={c} />)}
                  </datalist>
                </div>
                <div className="validasi-note">
                  <label htmlFor="faq-o">Urutan</label>
                  <input id="faq-o" className="form-input" type="number" value={form.sort_order} onChange={setField('sort_order')} />
                </div>
              </div>
              <label className="validasi-check">
                <input type="checkbox" checked={form.is_published} onChange={setField('is_published')} />
                <span>Tampilkan di halaman FAQ mahasiswa</span>
              </label>
              {formError && <p className="form-error" role="alert"><AlertCircle size={14} /> {formError}</p>}
            </div>
            <footer className="validasi-panel-footer">
              <button type="button" className="admin-btn-ghost" onClick={close}>Batal</button>
              <button type="submit" className="admin-btn-primary" disabled={saving}>{saving ? 'Menyimpan…' : 'Simpan FAQ'}</button>
            </footer>
          </form>
        </div>
      )}
    </div>
  );
};

export default FAQAdmin;
