import React from 'react';
import { Search, Filter, Plus, Edit2, Trash2, Eye } from 'lucide-react';
import '../../components/layout/AdminTable.css';

const Mahasiswa = () => {
  const students = [
    { nim: '20010045', name: 'Budi Santoso', prodi: 'Teknik Informatika', angkatan: '2020', status: 'Aktif' },
    { nim: '20010046', name: 'Siti Aminah', prodi: 'Sistem Informasi', angkatan: '2020', status: 'Aktif' },
    { nim: '21010012', name: 'Ahmad Faisal', prodi: 'Teknik Informatika', angkatan: '2021', status: 'Cuti' },
    { nim: '21010089', name: 'Nisa Salsabila', prodi: 'Pendidikan Teknik Informatika', angkatan: '2021', status: 'Aktif' },
    { nim: '19010023', name: 'Reza Rahadian', prodi: 'Sistem Informasi', angkatan: '2019', status: 'Lulus' },
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Aktif': return <span className="admin-status-badge success">Aktif</span>;
      case 'Cuti': return <span className="admin-status-badge warning">Cuti</span>;
      case 'Lulus': return <span className="admin-status-badge" style={{ backgroundColor: 'var(--primary-light)', color: 'var(--primary-dark)' }}>Lulus</span>;
      default: return null;
    }
  };

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Data Mahasiswa</h2>
          <p className="subtitle">Kelola data mahasiswa dan status akademiknya.</p>
        </div>
        
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" />
            <input type="text" placeholder="Cari nama atau NIM..." />
          </div>
          
          <button className="admin-filter-dropdown">
            <Filter size={16} /> Filter
          </button>
          
          <button className="admin-btn-primary">
            <Plus size={16} /> Tambah Data
          </button>
        </div>
      </div>

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th>NIM</th>
              <th>Nama Mahasiswa</th>
              <th>Program Studi</th>
              <th>Angkatan</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.nim}>
                <td><strong>{student.nim}</strong></td>
                <td>{student.name}</td>
                <td>{student.prodi}</td>
                <td>{student.angkatan}</td>
                <td>{getStatusBadge(student.status)}</td>
                <td>
                  <div className="admin-table-actions">
                    <button className="action-btn" title="Detail"><Eye size={16} /></button>
                    <button className="action-btn" title="Edit"><Edit2 size={16} /></button>
                    <button className="action-btn delete" title="Hapus"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        <div className="admin-pagination">
          <span className="pagination-info">Menampilkan 1-5 dari 124 data</span>
          <div className="pagination-controls">
            <button className="page-btn" disabled>&lt;</button>
            <button className="page-btn active">1</button>
            <button className="page-btn">2</button>
            <button className="page-btn">3</button>
            <button className="page-btn">...</button>
            <button className="page-btn">25</button>
            <button className="page-btn">&gt;</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Mahasiswa;
