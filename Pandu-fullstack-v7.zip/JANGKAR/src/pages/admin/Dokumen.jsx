import React from 'react';
import { Search, Filter, Upload, Edit2, Trash2, Eye, FileText, Download } from 'lucide-react';
import '../../components/layout/AdminTable.css';

const Dokumen = () => {
  const documents = [
    { id: 'DOC-001', name: 'Pedoman Penulisan Skripsi V.2', category: 'Pedoman', year: '2023', status: 'Aktif', uploadDate: '12 Jan 2023' },
    { id: 'DOC-002', name: 'Alur Pengajuan Cuti Akademik', category: 'SOP', year: '2023', status: 'Aktif', uploadDate: '05 Feb 2023' },
    { id: 'DOC-003', name: 'Formulir Pendaftaran Seminar Proposal', category: 'Formulir', year: '2022', status: 'Aktif', uploadDate: '20 Nov 2022' },
    { id: 'DOC-004', name: 'Kalender Akademik 2023/2024', category: 'Informasi', year: '2023', status: 'Kedaluwarsa', uploadDate: '15 Jul 2023' },
    { id: 'DOC-005', name: 'Template Jurnal Tugas Akhir (Word)', category: 'Template', year: '2024', status: 'Aktif', uploadDate: '10 Jan 2024' },
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Aktif': return <span className="admin-status-badge success">Aktif</span>;
      case 'Kedaluwarsa': return <span className="admin-status-badge warning">Kedaluwarsa</span>;
      default: return null;
    }
  };

  return (
    <div className="admin-page-container">
      <div className="admin-page-header-row">
        <div className="admin-page-header">
          <h2>Dokumen Resmi</h2>
          <p className="subtitle">Kelola pedoman, SOP, formulir, dan dokumen resmi institusi.</p>
        </div>
        
        <div className="admin-header-actions">
          <div className="admin-search-input">
            <Search size={16} color="var(--text-muted)" />
            <input type="text" placeholder="Cari dokumen..." />
          </div>
          
          <button className="admin-filter-dropdown">
            <Filter size={16} /> Filter Kategori
          </button>
          
          <button className="admin-btn-primary">
            <Upload size={16} /> Upload Dokumen
          </button>
        </div>
      </div>

      <div className="admin-table-container">
        <table className="admin-table">
          <thead>
            <tr>
              <th><FileText size={16} style={{display:'inline', verticalAlign:'text-bottom', marginRight:'4px'}}/> Nama Dokumen</th>
              <th>Kategori</th>
              <th>Tahun</th>
              <th>Tanggal Upload</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {documents.map((doc) => (
              <tr key={doc.id}>
                <td><strong>{doc.name}</strong></td>
                <td>{doc.category}</td>
                <td>{doc.year}</td>
                <td>{doc.uploadDate}</td>
                <td>{getStatusBadge(doc.status)}</td>
                <td>
                  <div className="admin-table-actions">
                    <button className="action-btn" title="Preview"><Eye size={16} /></button>
                    <button className="action-btn" title="Download"><Download size={16} /></button>
                    <button className="action-btn" title="Edit"><Edit2 size={16} /></button>
                    <button className="action-btn delete" title="Hapus"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        <div className="admin-pagination">
          <span className="pagination-info">Menampilkan 1-5 dari 45 dokumen</span>
          <div className="pagination-controls">
            <button className="page-btn" disabled>&lt;</button>
            <button className="page-btn active">1</button>
            <button className="page-btn">2</button>
            <button className="page-btn">3</button>
            <button className="page-btn">&gt;</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dokumen;
