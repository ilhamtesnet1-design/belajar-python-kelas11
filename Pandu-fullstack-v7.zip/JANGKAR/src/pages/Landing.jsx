import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  MessageSquare, ShieldCheck, FileText, Send, BookOpen, Menu, X,
  Search, Quote, SearchX, ArrowRight, ChevronDown, ScanSearch, ListChecks,
} from 'lucide-react';
import { api, auth, loginUrl, mapCitation, mapDocument } from '../api/client';
import { AUTH_CONFIG } from '../config/uploads';
import PandaMascot from '../components/mascot/PandaMascot';
import './landing.css';
import BrandMark from '../components/brand/BrandMark';

const NAV = [
  { id: 'beranda', label: 'Beranda' },
  { id: 'cara-kerja', label: 'Cara Kerja' },
  { id: 'dokumen', label: 'Dokumen' },
  { id: 'faq', label: 'FAQ' },
];

/* Drawn from the documents in the registry, so a demo question has a real
   chance of matching an indexed passage. */
const SAMPLE_QUESTIONS = [
  'Apa syarat minimal SKS untuk mendaftar PKL?',
  'Berapa kali minimal bimbingan sebelum seminar TA?',
  'Kapan jadwal wisuda periode Desember?',
];

/* What actually happens between a question and an answer — the same stages
   as app/rag/pipeline.py on the backend. */
const STEPS = [
  {
    icon: MessageSquare,
    title: 'Pertanyaan masuk',
    short: 'Tulis dengan bahasa sehari-hari.',
    body: 'Mahasiswa UNP masuk dengan akunnya, lalu bertanya dengan bahasa sehari-hari. Percakapan tersimpan di akun, jadi bisa dilanjutkan dari HP atau laptop lain.',
  },
  {
    icon: Search,
    title: 'Mencari di dokumen resmi',
    short: 'Hanya dokumen yang terverifikasi dan masih berlaku.',
    body: 'Pertanyaan dicocokkan dengan potongan teks dari dokumen yang sudah divalidasi admin akademik. Dokumen yang menunggu validasi, dicabut, atau kedaluwarsa tidak ikut dicari.',
  },
  {
    icon: ScanSearch,
    title: 'Dua gerbang pemeriksaan',
    short: 'Relevan? Didukung teks sumber?',
    body: 'Gerbang pertama memastikan potongan yang ditemukan cukup mirip dengan pertanyaan. Gerbang kedua memastikan jawaban yang disusun benar-benar didukung teks sumber, bukan karangan model.',
  },
  {
    icon: ListChecks,
    title: 'Jawaban dan sitasi, atau penolakan',
    short: 'Sumber selalu bisa ditelusuri.',
    body: 'Lolos kedua gerbang: jawaban tampil bersama nama dokumen, pasal, halaman, dan kutipan aslinya. Tidak lolos: Pandu menyatakan informasinya tidak ditemukan dan mengarahkan ke unit akademik.',
  },
];

const FAQS = [
  {
    q: 'Apakah saya perlu akun untuk bertanya?',
    a: 'Ya. Pandu khusus untuk mahasiswa UNP, jadi daftar sekali dengan email lalu masuk. Nantinya pendaftaran akan memakai akun SSO UNP.',
  },
  {
    q: 'Dari mana Pandu mengambil jawaban?',
    a: 'Hanya dari dokumen resmi universitas yang sudah diverifikasi admin dan masih dalam masa berlaku. Daftarnya bisa dilihat di bagian Dokumen di halaman ini.',
  },
  {
    q: 'Bagaimana jika jawabannya tidak ada di dokumen?',
    a: 'Pandu akan mengatakan informasinya tidak ditemukan, alih-alih menebak. Untuk kasus seperti ini, hubungi unit akademik terkait.',
  },
  {
    q: 'Apakah pertanyaan saya disimpan?',
    a: 'Riwayat chat disimpan di akun Anda supaya bisa dibuka lagi dari perangkat lain — hanya Anda yang bisa melihatnya dan bisa dihapus kapan saja. Terpisah dari itu, pertanyaan dicatat untuk evaluasi mutu sistem tanpa nama, email, maupun alamat IP.',
  },
  {
    q: 'Apakah jawaban Pandu mengikat secara resmi?',
    a: 'Tidak. Pandu membantu menemukan ketentuan dalam dokumen resmi. Untuk keputusan akhir, selalu rujuk dokumen aslinya — tautan sumber disertakan di setiap jawaban — atau tanyakan ke unit akademik.',
  },
];

/* ---------------- Live demo ---------------- */

const LiveDemo = () => {
  const navigate = useNavigate();
  const [question, setQuestion] = useState('');
  const [asked, setAsked] = useState('');
  const [state, setState] = useState('idle'); // idle | loading | answer | refused | error
  const [result, setResult] = useState(null);
  const inputRef = useRef(null);

  const ask = async (text) => {
    const q = text.trim();
    if (q.length < 3 || state === 'loading') return;
    setAsked(q);
    setQuestion('');
    /* Asking is for signed-in UNP students: keep the question and bring it
       along through login, so nothing has to be typed twice. */
    if (AUTH_CONFIG.studentLoginRequired && !auth.isLoggedIn) {
      setState('login');
      return;
    }
    setState('loading');
    try {
      const res = await api('/api/chat/ask', { method: 'POST', body: { question: q } });
      setResult({ ...res, citations: (res.citations || []).map(mapCitation) });
      setState(res.refused ? 'refused' : 'answer');
    } catch (e) {
      const unreachable = e instanceof TypeError || /^Error 5\d\d$/.test(e.message);
      setResult({ error: unreachable ? 'Server Pandu sedang tidak bisa dihubungi.' : e.message });
      setState('error');
    }
  };

  const onSubmit = (e) => { e.preventDefault(); ask(question); };
  const cite = result?.citations?.[0];
  const answerText = result?.answer || '';
  const shortAnswer = answerText.length > 280 ? `${answerText.slice(0, 280).trimEnd()}…` : answerText;

  return (
    <div className="demo-card" aria-live="polite">
      <div className="demo-header">
        <span className="demo-dot" aria-hidden="true" />
        <span className="demo-title">Coba langsung</span>
        <span className="demo-tag">Terhubung ke dokumen resmi</span>
      </div>

      <div className="demo-body">
        {state === 'idle' && (
          <div className="demo-idle">
            <div className="demo-idle-head">
              <PandaMascot mood="welcome" size={64} />
              <p>Halo! Ketik pertanyaan akademik, atau pilih salah satu contoh:</p>
            </div>
            <div className="demo-chips">
              {SAMPLE_QUESTIONS.map(s => (
                <button key={s} type="button" className="demo-chip" onClick={() => ask(s)}>{s}</button>
              ))}
            </div>
          </div>
        )}

        {state !== 'idle' && (
          <div className="demo-user"><span>{asked}</span></div>
        )}

        {state === 'loading' && (
          <div className="demo-bot demo-thinking">
            <PandaMascot mood="searching" size={64} caption />
          </div>
        )}

        {state === 'answer' && (
          <div className="demo-bot">
            <BrandMark size={28} bare />
            <div className="demo-answer">
              <p>{shortAnswer}</p>
              {cite && (
                <div className="demo-cite">
                  <div className="demo-cite-head">
                    <FileText size={13} />
                    <strong>{cite.documentName}</strong>
                    <span className="demo-verified"><ShieldCheck size={11} /> Terverifikasi</span>
                  </div>
                  {cite.quote && (
                    <p className="demo-quote"><Quote size={11} /> {cite.quote.length > 160 ? `${cite.quote.slice(0, 160)}…` : cite.quote}</p>
                  )}
                  <div className="demo-cite-meta">
                    {cite.section && cite.section !== '-' && <span><BookOpen size={12} /> {cite.section}</span>}
                    <span><FileText size={12} /> Halaman {cite.page}</span>
                    {result.citations.length > 1 && <span>+{result.citations.length - 1} sumber lain</span>}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {state === 'refused' && (
          <div className="demo-bot">
            <PandaMascot mood="refused" size={48} />
            <div className="demo-answer demo-refusal">
              <strong>Informasi tidak ditemukan di dokumen resmi.</strong>
              <p>Inilah perilaku yang diinginkan: Pandu tidak menebak ketika tidak ada sumber yang mendukung.</p>
            </div>
          </div>
        )}

        {state === 'login' && (
          <div className="demo-bot">
            <PandaMascot mood="encourage" size={56} />
            <div className="demo-answer demo-login">
              <strong>Masuk dulu untuk mendapat jawaban.</strong>
              <p>Pandu khusus untuk mahasiswa UNP. Pertanyaan Anda akan langsung dijawab setelah masuk.</p>
              <div className="demo-login-actions">
                <Link to={loginUrl(`/assistant?q=${encodeURIComponent(asked)}`, 'daftar')} className="landing-btn primary">Daftar</Link>
                <Link to={loginUrl(`/assistant?q=${encodeURIComponent(asked)}`)} className="landing-btn outline">Sudah punya akun? Masuk</Link>
              </div>
            </div>
          </div>
        )}

        {state === 'error' && (
          <div className="demo-bot">
            <PandaMascot mood="error" size={48} />
            <div className="demo-answer demo-error"><p>{result?.error}</p></div>
          </div>
        )}
      </div>

      {(state === 'answer' || state === 'refused' || state === 'login') && (
        <div className="demo-followup">
          <button type="button" className="demo-link" onClick={() => navigate(`/assistant?q=${encodeURIComponent(asked)}`)}>
            Lanjutkan di Asisten <ArrowRight size={14} />
          </button>
          <button type="button" className="demo-link muted" onClick={() => { setState('idle'); setResult(null); inputRef.current?.focus(); }}>
            Coba pertanyaan lain
          </button>
        </div>
      )}

      <form className="demo-input" onSubmit={onSubmit}>
        <label htmlFor="demo-question" className="sr-only">Pertanyaan akademik</label>
        <input
          id="demo-question"
          ref={inputRef}
          type="text"
          placeholder="Tanyakan sesuatu tentang akademik…"
          value={question}
          maxLength={1000}
          onChange={e => setQuestion(e.target.value)}
          disabled={state === 'loading'}
        />
        <button type="submit" disabled={state === 'loading' || question.trim().length < 3} aria-label="Kirim pertanyaan">
          <Send size={16} />
        </button>
      </form>
    </div>
  );
};

/* ---------------- Page ---------------- */

const Landing = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('beranda');
  const [activeStep, setActiveStep] = useState(0);
  const [docs, setDocs] = useState([]);
  const [docsState, setDocsState] = useState('loading');
  /* FAQ is managed by admins; the built-in list only shows if the server is down. */
  const [faqs, setFaqs] = useState(FAQS);

  useEffect(() => {
    api('/api/faq')
      .then(rows => { if (rows.length) setFaqs(rows.slice(0, 6).map(r => ({ q: r.question, a: r.answer }))); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    api('/api/documents/public')
      .then(rows => { setDocs(rows.map(mapDocument)); setDocsState('ready'); })
      .catch(() => setDocsState('error'));
  }, []);

  /* Scroll-spy: highlight the nav item for the section in view. Content is
     visible regardless; this only moves the highlight. */
  useEffect(() => {
    const sections = NAV.map(n => document.getElementById(n.id)).filter(Boolean);
    if (!('IntersectionObserver' in window) || sections.length === 0) return undefined;
    const observer = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) setActiveSection(e.target.id); }),
      { rootMargin: '-45% 0px -50% 0px' },
    );
    sections.forEach(s => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  const go = (id) => (e) => {
    e.preventDefault();
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const onStepKey = (e) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); setActiveStep(s => (s + 1) % STEPS.length); }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); setActiveStep(s => (s - 1 + STEPS.length) % STEPS.length); }
  };

  /* Where "Mulai Bertanya" goes: straight in when signed in, otherwise
     registration first, then the dashboard. */
  const startPath = auth.isLoggedIn || !AUTH_CONFIG.studentLoginRequired
    ? (auth.isAdmin ? '/admin/dashboard' : '/dashboard')
    : loginUrl('/dashboard', 'daftar');

  const accountActions = auth.isLoggedIn ? (
    <Link to={auth.isAdmin ? '/admin/dashboard' : '/dashboard'} className="landing-btn primary">
      {auth.isAdmin ? 'Buka Panel Admin' : `Buka Pandu${auth.user?.name ? ` · ${auth.user.name.split(' ')[0]}` : ''}`}
    </Link>
  ) : (
    <>
      <Link to="/login" className="landing-btn outline">Masuk</Link>
      <Link to={loginUrl('/dashboard', 'daftar')} className="landing-btn primary">Daftar</Link>
    </>
  );

  const step = STEPS[activeStep];
  const StepIcon = step.icon;

  return (
    <div className="landing-layout">
      <header className="landing-header">
        <div className="landing-container header-inner">
          <a href="#beranda" className="landing-brand" onClick={go('beranda')}>
            <BrandMark size={38} />
            <span className="brand-text-stack">
              <span className="brand-title">Pandu</span>
              <span className="brand-subtitle">Asisten Layanan Akademik</span>
            </span>
          </a>

          <nav className={`header-nav${menuOpen ? ' is-open' : ''}`} aria-label="Navigasi utama">
            {NAV.map(n => (
              <a
                key={n.id}
                href={`#${n.id}`}
                className={`nav-link${activeSection === n.id ? ' active' : ''}`}
                aria-current={activeSection === n.id ? 'true' : undefined}
                onClick={go(n.id)}
              >
                {n.label}
              </a>
            ))}
            <div className="nav-mobile-actions">{accountActions}</div>
          </nav>

          <div className="landing-header-actions">{accountActions}</div>

          <button
            type="button"
            className="menu-toggle"
            aria-expanded={menuOpen}
            aria-label={menuOpen ? 'Tutup menu' : 'Buka menu'}
            onClick={() => setMenuOpen(o => !o)}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main>
        <section id="beranda" className="hero-section">
          <div className="landing-container hero-grid">
            <div className="hero-text-content">
              <span className="hero-badge">
                <ShieldCheck size={14} /> Jawaban dari dokumen resmi yang terverifikasi
              </span>
              <h1 className="hero-title">
                Temukan jawaban akademik dari <span className="hero-accent">sumber resmi</span> UNP
              </h1>
              <p className="hero-desc">
                Pandu menjawab pertanyaan akademik hanya dari peraturan dan pedoman kampus yang sudah divalidasi.
                Setiap jawaban menyertakan dokumen, pasal, dan halaman — dan bila sumbernya tidak ada, Pandu mengatakannya.
              </p>
              <div className="hero-cta-group">
                <button type="button" className="landing-btn primary lg" onClick={() => navigate(startPath)}>
                  <MessageSquare size={18} /> Mulai Bertanya
                </button>
                <a href="#cara-kerja" className="landing-btn outline lg" onClick={go('cara-kerja')}>
                  Lihat Cara Kerja
                </a>
              </div>

              <dl className="hero-stats">
                <div className="hero-stat-item">
                  <dt className="hero-stat-label">Dokumen resmi aktif</dt>
                  <dd className="hero-stat-value tabular">{docsState === 'ready' ? docs.length : '–'}</dd>
                </div>
                <div className="hero-stat-item">
                  <dt className="hero-stat-label">Setiap jawaban</dt>
                  <dd className="hero-stat-value small">Bersitasi</dd>
                </div>
                <div className="hero-stat-item">
                  <dt className="hero-stat-label">Tanpa sumber</dt>
                  <dd className="hero-stat-value small">Ditolak</dd>
                </div>
              </dl>
            </div>

            <div className="hero-visual-content">
              <LiveDemo />
            </div>
          </div>
        </section>

        <section className="why-section" aria-labelledby="why-heading">
          <div className="landing-container">
            <div className="section-header-centered">
              <span className="section-eyebrow">Mengapa Pandu</span>
              <h2 id="why-heading" className="section-heading">Jawaban yang bisa diperiksa ulang</h2>
            </div>
            <div className="benefits-grid">
              <article className="benefit-item">
                <span className="benefit-icon"><ShieldCheck size={20} /></span>
                <h3 className="benefit-title">Hanya sumber resmi</h3>
                <p className="benefit-desc">Dokumen baru dipakai setelah divalidasi admin akademik, dan otomatis berhenti dipakai ketika dicabut atau kedaluwarsa.</p>
              </article>
              <article className="benefit-item">
                <span className="benefit-icon"><Quote size={20} /></span>
                <h3 className="benefit-title">Sitasi sampai halaman</h3>
                <p className="benefit-desc">Nama dokumen, pasal, halaman, dan kutipan aslinya ditampilkan, lengkap dengan tautan ke PDF di halaman yang dikutip.</p>
              </article>
              <article className="benefit-item">
                <span className="benefit-icon"><SearchX size={20} /></span>
                <h3 className="benefit-title">Jujur ketika tidak tahu</h3>
                <p className="benefit-desc">Pertanyaan di luar dokumen dijawab “tidak ditemukan”, bukan dikarang. Lebih baik diarahkan ke unit akademik daripada diberi info keliru.</p>
              </article>
            </div>
          </div>
        </section>

        <section id="cara-kerja" className="how-it-works-section" aria-labelledby="how-heading">
          <div className="landing-container">
            <div className="section-header-centered">
              <span className="section-eyebrow">Cara kerja</span>
              <h2 id="how-heading" className="section-heading">Dari pertanyaan ke jawaban bersumber</h2>
              <p className="section-subheading">Pilih tiap tahap untuk melihat apa yang terjadi di baliknya.</p>
            </div>

            <div className="steps-layout">
              <div className="steps-list" role="tablist" aria-label="Tahap cara kerja" onKeyDown={onStepKey}>
                {STEPS.map((s, i) => {
                  const Icon = s.icon;
                  return (
                    <button
                      key={s.title}
                      type="button"
                      role="tab"
                      id={`step-tab-${i}`}
                      aria-selected={activeStep === i}
                      aria-controls="step-panel"
                      tabIndex={activeStep === i ? 0 : -1}
                      className={`step-tab${activeStep === i ? ' is-active' : ''}`}
                      onClick={() => setActiveStep(i)}
                    >
                      <span className="step-number tabular">{i + 1}</span>
                      <span className="step-tab-text">
                        <strong>{s.title}</strong>
                        <span>{s.short}</span>
                      </span>
                      <Icon size={18} className="step-tab-icon" aria-hidden="true" />
                    </button>
                  );
                })}
              </div>

              <div className="step-panel" role="tabpanel" id="step-panel" aria-labelledby={`step-tab-${activeStep}`}>
                <span className="step-panel-icon"><StepIcon size={26} /></span>
                <span className="eyebrow">Tahap {activeStep + 1} dari {STEPS.length}</span>
                <h3>{step.title}</h3>
                <p>{step.body}</p>
                <div className="step-panel-nav">
                  <button type="button" className="landing-btn outline" disabled={activeStep === 0} onClick={() => setActiveStep(s => s - 1)}>
                    Sebelumnya
                  </button>
                  {activeStep < STEPS.length - 1 ? (
                    <button type="button" className="landing-btn primary" onClick={() => setActiveStep(s => s + 1)}>
                      Tahap berikutnya <ArrowRight size={15} />
                    </button>
                  ) : (
                    <a href="#beranda" className="landing-btn primary" onClick={go('beranda')}>
                      Coba sekarang <ArrowRight size={15} />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="dokumen" className="docs-section" aria-labelledby="docs-heading">
          <div className="landing-container">
            <div className="section-header-centered">
              <span className="section-eyebrow">Cakupan</span>
              <h2 id="docs-heading" className="section-heading">Dokumen yang dipakai menjawab</h2>
              <p className="section-subheading">Daftar ini diambil langsung dari registri — hanya dokumen yang terverifikasi dan masih berlaku.</p>
            </div>

            {docsState === 'loading' && <p className="docs-note">Memuat daftar dokumen…</p>}
            {docsState === 'error' && <p className="docs-note">Daftar dokumen belum bisa dimuat. Coba muat ulang halaman.</p>}
            {docsState === 'ready' && docs.length === 0 && (
              <p className="docs-note">Belum ada dokumen yang diverifikasi. Admin akademik sedang menyiapkannya.</p>
            )}

            {docs.length > 0 && (
              <ul className="landing-docs">
                {docs.map(d => (
                  <li key={d.id}>
                    <Link to={`/document/${d.id}`} className="landing-doc">
                      <span className="landing-doc-icon"><FileText size={18} /></span>
                      <span className="landing-doc-text">
                        <strong>{d.name}</strong>
                        <span>{[d.category, d.version, d.pages ? `${d.pages} halaman` : null].filter(Boolean).join(' · ')}</span>
                        <span className="landing-doc-validity">{d.validity}</span>
                      </span>
                      <ArrowRight size={16} className="landing-doc-arrow" />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        <section id="faq" className="faq-section" aria-labelledby="faq-heading">
          <div className="landing-container faq-inner">
            <div className="section-header-centered">
              <span className="section-eyebrow">FAQ</span>
              <h2 id="faq-heading" className="section-heading">Pertanyaan yang sering muncul</h2>
            </div>
            <div className="landing-faq-list">
              {faqs.map((f, i) => (
                <details key={f.q} className="landing-faq-item" open={i === 0}>
                  <summary>
                    <span>{f.q}</span>
                    <ChevronDown size={18} className="landing-faq-chevron" aria-hidden="true" />
                  </summary>
                  <p>{f.a}</p>
                </details>
              ))}
            </div>
            <p className="landing-faq-more"><Link to="/faq">Lihat semua FAQ <ArrowRight size={14} /></Link></p>
          </div>
        </section>

        <section className="cta-band">
          <div className="landing-container cta-inner">
            <div>
              <h2>Punya pertanyaan akademik?</h2>
              <p>Masuk dengan akun mahasiswa UNP Anda dan tanyakan langsung.</p>
            </div>
            <button type="button" className="landing-btn accent lg" onClick={() => navigate(startPath)}>
              <MessageSquare size={18} /> Mulai Bertanya
            </button>
          </div>
        </section>
      </main>

      <footer className="landing-footer">
        <div className="landing-container footer-content">
          <div className="footer-brand">
            <span className="footer-logo">Pandu</span>
            <span className="footer-sub">Asisten Layanan Akademik · Universitas Negeri Padang · 2026</span>
          </div>
          <nav className="footer-links" aria-label="Tautan footer">
            <Link to="/documents">Dokumen</Link>
            <Link to="/help">Bantuan</Link>
            <Link to="/login?next=/admin/dashboard">Masuk Admin</Link>
          </nav>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
