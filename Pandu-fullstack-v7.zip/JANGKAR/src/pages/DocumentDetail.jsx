import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ExternalLink, Info } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import Button from '../components/common/Button';
import Card from '../components/common/Card';
import StatusBadge from '../components/common/StatusBadge';
import { api, mapDocument } from '../api/client';
import { LoadingState, ErrorState } from '../components/common/StateUI';
import './DocumentDetail.css';

const DocumentDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [iframeError, setIframeError] = useState(false);
  const [iframeLoading, setIframeLoading] = useState(true);

  const [doc, setDoc] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/api/documents/public')
      .then(rows => setDoc(rows.map(mapDocument).find(d => d.id === id) || null))
      .catch(() => setDoc(null))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <LoadingState message="Memuat detail dokumen…" />;

  if (!doc) {
    return (
      <ErrorState
        title="Dokumen Tidak Ditemukan"
        description="Dokumen ini mungkin sudah dicabut atau belum diverifikasi, sehingga tidak lagi tersedia untuk mahasiswa."
        onRetry={() => navigate('/documents')}
      />
    );
  }

  return (
    <div className="document-detail-page">
      <TopHeader
        title="Detail Dokumen"
        action={
          <Button variant="outline" icon={<ArrowLeft size={16} />} onClick={() => navigate('/documents')}>
            Kembali
          </Button>
        }
      />

      <div className="doc-detail-grid">
        <div className="doc-preview-column">
          <Card className="doc-preview-card" padding="none">
            {iframeLoading && !iframeError && (
              <div className="pdf-loading-overlay">
                <LoadingState message="Memuat PDF..." />
              </div>
            )}

            {iframeError ? (
              <ErrorState
                title="Gagal Memuat PDF"
                description="Dokumen PDF tidak dapat ditampilkan di browser ini."
                onRetry={() => window.open(doc.fileUrl, '_blank')}
              />
            ) : (
              <iframe
                className="pdf-iframe"
                src={`${doc.fileUrl}#toolbar=0`}
                title={doc.name}
                onLoad={() => setIframeLoading(false)}
                onError={() => {
                  setIframeError(true);
                  setIframeLoading(false);
                }}
              />
            )}
          </Card>
        </div>

        <div className="doc-info-column">
          <Card className="doc-meta-card">
            <h3 className="section-title">Metadata Dokumen</h3>
            <div className="meta-list">
              <div className="meta-item">
                <span className="meta-label">Status Verifikasi</span>
                <StatusBadge status={doc.status} />
              </div>
              <div className="meta-item">
                <span className="meta-label">Kategori</span>
                <span className="meta-value">{doc.category}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Versi</span>
                <span className="meta-value">{doc.version}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Masa Berlaku</span>
                <span className="meta-value">{doc.validity}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Total Halaman</span>
                <span className="meta-value">{doc.pages} Hal</span>
              </div>
            </div>

            <div className="doc-actions">
              <Button fullWidth onClick={() => window.open(doc.fileUrl, '_blank')} icon={<ExternalLink size={16} />}>
                Buka PDF di Tab Baru
              </Button>
            </div>
          </Card>

          <Card className="doc-usage-card">
            <div className="usage-header">
              <Info size={18} className="usage-icon" />
              <h3 className="usage-title">Digunakan sebagai sumber jawaban</h3>
            </div>
            <p className="usage-text">
              Dokumen ini terindeks secara resmi dan digunakan oleh Asisten Pandu untuk merespon pertanyaan terkait <strong>{doc.category}</strong>.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DocumentDetail;
