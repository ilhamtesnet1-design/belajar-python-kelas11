import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { FileText, ArrowLeft, ExternalLink, FileX2 } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import Button from '../components/common/Button';
import Card from '../components/common/Card';
import StatusBadge from '../components/common/StatusBadge';
import { api, mapDocument } from '../api/client';
import './SourceDetail.css';

const SourceDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  // Sitasi dikirim dari CitationCard lewat navigate(..., { state: { citation } })
  const citation = location.state?.citation || null;
  const [doc, setDoc] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/api/documents/public')
      .then(rows => setDoc(rows.map(mapDocument).find(d => d.id === String(id)) || null))
      .catch(() => setDoc(null))
      .finally(() => setLoading(false));
  }, [id]);

  /* Previously this returned null, so a slow fetch or a missing document
     both rendered a blank page with no explanation. */
  if (loading) {
    return (
      <div className="source-detail-page">
        <TopHeader title="Detail Sumber" />
        <div className="source-state" role="status">
          <span className="source-spinner" aria-hidden="true" />
          <p>Memuat dokumen sumber…</p>
        </div>
      </div>
    );
  }

  if (!doc) {
    return (
      <div className="source-detail-page">
        <TopHeader
          title="Detail Sumber"
          action={
            <Button variant="outline" icon={<ArrowLeft size={16} />} onClick={() => navigate(-1)}>
              Kembali
            </Button>
          }
        />
        <div className="source-state">
          <FileX2 size={36} color="var(--text-muted)" />
          <h3>Dokumen tidak ditemukan</h3>
          <p>
            Dokumen ini mungkin sudah dicabut atau masa berlakunya habis, sehingga tidak lagi
            dipakai sebagai sumber jawaban.
          </p>
          <Button onClick={() => navigate('/documents')}>Lihat daftar dokumen</Button>
        </div>
      </div>
    );
  }

  // Buka PDF langsung di halaman yang dikutip
  const pdfLink = citation ? `${doc.fileUrl}#page=${citation.page}` : doc.fileUrl;

  return (
    <div className="source-detail-page">
      <TopHeader 
        title="Detail Sumber" 
        action={
          <Button variant="outline" icon={<ArrowLeft size={16} />} onClick={() => navigate(-1)}>
            Kembali
          </Button>
        }
      />

      <div className="source-content-grid">
        <div className="source-main">
          <Card className="source-quote-card" padding="lg">
            <h3 className="section-title">Kutipan Sumber</h3>
            <div className="quote-container">
              {citation ? (
                <>
                  <p className="quote-text">
                    <span className="quote-highlight">{citation.quote}</span>
                  </p>
                  <div className="quote-meta">
                    Halaman {citation.page}
                  </div>
                </>
              ) : (
                <p>Bagian kutipan tidak ditemukan untuk simulasi ini.</p>
              )}
            </div>
            
            <div className="quote-actions">
              <Button 
                onClick={() => window.open(pdfLink, '_blank')}
                icon={<ExternalLink size={16} />}
              >
                Buka Dokumen PDF
              </Button>
            </div>
          </Card>
        </div>

        <div className="source-sidebar">
          <Card className="source-meta-card">
            <div className="doc-icon-large">
              <FileText size={32} />
            </div>
            <h2 className="doc-title-large">{doc.name}</h2>
            <StatusBadge status={doc.status} />
            
            <div className="meta-list">
              <div className="meta-item">
                <span className="meta-label">Kategori</span>
                <span className="meta-value">{doc.category}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Versi</span>
                <span className="meta-value">{doc.version}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Masa Berlaku</span>
                <span className="meta-value">{doc.validity}</span>
              </div>
              {citation && (
                <div className="meta-item highlight-item">
                  <span className="meta-label">Bagian Referensi</span>
                  <span className="meta-value">{citation.section}</span>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SourceDetail;
