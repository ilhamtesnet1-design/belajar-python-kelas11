import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Card } from '../../components/ui/Card';
import { Mail, Lock, LogIn, Shield, CheckCircle } from 'lucide-react';
import './LoginPage.css';

export const LoginPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    // Dummy login logic: if email contains admin, go to admin dashboard
    if (email.includes('admin')) {
      navigate('/admin');
    } else {
      navigate('/chat');
    }
  };

  return (
    <div className="login-page">
      <div className="login-split-left">
        <div className="login-info-content">
          <Link to="/" className="logo-link login-logo">
            <div className="logo-icon login-logo-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/></svg>
            </div>
            <div className="login-logo-text">
              <span className="logo-text-title">Pandu</span>
              <span className="logo-text-subtitle">Asisten Layanan Akademik</span>
            </div>
          </Link>

          <h1 className="login-hero-title">
            Akses Informasi Akademik Resmi UNP
          </h1>
          
          <p className="login-hero-subtitle">
            Masuk untuk mengajukan pertanyaan akademik dan mendapatkan jawaban berdasarkan dokumen resmi yang telah diverifikasi.
          </p>

          <div className="login-features">
            <div className="login-feature-item">
              <div className="login-feature-icon">
                <Shield size={20} />
              </div>
              <div className="login-feature-text">
                <h4>Dokumen Terverifikasi</h4>
                <p>Semua sumber telah melalui proses verifikasi resmi.</p>
              </div>
            </div>
            
            <div className="login-feature-item">
              <div className="login-feature-icon">
                <CheckCircle size={20} />
              </div>
              <div className="login-feature-text">
                <h4>Jawaban Bersitasi</h4>
                <p>Setiap jawaban dilengkapi referensi pasal dan halaman.</p>
              </div>
            </div>
            
            <div className="login-feature-item">
              <div className="login-feature-icon">
                <Shield size={20} />
              </div>
              <div className="login-feature-text">
                <h4>Transparan</h4>
                <p>Pandu menyatakan jika informasi tidak tersedia.</p>
              </div>
            </div>
          </div>
          
          <div className="login-footer-info">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>
            <span>Universitas Negeri Padang - Sistem Informasi Akademik</span>
          </div>
        </div>
      </div>

      <div className="login-split-right">
        <Card padding="lg" className="login-form-card">
          <div className="form-header">
            <div className="form-logo-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/></svg>
            </div>
            <span className="form-logo-text">Pandu</span>
          </div>
          
          <h2 className="form-title">Masuk ke Pandu</h2>
          <p className="form-subtitle">Gunakan akun akademik Anda untuk mengakses sistem.</p>
          
          <form className="login-form" onSubmit={handleLogin}>
            <Input 
              label="Email / Username" 
              type="text" 
              placeholder="contoh@student.unp.ac.id" 
              icon={<Mail size={16} />}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            
            <Input 
              label="Kata Sandi" 
              type="password" 
              placeholder="••••••••••••" 
              icon={<Lock size={16} />}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            
            <div className="form-options">
              <label className="remember-me">
                <input type="checkbox" defaultChecked />
                <span>Ingat saya</span>
              </label>
              <a href="#" className="forgot-password">Lupa kata sandi?</a>
            </div>
            
            <Button type="submit" variant="primary" fullWidth icon={<LogIn size={16} />}>
              Masuk
            </Button>
          </form>
          
          <div className="form-footer">
            <p>Belum memiliki akses?</p>
            <Button variant="outline" fullWidth>
              Hubungi Administrator
            </Button>
            <p className="secure-badge">
              <Shield size={12} /> Sistem dilindungi enkripsi dan autentikasi aman
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};
