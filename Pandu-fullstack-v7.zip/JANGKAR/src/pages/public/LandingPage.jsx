import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { ShieldCheck, BookOpen, Clock, FileText, Search, CheckCircle, Navigation } from 'lucide-react';
import './LandingPage.css';

export const LandingPage = () => {
  return (
    <div className="landing-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container hero-container">
          <Badge variant="default" className="hero-badge">
            <ShieldCheck size={14} className="badge-icon" />
            Jawaban berbasis dokumen resmi dan terverifikasi
          </Badge>
          
          <h1 className="hero-title">
            Temukan Jawaban Akademik dari Sumber Resmi UNP
          </h1>
          
          <p className="hero-subtitle">
            Pandu membantu mahasiswa menemukan informasi akademik berdasarkan dokumen resmi yang telah diverifikasi. Setiap jawaban dilengkapi sumber pasal dan halaman yang dapat ditelusuri.
          </p>
          
          <div className="hero-actions">
            <Link to="/chat">
              <Button variant="primary" size="lg">Mulai Bertanya</Button>
            </Link>
            <Link to="#cara-kerja">
              <Button variant="outline" size="lg" icon={<Navigation size={18} />}>Lihat Cara Kerja</Button>
            </Link>
          </div>
          
          <div className="hero-stats">
            <div className="stat-item">
              <h3 className="stat-value">64+</h3>
              <p className="stat-label">Dokumen Resmi</p>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <h3 className="stat-value">100%</h3>
              <p className="stat-label">Jawaban Bersumber</p>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <h3 className="stat-value">RAG</h3>
              <p className="stat-label">Teknologi Retrieval</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section" id="tentang">
        <div className="container">
          <div className="section-header">
            <span className="section-subtitle">MENGAPA PANDU?</span>
            <h2 className="section-title">Jawaban Akademik yang Dapat Dipercaya</h2>
            <p className="section-desc">
              Dirancang khusus untuk mahasiswa UNP yang membutuhkan informasi akademik akurat dan terverifikasi.
            </p>
          </div>
          
          <div className="features-grid">
            <Card padding="lg" className="feature-card">
              <div className="feature-icon-wrapper">
                <ShieldCheck size={24} className="feature-icon" />
                <span className="feature-number">01</span>
              </div>
              <h3 className="feature-title">Sumber Resmi</h3>
              <p className="feature-text">
                Jawaban hanya menggunakan dokumen yang telah diverifikasi oleh staf akademik Universitas Negeri Padang.
              </p>
            </Card>
            
            <Card padding="lg" className="feature-card primary-card">
              <div className="feature-icon-wrapper">
                <BookOpen size={24} className="feature-icon" />
                <span className="feature-number">02</span>
              </div>
              <h3 className="feature-title">Jawaban Bersitasi</h3>
              <p className="feature-text">
                Setiap jawaban menampilkan nama dokumen, nomor pasal, dan halaman sumber yang dapat langsung diperiksa.
              </p>
            </Card>
            
            <Card padding="lg" className="feature-card">
              <div className="feature-icon-wrapper">
                <CheckCircle size={24} className="feature-icon" />
                <span className="feature-number">03</span>
              </div>
              <h3 className="feature-title">Transparan</h3>
              <p className="feature-text">
                Jika informasi tidak ditemukan dalam dokumen resmi, Pandu akan menyatakan secara jelas bahwa jawaban tidak tersedia.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section className="how-it-works-section" id="cara-kerja">
        <div className="container">
          <div className="section-header">
            <span className="section-subtitle">CARA KERJA</span>
            <h2 className="section-title">Bagaimana Pandu Bekerja?</h2>
          </div>
          
          <div className="steps-container">
            <div className="step-item">
              <div className="step-icon-circle">
                <Search size={24} />
              </div>
              <span className="step-number badge badge-primary">01</span>
              <h4 className="step-title">Pertanyaan</h4>
              <p className="step-text">Mahasiswa mengajukan pertanyaan akademik</p>
            </div>
            <div className="step-connector"></div>
            
            <div className="step-item">
              <div className="step-icon-circle">
                <FileText size={24} />
              </div>
              <span className="step-number badge badge-primary">02</span>
              <h4 className="step-title">Pencarian Dokumen</h4>
              <p className="step-text">Sistem mencari di dokumen resmi yang terindeks</p>
            </div>
            <div className="step-connector"></div>
            
            <div className="step-item">
              <div className="step-icon-circle">
                <ShieldCheck size={24} />
              </div>
              <span className="step-number badge badge-warning">03</span>
              <h4 className="step-title">Verifikasi Bukti</h4>
              <p className="step-text">RAG memverifikasi relevansi dan keabsahan sumber</p>
            </div>
            <div className="step-connector"></div>
            
            <div className="step-item">
              <div className="step-icon-circle">
                <BookOpen size={24} />
              </div>
              <span className="step-number badge badge-success">04</span>
              <h4 className="step-title">Jawaban Bersitasi</h4>
              <p className="step-text">Jawaban diberikan lengkap dengan referensi sumber resmi</p>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Questions Section */}
      <section className="quick-questions-section">
        <div className="container">
          <div className="section-header">
            <span className="section-subtitle">PERTANYAAN YANG SERING DIAJUKAN</span>
            <h2 className="section-title">Mulai dengan Pertanyaan Ini</h2>
          </div>
          
          <div className="questions-grid">
            <Link to="/chat?q=prosedur-pengajuan-tugas-akhir" className="question-card">
              <BookOpen size={20} className="q-icon" />
              <span>Bagaimana prosedur pengajuan tugas akhir?</span>
              <Navigation size={16} className="q-arrow" />
            </Link>
            <Link to="/chat?q=batas-pendaftaran-wisuda" className="question-card">
              <Clock size={20} className="q-icon" />
              <span>Kapan batas pendaftaran wisuda?</span>
              <Navigation size={16} className="q-arrow" />
            </Link>
            <Link to="/chat?q=syarat-mengikuti-yudisium" className="question-card">
              <ShieldCheck size={20} className="q-icon" />
              <span>Apa syarat mengikuti yudisium?</span>
              <Navigation size={16} className="q-arrow" />
            </Link>
            <Link to="/chat?q=kalender-akademik" className="question-card">
              <FileText size={20} className="q-icon" />
              <span>Di mana saya dapat melihat kalender akademik?</span>
              <Navigation size={16} className="q-arrow" />
            </Link>
          </div>
        </div>
      </section>

      {/* Source Documents Section */}
      <section className="sources-section" id="dokumen">
        <div className="container">
          <div className="section-header">
            <span className="section-subtitle">DOKUMEN YANG DIGUNAKAN</span>
            <h2 className="section-title">Sumber Informasi Pandu</h2>
            <p className="section-desc">
              Semua jawaban diambil dari dokumen berikut yang telah diverifikasi dan dinyatakan berlaku.
            </p>
          </div>
          
          <div className="sources-grid">
            <Card className="source-doc-card">
              <div className="source-doc-header">
                <BookOpen size={20} className="source-doc-icon" />
                <Badge variant="success">Berlaku</Badge>
              </div>
              <h3 className="source-doc-title">Panduan Akademik</h3>
              <p className="source-doc-desc">Universitas Negeri Padang</p>
              <div className="source-doc-footer">
                <span className="source-doc-meta">Versi 2026</span>
                <Button variant="outline" size="sm">Lihat</Button>
              </div>
            </Card>
            
            <Card className="source-doc-card">
              <div className="source-doc-header">
                <Clock size={20} className="source-doc-icon" />
                <Badge variant="success">Berlaku</Badge>
              </div>
              <h3 className="source-doc-title">Kalender Akademik</h3>
              <p className="source-doc-desc">Tahun Akademik 2026/2027</p>
              <div className="source-doc-footer">
                <span className="source-doc-meta">Versi 2026</span>
                <Button variant="outline" size="sm">Lihat</Button>
              </div>
            </Card>
            
            <Card className="source-doc-card">
              <div className="source-doc-header">
                <FileText size={20} className="source-doc-icon" />
                <Badge variant="success">Berlaku</Badge>
              </div>
              <h3 className="source-doc-title">Panduan Tugas Akhir</h3>
              <p className="source-doc-desc">Pedoman Penulisan & Pengajuan TA/Skripsi</p>
              <div className="source-doc-footer">
                <span className="source-doc-meta">Versi 2026</span>
                <Button variant="outline" size="sm">Lihat</Button>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};
