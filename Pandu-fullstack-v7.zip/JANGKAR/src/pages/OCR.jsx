import React, { useState } from 'react';
import { Play, Copy, RefreshCw, FileText, ScanLine, FileCheck } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { EmptyState, ErrorState, LoadingState } from '../components/common/StateUI';
import { documents } from '../data/documents';
import { mockOCRData } from '../data/ocrData';
import './ocr.css';

const OCR = () => {
  const [selectedDocId, setSelectedDocId] = useState('');
  const [ocrState, setOcrState] = useState('INITIAL'); // INITIAL, PROCESSING, SUCCESS, ERROR
  
  const selectedDoc = documents.find(d => d.id === selectedDocId);

  const startOCR = () => {
    if (!selectedDocId) return;
    
    setOcrState('PROCESSING');
    
    // Simulate OCR processing time
    setTimeout(() => {
      // Randomly fail 10% of the time to show error state, but mostly succeed
      const isSuccess = Math.random() > 0.1;
      if (isSuccess) {
        setOcrState('SUCCESS');
      } else {
        setOcrState('ERROR');
      }
    }, 2500);
  };

  const resetOCR = () => {
    setOcrState('INITIAL');
    setSelectedDocId('');
  };

  const copyText = (text) => {
    navigator.clipboard.writeText(text);
    alert('Teks berhasil disalin!');
  };

  return (
    <div className="ocr-page">
      <TopHeader title="OCR Dokumen" />

      <div className="ocr-content-wrapper">
        
        {/* Page Hero Description */}
        <div className="ocr-hero">
          <div className="ocr-hero-icon bg-blue-tint">
            <ScanLine size={28} />
          </div>
          <div className="ocr-hero-text">
            <h1 className="ocr-hero-title">Studio Ekstraksi Teks (OCR)</h1>
            <p className="ocr-hero-subtitle">
              Pindai dokumen PDF konvensional dan esktrak seluruh teks yang terkandung di dalamnya ke dalam format data terstruktur. Modul ini menjadi pintu masuk pangkalan pengetahuan (knowledge base) asisten cerdas Pandu.
            </p>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="ocr-toolbar card-elevated">
          <div className="ocr-toolbar-left">
            <FileCheck size={20} className="toolbar-icon" />
            <h2 className="toolbar-title">Simulasi Pendaftaran Dokumen</h2>
          </div>
          <div className="ocr-toolbar-right">
            <div className="selector-group">
              <label htmlFor="doc-select" className="sr-only">Pilih Dokumen</label>
              <select 
                id="doc-select" 
                className="doc-select"
                value={selectedDocId}
                onChange={(e) => setSelectedDocId(e.target.value)}
                disabled={ocrState === 'PROCESSING'}
              >
                <option value="">-- Pilih dokumen untuk di pindai --</option>
                {documents.map(doc => (
                  <option key={doc.id} value={doc.id}>{doc.name}</option>
                ))}
              </select>
            </div>
            <Button 
              size="md" 
              onClick={startOCR} 
              disabled={!selectedDocId || ocrState === 'PROCESSING'}
              icon={<Play size={16} />}
            >
              Mulai OCR
            </Button>
          </div>
        </div>

        <div className="ocr-workspace">
          {/* Left Column: Preview */}
          <div className="ocr-column ocr-preview card-elevated">
            <div className="column-header">
              <h3 className="column-title">Penampil Dokumen</h3>
            </div>
            <div className="column-body preview-container">
              {!selectedDoc ? (
                <EmptyState 
                  icon={FileText}
                  title="Pratinjau Kosong"
                  description="Pilih dokumen pada bilah di atas untuk memuat tinjauan PDF."
                />
              ) : (
                <iframe 
                  src={`${selectedDoc.fileUrl}#toolbar=0`} 
                  title="PDF Preview"
                  className="pdf-preview-iframe"
                />
              )}
            </div>
          </div>

          {/* Right Column: Results */}
          <div className="ocr-column ocr-results card-elevated">
            <div className="column-header">
              <h3 className="column-title">Terminal Ekstraksi</h3>
            </div>
            <div className={`column-body results-container ${ocrState !== 'SUCCESS' ? 'centered-state' : ''}`}>
              
              {ocrState === 'INITIAL' && (
                <EmptyState 
                  title="Menunggu Perintah"
                  description="Klik tombol 'Mulai OCR' untuk memindai dokumen yang Anda pilih."
                />
              )}

              {ocrState === 'PROCESSING' && (
                <LoadingState message="Pemindaian karakter optik sedang berlangsung secara internal..." />
              )}

              {ocrState === 'ERROR' && (
                <ErrorState 
                  title="Integrasi Teks Gagal"
                  description="Sistem gagal mengenali pola karakter dokumen. Harap pastikan pdf dapat terbaca nalar optik."
                  onRetry={startOCR}
                />
              )}

              {ocrState === 'SUCCESS' && selectedDocId && mockOCRData[selectedDocId] && (
                <div className="ocr-success-view">
                  <div className="success-banner">Berhasil diproses dan dienkripsi ke database vektor.</div>
                  
                  <div className="ocr-stats-bar">
                    <div className="stat-item">
                      <span className="stat-value">{mockOCRData[selectedDocId].stats.chars}</span>
                      <span className="stat-label">Karakter</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-value">{mockOCRData[selectedDocId].stats.words}</span>
                      <span className="stat-label">Kata</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-value">{mockOCRData[selectedDocId].stats.paragraphs}</span>
                      <span className="stat-label">Paragraf</span>
                    </div>
                  </div>

                  <div className="text-processing-grid">
                    <div className="text-box-col">
                      <div className="text-box-header">
                        <h4>Raw Extracted Text</h4>
                        <button className="copy-btn" onClick={() => copyText(mockOCRData[selectedDocId].rawText)}>
                          <Copy size={13} /> Salin
                        </button>
                      </div>
                      <div className="text-box-content raw-text">
                        {mockOCRData[selectedDocId].rawText}
                      </div>
                    </div>
                    
                    <div className="text-box-col">
                      <div className="text-box-header">
                        <h4>Cleaned Information</h4>
                        <button className="copy-btn" onClick={() => copyText(mockOCRData[selectedDocId].processedText)}>
                          <Copy size={13} /> Salin
                        </button>
                      </div>
                      <div className="text-box-content processed-text">
                        {mockOCRData[selectedDocId].processedText}
                      </div>
                    </div>
                  </div>

                  <div className="ocr-actions">
                    <Button variant="outline" size="sm" onClick={resetOCR} icon={<RefreshCw size={14} />}>
                      Kosongkan Terminal
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default OCR;
