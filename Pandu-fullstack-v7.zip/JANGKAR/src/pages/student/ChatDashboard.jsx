import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Send, Paperclip, Anchor, BookOpen, ShieldCheck, Clock, FileText, Navigation, Phone, RefreshCcw } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { ChatBubbleUser, ChatBubbleSystem, SourceCitation, RefusalBanner } from '../../components/chat/ChatComponents';
import './ChatDashboard.css';

export const ChatDashboard = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const initialQuery = queryParams.get('q');
  
  const [inputValue, setInputValue] = useState('');
  const [chatState, setChatState] = useState('welcome'); // welcome, active, refusal

  useEffect(() => {
    if (initialQuery === 'syarat-yudisium') {
      setChatState('active');
    } else if (initialQuery === 'nilai-ipk') {
      setChatState('refusal');
    } else if (initialQuery) {
      setChatState('active'); // fallback
    } else {
      setChatState('welcome');
    }
  }, [initialQuery]);

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    
    // Dummy logic to simulate different states
    if (inputValue.toLowerCase().includes('ipk') || inputValue.toLowerCase().includes('nilai')) {
      navigate('/chat?q=nilai-ipk');
    } else {
      navigate('/chat?q=syarat-yudisium');
    }
    setInputValue('');
  };

  const renderWelcomeState = () => (
    <div className="chat-welcome">
      <div className="welcome-logo">
        <div className="welcome-logo-icon">
          <Anchor size={32} />
        </div>
      </div>
      
      <h2 className="welcome-title">Selamat datang di Pandu</h2>
      <p className="welcome-subtitle">Ajukan pertanyaan seputar layanan dan aturan akademik UNP.</p>
      
      <div className="welcome-badges">
        <span className="welcome-badge"><ShieldCheck size={14} /> Dokumen Resmi</span>
        <span className="welcome-badge"><BookOpen size={14} /> Berbasis Sumber Terverifikasi</span>
        <span className="welcome-badge"><FileText size={14} /> Universitas Negeri Padang</span>
      </div>
      
      <div className="quick-prompts-container">
        <p className="quick-prompts-label">Pertanyaan yang sering diajukan</p>
        <div className="quick-prompts-grid">
          <button className="quick-prompt-btn" onClick={() => navigate('/chat?q=syarat-yudisium')}>
            <MessageIcon />
            <span>Bagaimana syarat yudisium?</span>
            <Navigation size={14} className="qp-arrow" />
          </button>
          <button className="quick-prompt-btn" onClick={() => navigate('/chat?q=syarat-tugas-akhir')}>
            <MessageIcon />
            <span>Apa persyaratan tugas akhir?</span>
            <Navigation size={14} className="qp-arrow" />
          </button>
          <button className="quick-prompt-btn" onClick={() => navigate('/chat?q=jadwal-wisuda')}>
            <MessageIcon />
            <span>Kapan jadwal wisuda 2026?</span>
            <Navigation size={14} className="qp-arrow" />
          </button>
          <button className="quick-prompt-btn" onClick={() => navigate('/chat?q=prosedur-tugas-akhir')}>
            <MessageIcon />
            <span>Prosedur pengajuan tugas akhir?</span>
            <Navigation size={14} className="qp-arrow" />
          </button>
        </div>
      </div>
    </div>
  );

  const renderActiveState = () => (
    <div className="chat-active">
      <div className="chat-date-divider">
        <span>Hari ini</span>
      </div>
      
      <ChatBubbleUser message="Bagaimana syarat yudisium?" />
      
      <ChatBubbleSystem>
        <p>Berdasarkan dokumen resmi yang tersedia, mahasiswa yang akan mengikuti yudisium harus memenuhi persyaratan akademik dan administratif sesuai ketentuan yang berlaku di Universitas Negeri Padang.</p>
        
        <div className="citation-summary">
          <FileText size={14} />
          <span>Jawaban ini dibuat berdasarkan 2 sumber dokumen resmi.</span>
          <button className="expand-citations-btn">
            Lihat bukti <ChevronDown size={14} />
          </button>
        </div>
        
        <div className="citations-list">
          <p className="citations-label">SUMBER REFERENSI</p>
          <SourceCitation 
            title="Panduan Akademik Fakultas Teknik UNP"
            article="Pasal 12, Ayat 3"
            page="24-25"
            version="2026"
          />
          <SourceCitation 
            title="Peraturan Akademik UNP No. 4 Tahun 2024"
            article="Pasal 8"
            page="17"
          />
        </div>
      </ChatBubbleSystem>
    </div>
  );

  const renderRefusalState = () => (
    <div className="chat-active">
      <ChatBubbleUser message="Berapa nilai IPK saya saat ini?" />
      
      <ChatBubbleSystem>
        <p>Maaf, Pandu tidak dapat menjawab pertanyaan tersebut karena informasi yang dibutuhkan tidak tersedia dalam dokumen resmi yang terverifikasi.</p>
        
        <RefusalBanner />
        
        <div className="citation-summary">
          <ShieldCheck size={14} />
          <span>Pandu hanya menjawab berdasarkan sumber resmi yang tersedia dan terverifikasi.</span>
        </div>
        
        <div className="refusal-actions">
          <Button variant="primary" icon={<Phone size={14} />}>Lihat Kontak Akademik</Button>
          <Button variant="outline" icon={<RefreshCcw size={14} />} onClick={() => navigate('/chat')}>Ubah Pertanyaan</Button>
        </div>
        
        <Card className="refusal-suggestions" padding="sm">
          <div className="suggestions-header">
            <InfoIcon />
            <span>Apa yang bisa ditanyakan ke Pandu?</span>
          </div>
          <ul className="suggestions-list">
            <li><CheckIcon /> Prosedur dan syarat akademik (yudisium, tugas akhir, dll)</li>
            <li><CheckIcon /> Aturan kehadiran, nilai, dan perkuliahan</li>
            <li><CheckIcon /> Kalender akademik dan jadwal wisuda</li>
            <li><CheckIcon /> Persyaratan administrasi perkuliahan</li>
          </ul>
        </Card>
      </ChatBubbleSystem>
    </div>
  );

  return (
    <div className="chat-dashboard-container">
      <div className="chat-history-area">
        <div className="chat-history-inner">
          {chatState === 'welcome' && renderWelcomeState()}
          {chatState === 'active' && renderActiveState()}
          {chatState === 'refusal' && renderRefusalState()}
        </div>
      </div>
      
      <div className="chat-input-area">
        <div className="chat-input-inner">
          <form className="chat-input-form" onSubmit={handleSendMessage}>
            <button type="button" className="attach-btn">
              <Paperclip size={20} />
            </button>
            <input 
              type="text" 
              className="chat-input-field" 
              placeholder="Tanyakan sesuatu tentang akademik..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
            />
            <div className="chat-input-actions">
              <span className="enter-hint">Tekan Enter untuk kirim</span>
              <button 
                type="submit" 
                className={`send-btn ${inputValue.trim() ? 'active' : ''}`}
                disabled={!inputValue.trim()}
              >
                <Send size={18} />
              </button>
            </div>
          </form>
          <p className="chat-disclaimer">
            Pandu hanya menjawab berdasarkan dokumen resmi yang terverifikasi oleh administrator.
          </p>
        </div>
      </div>
    </div>
  );
};

// Helper components for icons
const MessageIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: 'var(--primary)'}}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
const ChevronDown = ({size}) => <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>;
const InfoIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: 'var(--primary)'}}><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>;
const CheckIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: 'var(--success)'}}><polyline points="20 6 9 17 4 12"/></svg>;
