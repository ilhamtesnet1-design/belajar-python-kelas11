import React, { useEffect, useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import { api } from '../api/client';
import './faq.css';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  const [faqs, setFaqs] = useState([]);
  const [state, setState] = useState('loading');

  /* Managed by admin on the FAQ page of the admin panel. */
  useEffect(() => {
    api('/api/faq')
      .then(rows => { setFaqs(rows); setState('ready'); })
      .catch(() => setState('error'));
  }, []);

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="faq-page">
      <TopHeader title="FAQ" />
      
      <div className="faq-content">
        <div className="faq-header-text">
          <h2 className="faq-page-title">Pertanyaan yang Sering Diajukan</h2>
          <p className="faq-page-subtitle">Pahami lebih lanjut tentang cara kerja dan informasi ketersediaan layanan pada sistem Pandu.</p>
        </div>

        {state === 'loading' && <p className="faq-page-subtitle">Memuat FAQ…</p>}
        {state === 'error' && <p className="faq-page-subtitle">FAQ belum bisa dimuat. Pastikan server Pandu berjalan, lalu muat ulang halaman.</p>}
        {state === 'ready' && faqs.length === 0 && <p className="faq-page-subtitle">Belum ada FAQ.</p>}
        <div className="faq-list">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div key={faq.id} className={`faq-item ${isOpen ? 'open' : ''}`}>
                <button
                  type="button"
                  className="faq-question-btn" 
                  onClick={() => toggleFAQ(index)}
                  aria-expanded={isOpen}
                >
                  <span className="faq-question-text">{faq.question}</span>
                  {isOpen ? (
                    <ChevronUp size={20} className="faq-icon" />
                  ) : (
                    <ChevronDown size={20} className="faq-icon" />
                  )}
                </button>
                
                {isOpen && (
                  <div className="faq-answer">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FAQ;
