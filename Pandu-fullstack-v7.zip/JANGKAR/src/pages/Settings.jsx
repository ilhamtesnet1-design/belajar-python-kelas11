import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Trash2, MessageSquare, Check, User, FileText, AlertCircle, ExternalLink, UserX } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import { api, auth, privateFileUrl } from '../api/client';
import { formatBytes } from '../config/uploads';
import { formatWhen, parseServerDate } from '../utils/time';
import { deleteAllConversations, listConversations } from '../api/history';
import './settings.css';

const hoursLeft = (expires) => {
  const d = parseServerDate(expires);
  if (!d) return null;
  return Math.max(0, Math.round((d.getTime() - Date.now()) / 3600000));
};

const Notice = ({ notice }) => (notice ? (
  <p className={`student-settings-notice ${notice.tone}`} role="status">
    {notice.tone === 'success' ? <Check size={14} /> : <AlertCircle size={14} />} {notice.text}
  </p>
) : null);

const Settings = () => {
  const navigate = useNavigate();
  const [delPw, setDelPw] = useState('');
  const [delNotice, setDelNotice] = useState(null);
  const [history, setHistory] = useState([]);
  const [cleared, setCleared] = useState(false);

  const [me, setMe] = useState(auth.user);
  const [name, setName] = useState(auth.user?.name || '');
  const [profileNotice, setProfileNotice] = useState(null);
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [pwNotice, setPwNotice] = useState(null);
  const [saving, setSaving] = useState(false);

  const [docs, setDocs] = useState([]);
  const [docsState, setDocsState] = useState('loading');

  const loadDocs = () => api('/api/my-documents')
    .then(rows => { setDocs(rows); setDocsState('ready'); })
    .catch(() => setDocsState('error'));

  useEffect(() => {
    api('/api/auth/me').then(u => { setMe(u); setName(u.name); }).catch(() => {});
    loadDocs();
    listConversations().then(setHistory).catch(() => {});
  }, []);

  const messageCount = history.reduce((n, c) => n + (c.message_count || 0), 0);

  const clearHistory = async () => {
    if (!window.confirm(`Hapus ${history.length} percakapan dari akun Anda, di semua perangkat? Tindakan ini tidak bisa dibatalkan.`)) return;
    try {
      await deleteAllConversations();
      setHistory([]);
      setCleared(true);
    } catch (e) {
      window.alert(e.message);
    }
  };

  const saveProfile = async (e) => {
    e.preventDefault();
    if (saving || name.trim().length < 2) return;
    setSaving(true);
    setProfileNotice(null);
    try {
      const u = await api('/api/auth/me', { method: 'PATCH', body: { name: name.trim() } });
      setMe(u);
      auth.set(auth.token, u);
      setProfileNotice({ tone: 'success', text: 'Nama tersimpan.' });
    } catch (err) {
      setProfileNotice({ tone: 'error', text: err.message });
    } finally {
      setSaving(false);
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    if (saving) return;
    if (pw.next.length < 8) { setPwNotice({ tone: 'error', text: 'Kata sandi baru minimal 8 karakter.' }); return; }
    if (pw.next !== pw.confirm) { setPwNotice({ tone: 'error', text: 'Konfirmasi kata sandi tidak sama.' }); return; }
    setSaving(true);
    setPwNotice(null);
    try {
      await api('/api/auth/password', { method: 'POST', body: { current_password: pw.current, new_password: pw.next } });
      setPw({ current: '', next: '', confirm: '' });
      setPwNotice({ tone: 'success', text: 'Kata sandi diganti.' });
    } catch (err) {
      setPwNotice({ tone: 'error', text: err.message });
    } finally {
      setSaving(false);
    }
  };

  const removeDoc = async (doc) => {
    if (!window.confirm(`Hapus “${doc.name}” dari server sekarang?`)) return;
    try {
      await api(`/api/my-documents/${doc.id}`, { method: 'DELETE' });
      loadDocs();
    } catch (e) {
      window.alert(e.message);
    }
  };

  const setPwField = k => e => setPw({ ...pw, [k]: e.target.value });

  /* Required by Google Play and the App Store for apps with accounts. */
  const deleteAccount = async (e) => {
    e.preventDefault();
    if (!delPw) { setDelNotice({ tone: 'error', text: 'Masukkan kata sandi untuk konfirmasi.' }); return; }
    if (!window.confirm('Hapus akun beserta seluruh riwayat chat dan PDF Anda? Tindakan ini tidak bisa dibatalkan.')) return;
    try {
      await api('/api/auth/me', { method: 'DELETE', body: { password: delPw } });
      auth.clear();
      navigate('/', { replace: true });
    } catch (err) {
      setDelNotice({ tone: 'error', text: err.message });
    }
  };

  return (
    <div className="student-settings">
      <TopHeader title="Pengaturan" />

      <div className="student-settings-body">
        <section className="student-settings-card">
          <header>
            <User size={20} />
            <div>
              <h2>Akun</h2>
              <p>Dipakai untuk masuk dan menyimpan riwayat chat Anda.</p>
            </div>
          </header>
          <form className="student-settings-form" onSubmit={saveProfile}>
            <div className="student-settings-field">
              <label htmlFor="s-name">Nama</label>
              <input id="s-name" className="form-input" value={name} onChange={e => setName(e.target.value)} />
            </div>
            <div className="student-settings-field">
              <label htmlFor="s-email">Email</label>
              <input id="s-email" className="form-input" value={me?.email || ''} readOnly />
            </div>
            <div className="student-settings-actions">
              <Notice notice={profileNotice} />
              <button type="submit" className="student-settings-primary" disabled={saving || name.trim().length < 2}>Simpan nama</button>
            </div>
          </form>

          <form className="student-settings-form" onSubmit={savePassword}>
            <h3>Ganti kata sandi</h3>
            <div className="student-settings-grid">
              <div className="student-settings-field">
                <label htmlFor="s-pw">Kata sandi saat ini</label>
                <input id="s-pw" type="password" className="form-input" autoComplete="current-password" value={pw.current} onChange={setPwField('current')} />
              </div>
              <div className="student-settings-field">
                <label htmlFor="s-pw-new">Kata sandi baru</label>
                <input id="s-pw-new" type="password" className="form-input" autoComplete="new-password" value={pw.next} onChange={setPwField('next')} />
              </div>
              <div className="student-settings-field">
                <label htmlFor="s-pw-confirm">Ulangi kata sandi baru</label>
                <input id="s-pw-confirm" type="password" className="form-input" autoComplete="new-password" value={pw.confirm} onChange={setPwField('confirm')} />
              </div>
            </div>
            <div className="student-settings-actions">
              <Notice notice={pwNotice} />
              <button type="submit" className="student-settings-primary" disabled={saving || !pw.current || !pw.next}>Ganti kata sandi</button>
            </div>
          </form>
        </section>

        <section className="student-settings-card">
          <header>
            <FileText size={20} />
            <div>
              <h2>PDF yang Anda unggah</h2>
              <p>Hanya Anda yang bisa melihat dan menanyakannya. Dihapus otomatis setelah beberapa hari, atau hapus sekarang.</p>
            </div>
          </header>
          {docsState === 'loading' && <p className="student-settings-muted">Memuat…</p>}
          {docsState === 'error' && <p className="student-settings-muted">Daftar dokumen belum bisa dimuat.</p>}
          {docsState === 'ready' && docs.length === 0 && (
            <p className="student-settings-muted">Belum ada. Lampirkan PDF lewat tombol klip di halaman Chat untuk menanyakan isinya.</p>
          )}
          {docs.length > 0 && (
            <ul className="student-docs">
              {docs.map(d => {
                const left = hoursLeft(d.expires_at);
                return (
                  <li key={d.id}>
                    <FileText size={18} />
                    <div className="student-docs-text">
                      <strong>{d.name}</strong>
                      <span>
                        {formatBytes(d.size_bytes)}{d.pages ? ` · ${d.pages} hlm` : ''} · diunggah {formatWhen(d.created_at)}
                        {left !== null && ` · terhapus dalam ${left >= 24 ? `${Math.round(left / 24)} hari` : `${left} jam`}`}
                      </span>
                      {d.ingest_status === 'gagal' && <span className="student-docs-error">{d.ingest_error}</span>}
                    </div>
                    <button type="button" className="student-docs-btn" onClick={() => window.open(privateFileUrl(d.id), '_blank', 'noopener')} title="Buka PDF">
                      <ExternalLink size={15} />
                    </button>
                    <button type="button" className="student-docs-btn danger" onClick={() => removeDoc(d)} title="Hapus sekarang">
                      <Trash2 size={15} />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="student-settings-card">
          <header>
            <MessageSquare size={20} />
            <div>
              <h2>Riwayat percakapan</h2>
              <p>Tersimpan di akun Anda, jadi bisa dibuka lagi dari HP atau laptop lain. Hanya Anda yang bisa melihatnya.</p>
            </div>
          </header>
          <dl className="student-settings-stats">
            <div><dt>Percakapan</dt><dd className="tabular">{history.length}</dd></div>
            <div><dt>Pesan</dt><dd className="tabular">{messageCount}</dd></div>
          </dl>
          <div className="student-settings-actions">
            {cleared && <span className="student-settings-done"><Check size={14} /> Riwayat dihapus</span>}
            <button type="button" className="student-settings-danger" onClick={clearHistory} disabled={history.length === 0}>
              <Trash2 size={16} /> Hapus semua riwayat
            </button>
          </div>
        </section>

        <section className="student-settings-card is-danger">
          <header>
            <UserX size={20} />
            <div>
              <h2>Hapus akun</h2>
              <p>Menghapus akun, seluruh riwayat chat, dan PDF yang Anda unggah secara permanen.</p>
            </div>
          </header>
          <form className="student-settings-form" onSubmit={deleteAccount}>
            <div className="student-settings-field">
              <label htmlFor="s-del-pw">Kata sandi untuk konfirmasi</label>
              <input id="s-del-pw" type="password" className="form-input" autoComplete="current-password" value={delPw} onChange={e => setDelPw(e.target.value)} />
            </div>
            <div className="student-settings-actions">
              <Notice notice={delNotice} />
              <button type="submit" className="student-settings-danger"><UserX size={16} /> Hapus akun saya</button>
            </div>
          </form>
        </section>

        <section className="student-settings-card">
          <header>
            <ShieldCheck size={20} />
            <div>
              <h2>Privasi</h2>
              <p>Apa yang disimpan Pandu:</p>
            </div>
          </header>
          <ul className="student-settings-list">
            <li><strong>Akun:</strong> nama, email, dan kata sandi terenkripsi.</li>
            <li><strong>Riwayat chat:</strong> disimpan di akun Anda agar bisa dibuka di perangkat lain. Hanya Anda yang bisa melihatnya; hapus per percakapan di halaman Riwayat, atau semuanya di atas.</li>
            <li><strong>Catatan evaluasi:</strong> pertanyaan tentang dokumen resmi juga dicatat terpisah untuk menilai mutu jawaban — catatan ini <em>tanpa</em> nama, email, atau alamat IP.</li>
            <li><strong>PDF Anda:</strong> hanya bisa diakses akun Anda, tidak masuk catatan evaluasi, dan dihapus otomatis setelah beberapa hari.</li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default Settings;
