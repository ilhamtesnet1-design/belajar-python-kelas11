import React from 'react';
import { LifeBuoy } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import './help.css';

const Help = () => {
  return (
    <div className="help-page">
      <TopHeader title="Bantuan" />
      
      <div className="help-content">
        <div className="help-header-text">
          <h2 className="help-page-title">Pusat Bantuan Pandu</h2>
          <p className="help-page-subtitle">Punya masalah saat menggunakan sistem? Tim kami siap membantu Anda.</p>
        </div>

        <div className="help-grid">
          {/* Main Troubleshooting Section */}
          <div className="help-main-column">
            <Card className="help-guide-card">
              <h3 className="help-section-title">Panduan Cepat</h3>
              
              <div className="guide-step">
                <div className="step-circle">1</div>
                <div className="step-text">
                  <h4>Pastikan Koneksi Anda Stabil</h4>
                  <p>Meskipun simulasi saat ini berjalan di sisi frontend, lingkungan produksi mensyaratkan koneksi solid untuk berkomunikasi dengan model AI.</p>
                </div>
              </div>

              <div className="guide-step">
                <div className="step-circle">2</div>
                <div className="step-text">
                  <h4>Gunakan Bahasa Akademik (Formal)</h4>
                  <p>Sistem merespons paling optimal terhadap pertanyaan yang terstruktur dengan subjek yang jelas, mirip dengan yang tertera di dokumen.</p>
                </div>
              </div>

              <div className="guide-step">
                <div className="step-circle">3</div>
                <div className="step-text">
                  <h4>Periksa Menu Dokumen</h4>
                  <p>Jika jawaban asisten terasa kurang menyentuh substansi spesifik fakultas, Anda dapat membaca manual PDF secara menyeluruh di menu Dokumen Resmi.</p>
                </div>
              </div>
            </Card>

            <div className="help-support-block">
              <h3 className="help-section-title">Hubungi Tim Layanan Akademik</h3>
              <p className="support-desc">
                Apakah Pandu memberikan informasi yang keliru? Silakan mengirim keluhan langsung ke divisi pelayanan administratif kampus.
              </p>
              <form className="support-form" onSubmit={(e) => e.preventDefault()}>
                <div className="form-group-help">
                  <label htmlFor="issue">Pilih Kategori Masalah</label>
                  <select id="issue" className="help-input">
                    <option>Sistem Error</option>
                    <option>Informasi Dokumen Tidak Akurat</option>
                    <option>Dokumen Tidak Ditemukan</option>
                    <option>Masalah Akun Layanan</option>
                  </select>
                </div>
                <div className="form-group-help">
                  <label htmlFor="desc">Jelaskan Kendala Anda</label>
                  <textarea id="desc" rows={4} className="help-input" placeholder="Tuliskan secara ringkas kendala yang dikeluhkan..."></textarea>
                </div>
                <Button size="md" type="submit" className="submit-ticket-btn">
                  Kirim Laporan
                </Button>
              </form>
            </div>
          </div>

          {/* Sidebar Contact Section */}
          <div className="help-side-column">
            <Card className="contact-card">
              <div className="contact-icon-wrapper">
                <LifeBuoy size={24} />
              </div>
              <h3>Layanan Akademik UNP</h3>
              <p>Senin–Jumat, 07.30–16.00 WIB</p>
            </Card>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Help;
