import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MessageSquare, ArrowRight } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import DocumentCard from '../components/document/DocumentCard';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { api, mapDocument } from '../api/client';
import { listConversations } from '../api/history';
import './dashboard.css';

const Dashboard = () => {
  const [query, setQuery] = useState('');
  const [documents, setDocuments] = useState([]);
  const [docsState, setDocsState] = useState('loading');
  const navigate = useNavigate();

  /* Same public list the Documents page uses, so every card opens a document
     the detail page can actually find. */
  useEffect(() => {
    api('/api/documents/public')
      .then(rows => { setDocuments(rows.map(mapDocument)); setDocsState('ready'); })
      .catch(() => setDocsState('error'));
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/assistant?q=${encodeURIComponent(query)}`);
    }
  };

  const suggestedQuestions = [
    'Apa syarat minimal SKS untuk mendaftar PKL?',
    'Berapa kali minimal bimbingan sebelum seminar Tugas Akhir?',
    'Siapa yang memvalidasi naskah laporan Tugas Akhir?',
    'Bagaimana prosedur pengajuan PKL?',
  ];

  /* Most recent conversations from the account, to pick up where they left off. */
  const [recentChats, setRecentChats] = useState([]);
  useEffect(() => {
    listConversations().then(rows => setRecentChats(rows.slice(0, 3))).catch(() => {});
  }, []);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) handleSearch(e);
  };

  return (
    <div className="dashboard-page">
      <TopHeader title="Selamat datang di Pandu" />

      <div className="dashboard-content">
        <p className="dashboard-intro">
          Temukan informasi akademik dari dokumen resmi kampus.
        </p>

        <section className="dashboard-main-section">
          <Card padding="lg" className="primary-question-card">
            <h2 className="question-card-title">Apa yang ingin kamu tanyakan?</h2>
            
            <form onSubmit={handleSearch} className="question-form">
              <textarea
                className="question-textarea"
                placeholder="Tanyakan sesuatu tentang layanan atau aturan akademik..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={4}
              />
              <span className="question-hint">Enter untuk bertanya · Shift+Enter untuk baris baru</span>
              <div className="form-actions">
                <Button type="submit" size="md" disabled={!query.trim()}>
                  Tanyakan
                </Button>
              </div>
            </form>
          </Card>
        </section>

        {recentChats.length > 0 && (
          <section className="dashboard-recent">
            <h3 className="section-subtitle">Lanjutkan percakapan</h3>
            <ul className="recent-list">
              {recentChats.map(chat => (
                <li key={chat.id}>
                  <Link to={`/assistant?chatId=${chat.id}`} className="recent-item">
                    <MessageSquare size={16} />
                    <span className="recent-title">{chat.title}</span>
                    <span className="recent-count tabular">{chat.message_count} pesan</span>
                    <ArrowRight size={14} className="recent-arrow" />
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="dashboard-suggestions">
          <h3 className="section-subtitle">Pertanyaan yang sering diajukan</h3>
          <div className="suggestions-grid">
            {suggestedQuestions.map((q, idx) => (
              <Card 
                key={idx} 
                className="suggestion-card" 
                onClick={() => navigate(`/assistant?q=${encodeURIComponent(q)}`)}
                padding="md"
              >
                {q}
              </Card>
            ))}
          </div>
        </section>

        <section className="dashboard-docs-section">
          <h3 className="section-subtitle">Dokumen Resmi</h3>
          {docsState === 'loading' && <p className="docs-state">Memuat dokumen resmi…</p>}
          {docsState === 'error' && (
            <p className="docs-state">Daftar dokumen belum bisa dimuat. Pastikan server Pandu berjalan.</p>
          )}
          {docsState === 'ready' && documents.length === 0 && (
            <p className="docs-state">Belum ada dokumen yang diverifikasi.</p>
          )}
          <div className="docs-grid">
            {documents.slice(0, 3).map(doc => (
              <DocumentCard key={doc.id} document={doc} />
            ))}
          </div>
          {documents.length > 3 && (
            <Link to="/documents" className="docs-more">Lihat semua {documents.length} dokumen</Link>
          )}
        </section>
      </div>
    </div>
  );
};

export default Dashboard;
