import React, { useState, useEffect } from 'react';
import { Search, Filter, BookOpen, Database, RefreshCw } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import DocumentCard from '../components/document/DocumentCard';
import { EmptyState } from '../components/common/StateUI';
import { api, mapDocument } from '../api/client';
import './Documents.css';

const Documents = () => {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('Semua');
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api('/api/documents/public')
      .then(rows => setDocuments(rows.map(mapDocument)))
      .catch(e => console.error('Gagal memuat dokumen:', e.message))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const filteredDocs = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(query.toLowerCase());
    const matchesFilter = filter === 'Semua' || doc.category === filter;
    return matchesSearch && matchesFilter;
  });

  const totalPages = documents.reduce((sum, doc) => sum + (parseInt(doc.pages) || 0), 0);

  return (
    <div className="documents-page">
      <TopHeader title="Dokumen Resmi" />

      <div className="documents-content-wrapper">
        
        {/* Page Hero Description */}
        <div className="docs-hero">
          <h1 className="docs-hero-title">Katalog Dokumen Terverifikasi</h1>
          <p className="docs-hero-subtitle">
            Telusuri pangkalan data dokumen resmi universitas yang menjadi acuan sumber jawaban asisten Pandu. Seluruh dokumen telah divalidasi oleh otoritas akademik.
          </p>
        </div>

        {/* Global Stats/Status Block */}
        <div className="docs-stats-board">
          <div className="doc-stat-item">
            <div className="stat-icon-wrap bg-blue"><BookOpen size={20} /></div>
            <div className="stat-info">
              <span className="stat-num">{documents.length}</span>
              <span className="stat-lbl">Total Dokumen</span>
            </div>
          </div>
          <div className="doc-stat-item">
            <div className="stat-icon-wrap bg-purple"><Database size={20} /></div>
            <div className="stat-info">
              <span className="stat-num">{totalPages}</span>
              <span className="stat-lbl">Halaman Terindeks</span>
            </div>
          </div>
          <div className="doc-stat-item">
            <div className="stat-icon-wrap bg-green"><RefreshCw size={20} /></div>
            <div className="stat-info">
              <span className="stat-num sync-ok">Tersinkronisasi</span>
              <span className="stat-lbl">Status Pangkalan Data</span>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="docs-toolbar card-elevated">
          <div className="docs-toolbar-left">
            <h2 className="toolbar-title">Daftar Dokumen</h2>
          </div>
          <div className="docs-toolbar-right">
            <div className="search-wrapper">
              <Search size={18} className="search-icon" />
              <input 
                type="text" 
                placeholder="Cari dokumen..." 
                className="docs-search-input"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            
            <div className="filter-wrapper">
              <Filter size={18} className="filter-icon" />
              <select 
                className="docs-filter-select"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              >
                <option value="Semua">Semua Kategori</option>
                <option value="PKL">PKL</option>
                <option value="Tugas Akhir">Tugas Akhir</option>
              </select>
            </div>
          </div>
        </div>

        {/* Document Grid */}
        {loading ? null : filteredDocs.length > 0 ? (
          <div className="docs-grid">
            {filteredDocs.map(doc => (
              <DocumentCard key={doc.id} document={doc} />
            ))}
          </div>
        ) : (
          <div className="docs-empty-state-wrapper">
            <EmptyState 
              title="Dokumen Tidak Ditemukan" 
              description="Sistem tidak dapat menemukan dokumen dengan kata kunci atau kategori yang Anda pilih."
            />
          </div>
        )}

      </div>
    </div>
  );
};

export default Documents;
