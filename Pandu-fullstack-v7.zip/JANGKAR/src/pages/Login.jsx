import React, { useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { AlertCircle, GraduationCap, ShieldCheck } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { api, auth } from '../api/client';
import { AUTH_CONFIG } from '../config/uploads';
import './login.css';
import BrandMark from '../components/brand/BrandMark';

/* Only same-site paths are accepted as a return target. */
const safeNext = (value) => (value && value.startsWith('/') && !value.startsWith('//') ? value : null);

const Login = () => {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'));
  const [mode, setMode] = useState(params.get('mode') === 'daftar' ? 'daftar' : 'masuk');
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const domains = AUTH_CONFIG.allowedEmailDomains;
  const setField = k => e => setForm({ ...form, [k]: e.target.value });

  const goAfterLogin = (user) => {
    if (user.role === 'admin') navigate(next?.startsWith('/admin') ? next : '/admin/dashboard', { replace: true });
    else navigate(next && !next.startsWith('/admin') ? next : '/dashboard', { replace: true });
  };

  if (auth.isLoggedIn) {
    return <Navigate to={auth.isAdmin ? '/admin/dashboard' : (next || '/dashboard')} replace />;
  }

  const submit = async (e) => {
    e.preventDefault();
    if (loading) return;
    setError('');
    const email = form.email.trim();
    if (mode === 'daftar') {
      if (form.name.trim().length < 2) { setError('Isi nama lengkap Anda.'); return; }
      if (form.password.length < 8) { setError('Kata sandi minimal 8 karakter.'); return; }
      if (form.password !== form.confirm) { setError('Konfirmasi kata sandi tidak sama.'); return; }
    }
    setLoading(true);
    try {
      const res = mode === 'daftar'
        ? await api('/api/auth/register', { method: 'POST', body: { name: form.name.trim(), email, password: form.password } })
        : await api('/api/auth/login', { method: 'POST', body: { email, password: form.password } });
      auth.set(res.access_token, res.user);
      goAfterLogin(res.user);
    } catch (err) {
      const unreachable = err instanceof TypeError || /^Error 5\d\d$/.test(err.message);
      setError(unreachable ? 'Server Pandu tidak bisa dihubungi. Coba lagi sebentar.' : err.message);
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (m) => { setMode(m); setError(''); };

  return (
    <div className="login-page">
      <Card padding="lg" className="login-card">
        <div className="login-header">
          <Link to="/" className="login-brand" aria-label="Kembali ke beranda Pandu">
            <BrandMark size={36} />
            <span className="login-logo">Pandu</span>
          </Link>
          <p className="login-subtitle">Asisten layanan akademik khusus mahasiswa Universitas Negeri Padang.</p>
        </div>

        <div className="login-tabs" role="tablist" aria-label="Masuk atau daftar">
          <button type="button" role="tab" aria-selected={mode === 'masuk'} className={mode === 'masuk' ? 'is-active' : ''} onClick={() => switchMode('masuk')}>
            Masuk
          </button>
          <button type="button" role="tab" aria-selected={mode === 'daftar'} className={mode === 'daftar' ? 'is-active' : ''} onClick={() => switchMode('daftar')}>
            Daftar akun mahasiswa
          </button>
        </div>

        <form onSubmit={submit} className="login-form" noValidate>
          {mode === 'daftar' && (
            <div className="form-group">
              <label htmlFor="name">Nama lengkap</label>
              <input id="name" className="form-input" autoComplete="name" value={form.name} onChange={setField('name')} placeholder="Nama sesuai data kampus" />
            </div>
          )}
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              className="form-input"
              autoComplete="email"
              value={form.email}
              onChange={setField('email')}
              placeholder={domains.length ? `nama@${domains[0]}` : 'nama@email.com'}
              required
            />
            {mode === 'daftar' && (
              <span className="login-hint">
                {domains.length
                  ? `Hanya email ${domains.map(d => `@${d}`).join(' atau ')} yang bisa mendaftar.`
                  : 'Untuk sementara email apa pun bisa dipakai. Nantinya akan memakai akun SSO UNP.'}
              </span>
            )}
          </div>
          <div className="form-group">
            <label htmlFor="password">Kata sandi</label>
            <input
              id="password"
              type="password"
              className="form-input"
              autoComplete={mode === 'daftar' ? 'new-password' : 'current-password'}
              value={form.password}
              onChange={setField('password')}
              placeholder={mode === 'daftar' ? 'Minimal 8 karakter' : 'Kata sandi Anda'}
              required
            />
          </div>
          {mode === 'daftar' && (
            <div className="form-group">
              <label htmlFor="confirm">Ulangi kata sandi</label>
              <input id="confirm" type="password" className="form-input" autoComplete="new-password" value={form.confirm} onChange={setField('confirm')} />
            </div>
          )}

          {error && (
            <p className="login-error" role="alert">
              <AlertCircle size={15} /> {error}
            </p>
          )}

          <div className="login-actions">
            <Button size="lg" fullWidth type="submit" disabled={loading}>
              {loading ? 'Memproses…' : mode === 'daftar' ? 'Daftar & mulai bertanya' : 'Masuk'}
            </Button>
          </div>

          <div className="login-roles">
            <div className="login-role">
              <GraduationCap size={16} />
              <span><strong>Mahasiswa UNP</strong> — daftar sekali, lalu masuk untuk bertanya. Riwayat chat tersimpan di akun Anda.</span>
            </div>
            <div className="login-role">
              <ShieldCheck size={16} />
              <span><strong>Admin akademik</strong> — masuk dengan akun admin yang diberikan sistem.</span>
            </div>
          </div>
        </form>

        <div className="login-footer">
          <Link to="/" className="link-button">Kembali ke Beranda</Link>
        </div>
      </Card>
    </div>
  );
};

export default Login;
