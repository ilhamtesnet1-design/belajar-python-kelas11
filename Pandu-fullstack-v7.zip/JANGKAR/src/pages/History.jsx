import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MessageSquare, Pencil, Trash2, Check, X, Plus } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import PandaMascot from '../components/mascot/PandaMascot';
import { deleteConversation, listConversations, renameConversation } from '../api/history';
import { formatWhen, parseServerDate } from '../utils/time';
import './history.css';

/* Group by how long ago, the way people remember chats. */
const bucket = (value) => {
  const d = parseServerDate(value);
  if (!d) return 'Lebih lama';
  const start = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const days = Math.round((start(new Date()) - start(d)) / 86400000);
  if (days <= 0) return 'Hari ini';
  if (days === 1) return 'Kemarin';
  if (days < 7) return '7 hari terakhir';
  if (days < 31) return '30 hari terakhir';
  return 'Lebih lama';
};
const ORDER = ['Hari ini', 'Kemarin', '7 hari terakhir', '30 hari terakhir', 'Lebih lama'];

const History = () => {
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const [state, setState] = useState('loading');
  const [q, setQ] = useState('');
  const [editing, setEditing] = useState(null);
  const [title, setTitle] = useState('');

  const load = () => listConversations()
    .then(r => { setRows(r); setState('ready'); })
    .catch(() => setState('error'));

  useEffect(() => {
    load();
    window.addEventListener('jangkar_history_update', load);
    return () => window.removeEventListener('jangkar_history_update', load);
  }, []);

  const visible = rows.filter(r => !q || `${r.title} ${r.preview}`.toLowerCase().includes(q.toLowerCase()));
  const groups = useMemo(() => {
    const g = {};
    visible.forEach(r => { (g[bucket(r.updated_at)] = g[bucket(r.updated_at)] || []).push(r); });
    return ORDER.filter(k => g[k]).map(k => [k, g[k]]);
  }, [visible]);

  const saveTitle = async (id) => {
    const t = title.trim();
    if (t) await renameConversation(id, t).catch(() => {});
    setEditing(null);
  };

  const remove = async (row) => {
    if (!window.confirm(`Hapus percakapan “${row.title}”?`)) return;
    await deleteConversation(row.id).catch(() => {});
  };

  return (
    <div className="history-page">
      <TopHeader title="Riwayat Chat" />
      <div className="history-body">
        <div className="history-toolbar">
          <div className="history-search">
            <Search size={16} aria-hidden="true" />
            <label htmlFor="history-q" className="sr-only">Cari riwayat</label>
            <input id="history-q" type="search" placeholder="Cari percakapan…" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <button type="button" className="history-new" onClick={() => navigate(`/assistant?new=${Date.now()}`)}>
            <Plus size={16} /> Chat baru
          </button>
        </div>

        {state === 'loading' && <div className="history-empty"><PandaMascot mood="history" size={96} caption /></div>}
        {state === 'error' && <p className="history-note">Riwayat belum bisa dimuat. Periksa koneksi Anda.</p>}
        {state === 'ready' && rows.length === 0 && (
          <div className="history-empty">
            <PandaMascot mood="welcome" size={110} />
            <h3>Belum ada percakapan</h3>
            <p>Percakapan Anda tersimpan di akun dan bisa dibuka lagi dari HP atau laptop lain.</p>
            <button type="button" className="history-new" onClick={() => navigate('/assistant')}>Mulai bertanya</button>
          </div>
        )}
        {state === 'ready' && rows.length > 0 && visible.length === 0 && (
          <p className="history-note">Tidak ada percakapan yang cocok dengan “{q}”.</p>
        )}

        {groups.map(([label, items]) => (
          <section key={label} className="history-group">
            <h2 className="eyebrow">{label}</h2>
            <ul>
              {items.map(r => (
                <li key={r.id} className="history-row">
                  {editing === r.id ? (
                    <form className="history-edit" onSubmit={e => { e.preventDefault(); saveTitle(r.id); }}>
                      <label htmlFor={`t-${r.id}`} className="sr-only">Judul percakapan</label>
                      <input id={`t-${r.id}`} autoFocus value={title} maxLength={200} onChange={e => setTitle(e.target.value)} />
                      <button type="submit" aria-label="Simpan judul"><Check size={16} /></button>
                      <button type="button" aria-label="Batal" onClick={() => setEditing(null)}><X size={16} /></button>
                    </form>
                  ) : (
                    <>
                      <button type="button" className="history-open" onClick={() => navigate(`/assistant?chatId=${r.id}`)}>
                        <MessageSquare size={18} />
                        <span className="history-text">
                          <strong>{r.title}</strong>
                          <span>{r.preview}</span>
                        </span>
                        <span className="history-meta tabular">{formatWhen(r.updated_at)} · {r.message_count} pesan</span>
                      </button>
                      <div className="history-actions">
                        <button type="button" aria-label="Ganti judul" title="Ganti judul" onClick={() => { setEditing(r.id); setTitle(r.title); }}>
                          <Pencil size={15} />
                        </button>
                        <button type="button" className="danger" aria-label="Hapus" title="Hapus" onClick={() => remove(r)}>
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </>
                  )}
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
};

export default History;
