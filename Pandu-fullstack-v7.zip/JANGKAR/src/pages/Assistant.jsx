import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Send, CheckCircle, RotateCcw, Paperclip, FileText, X, Loader2, AlertCircle } from 'lucide-react';
import TopHeader from '../components/layout/TopHeader';
import ChatMessage from '../components/chat/ChatMessage';
import PandaMascot from '../components/mascot/PandaMascot';
import { api, mapCitation } from '../api/client';
import { fromStored, getConversation, saveExchange } from '../api/history';
import { UPLOAD_LIMITS, limitHint, validateFile } from '../config/uploads';
import './assistant.css';

const Assistant = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q');
  const queryChatId = searchParams.get('chatId');
  const isNew = searchParams.get('new');

  const [messages, setMessages] = useState([]);
  const chatIdRef = useRef(queryChatId || null);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  /* Student's own PDFs: the one attached to this conversation, and the list
     of everything they've uploaded (kept server-side for a few days). */
  const [myDocs, setMyDocs] = useState([]);
  const [attached, setAttached] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [attachError, setAttachError] = useState('');
  const fileRef = useRef(null);

  const loadMyDocs = () => api('/api/my-documents').then(setMyDocs).catch(() => {});
  useEffect(() => { loadMyDocs(); }, []);

  /* While the attached PDF is still being read, check back every 2s. */
  const attachedProcessing = attached && (attached.ingest_status === 'belum' || attached.ingest_status === 'diproses');
  useEffect(() => {
    if (!attachedProcessing) return undefined;
    const timer = setInterval(() => {
      api(`/api/my-documents/${attached.id}`)
        .then(d => { setAttached(d); if (d.ingest_status === 'selesai' || d.ingest_status === 'gagal') loadMyDocs(); })
        .catch(() => {});
    }, 2000);
    return () => clearInterval(timer);
  }, [attachedProcessing, attached?.id]);

  const uploadPdf = async (file) => {
    if (!file) return;
    setAttachError('');
    const check = validateFile(file, 'document');
    if (!check.ok) { setAttachError(check.message); return; }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const doc = await api('/api/my-documents', { method: 'POST', form: fd });
      setAttached(doc);
      loadMyDocs();
    } catch (e) {
      setAttachError(e.message);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const [loadingChat, setLoadingChat] = useState(false);

  /* Open a saved conversation from the account (sidebar, history page, other device). */
  useEffect(() => {
    if (isNew) {
      setMessages([]);
      setAttached(null);
      chatIdRef.current = null;
      setSearchParams({});
      return;
    }
    if (!queryChatId || String(chatIdRef.current) === String(queryChatId) && messages.length) return;
    setLoadingChat(true);
    getConversation(queryChatId)
      .then(c => { setMessages(c.messages.map(fromStored)); chatIdRef.current = c.id; })
      .catch(() => { setMessages([]); chatIdRef.current = null; setSearchParams({}); })
      .finally(() => setLoadingChat(false));
  }, [queryChatId, isNew, setSearchParams]);

  /* Each finished exchange is saved to the account; the first one creates the
     conversation and puts its id in the URL so a refresh reopens it. */
  const persist = async (pair) => {
    try {
      const id = await saveExchange(chatIdRef.current, pair);
      if (!chatIdRef.current) {
        chatIdRef.current = id;
        setSearchParams({ chatId: String(id) }, { replace: true });
      }
    } catch {
      /* History is a convenience: a failed save never blocks the answer. */
    }
  };

  useEffect(() => {
    if (initialQuery && messages.length === 0) {
      handleSend(initialQuery);
    }
  }, [initialQuery]);

  useEffect(() => {
    if (scrollRef.current) {
      // Welcome screen reads from the top; a conversation follows the newest message.
      scrollRef.current.scrollTop = messages.length || isTyping ? scrollRef.current.scrollHeight : 0;
    }
  }, [messages, isTyping]);

  const attachedReady = attached?.ingest_status === 'selesai';

  const handleSend = async (text) => {
    if (!text.trim() || isTyping) return;
    if (attached && !attachedReady) return;

    const privateDoc = attached ? attached.name : null;
    const newUserMsg = { id: Date.now().toString(), role: 'user', content: text, privateDoc };
    setMessages(prev => [...prev, newUserMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const res = attached
        ? await api(`/api/my-documents/${attached.id}/ask`, { method: 'POST', body: { question: text } })
        : await api('/api/chat/ask', { method: 'POST', body: { question: text } });
      const answerMsg = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: res.answer,
        isRefusal: res.refused,
        logId: res.log_id,
        privateDoc,
        citations: res.citations.map(mapCitation),
      };
      setMessages(prev => [...prev, answerMsg]);
      persist([newUserMsg, answerMsg]);
    } catch (err) {
      /* A failure is not a refusal: showing "no source found" here would tell
         the student the documents don't cover their question when in fact
         the server never answered. */
      const unreachable = err instanceof TypeError || /^Error 5\d\d$/.test(err.message);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: unreachable
          ? 'Server Pandu tidak bisa dihubungi. Pastikan backend berjalan di localhost:8000, lalu tanya ulang.'
          : err.message,
        isError: true,
      }]);
      if (attached && /tidak ditemukan/i.test(err.message)) { setAttached(null); loadMyDocs(); }
    } finally {
      setIsTyping(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleSend(input);
  };

  /* Enter sends; Shift+Enter starts a new line, which matters because
     academic questions are often several lines long. */
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend(input);
      e.target.style.height = 'auto';
    }
  };

  const autoGrow = (e) => {
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 160)}px`;
  };

  /* Drawn from documents that are verified and in force, so a first question
     has a real chance of matching an indexed passage. */
  const suggestedQuestions = attached
    ? ['Apa isi utama dokumen ini?', 'Apa saja persyaratan yang disebutkan?', 'Kapan batas waktu yang tercantum?', 'Siapa yang bertanggung jawab?']
    : [
      'Kapan perkuliahan semester ganjil 2026/2027 dimulai?',
      'Bagaimana langkah pendaftaran yudisium di portal akademik?',
      'Apa syarat minimal SKS untuk mendaftar PKL?',
      'Kapan pengisian KRS semester genap 2027?',
    ];

  const lastQuestion = [...messages].reverse().find(m => m.role === 'user');
  const readyDocs = myDocs.filter(d => d.ingest_status === 'selesai');

  return (
    <div className="assistant-page">
      <TopHeader
        title="Asisten Pandu"
        action={
          <div className="system-status">
            <span className="status-dot"></span>
            Sistem aktif
          </div>
        }
      />

      <div className="chat-workspace">
        <div className="chat-history" ref={scrollRef}>
          {loadingChat ? (
            <div className="welcome-state"><PandaMascot mood="history" size={96} caption /></div>
          ) : messages.length === 0 ? (
            <div className="welcome-state">
              <PandaMascot mood={attached ? (attachedReady ? 'encourage' : 'uploading') : 'welcome'} size={132} className="welcome-panda" />
              <div className="welcome-logo">Pandu</div>
              <p className="welcome-subtitle" style={{ marginTop: '16px' }}>
                {attached
                  ? `Tanyakan apa saja tentang isi “${attached.name}”.`
                  : 'Ajukan pertanyaan seputar layanan dan aturan akademik kampus, atau lampirkan PDF Anda sendiri untuk ditanyakan.'}
              </p>

              {!attached && (
                <div className="trust-badges">
                  <span className="trust-badge"><CheckCircle size={14} /> Dokumen Resmi</span>
                  <span className="trust-badge"><CheckCircle size={14} /> Sumber Terverifikasi</span>
                  <span className="trust-badge"><CheckCircle size={14} /> Kutipan & Halaman</span>
                </div>
              )}

              <div className="welcome-suggestions">
                <h3 className="welcome-suggestions-title">{attached ? 'Contoh pertanyaan untuk dokumen Anda' : 'Pertanyaan yang sering diajukan'}</h3>
                <div className="welcome-suggestions-grid">
                  {suggestedQuestions.map((q) => (
                    <button
                      key={q}
                      type="button"
                      className="welcome-suggestion-btn"
                      onClick={() => handleSend(q)}
                      disabled={Boolean(attached) && !attachedReady}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            messages.map(msg => <ChatMessage key={msg.id} message={msg} />)
          )}

          {isTyping && (
            <div className="typing-indicator-row">
              <div className="panda-working">
                <PandaMascot mood={attached ? 'reading-own' : 'searching'} size={76} caption />
              </div>
            </div>
          )}
          <div className="chat-spacer"></div>
        </div>

        <div className="chat-input-wrapper">
          <div className="chat-input-area">
            {(attached || uploading || attachError || readyDocs.length > 0) && (
              <div className="attach-bar">
                {uploading && (
                  <span className="attach-chip is-busy"><Loader2 size={14} className="spin" /> Mengunggah PDF…</span>
                )}
                {attached && !uploading && (
                  <span className={`attach-chip${attachedReady ? ' is-ready' : attached.ingest_status === 'gagal' ? ' is-failed' : ' is-busy'}`}>
                    {attachedReady ? <FileText size={14} /> : attached.ingest_status === 'gagal' ? <AlertCircle size={14} /> : <Loader2 size={14} className="spin" />}
                    <span className="attach-name">{attached.name}</span>
                    <span className="attach-state">
                      {attachedReady ? `${attached.pages} hlm · siap ditanya`
                        : attached.ingest_status === 'gagal' ? 'tidak bisa dibaca' : 'sedang dibaca…'}
                    </span>
                    <button type="button" onClick={() => setAttached(null)} aria-label="Berhenti bertanya tentang dokumen ini" title="Kembali ke dokumen resmi">
                      <X size={14} />
                    </button>
                  </span>
                )}
                {!attached && !uploading && readyDocs.length > 0 && (
                  <label className="attach-pick">
                    <span className="sr-only">Pilih dokumen yang pernah diunggah</span>
                    <select value="" onChange={e => setAttached(readyDocs.find(d => String(d.id) === e.target.value) || null)}>
                      <option value="">Tanya dokumen saya ({readyDocs.length})…</option>
                      {readyDocs.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                    </select>
                  </label>
                )}
                {attached?.ingest_status === 'gagal' && (
                  <span className="attach-error">{attached.ingest_error}</span>
                )}
                {attachError && <span className="attach-error"><AlertCircle size={13} /> {attachError}</span>}
              </div>
            )}

            <form className="chat-input-form" onSubmit={handleSubmit}>
              <input
                ref={fileRef}
                type="file"
                accept={UPLOAD_LIMITS.document.accept}
                hidden
                onChange={e => uploadPdf(e.target.files[0])}
              />
              <button
                type="button"
                className="attachment-btn"
                onClick={() => fileRef.current?.click()}
                disabled={uploading || isTyping}
                title={`Lampirkan PDF Anda (${limitHint('document')})`}
                aria-label="Lampirkan PDF untuk ditanyakan"
              >
                <Paperclip size={19} />
              </button>
              <label htmlFor="chat-input" className="sr-only">Pertanyaan Anda</label>
              <textarea
                id="chat-input"
                className="chat-input"
                placeholder={attached ? 'Tanya isi PDF ini…' : 'Tanya soal akademik…'}
                value={input}
                rows={1}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                onInput={autoGrow}
                disabled={isTyping}
              />
              <button
                type="submit"
                className="chat-submit-btn"
                disabled={isTyping || !input.trim() || (Boolean(attached) && !attachedReady)}
                aria-label="Kirim pertanyaan"
              >
                <Send size={18} />
              </button>
            </form>
            <div className="chat-footer-row">
              <span className="chat-disclaimer">
                {attached
                  ? <>Jawaban disusun dari PDF yang Anda unggah, bukan dokumen resmi. Dokumen terhapus otomatis — <Link to="/settings">kelola</Link>.</>
                  : 'Jawaban hanya disusun dari dokumen resmi yang sudah diverifikasi.'}
              </span>
              {lastQuestion && !isTyping && (
                <button type="button" className="chat-retry" onClick={() => handleSend(lastQuestion.content)}>
                  <RotateCcw size={13} /> Tanya ulang
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Assistant;
