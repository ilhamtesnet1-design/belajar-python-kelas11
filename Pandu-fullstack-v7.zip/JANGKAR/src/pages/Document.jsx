import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, FileText, Info, ScanText, Layout } from 'lucide-react';
import { mockDocuments } from '../data/documents';
import './document.css';

const Document = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const document = mockDocuments.find(d => d.id === id);

  if (!document) {
    return (
      <div className="document-detail-container text-center" style={{ padding: '64px' }}>
        <h2>Dokumen Tidak Ditemukan</h2>
        <button className="btn btn-primary" style={{ marginTop: '16px' }} onClick={() => navigate(-1)}>
          Kembali
        </button>
      </div>
    );
  }

  return (
    <div className="document-detail-container">
      <div className="document-header">
        <div>
          <button className="btn btn-outline" style={{ marginBottom: '16px' }} onClick={() => navigate(-1)}>
            <ArrowLeft size={18} /> Kembali
          </button>
          <h1 className="document-title">{document.title}</h1>
          <div className="document-meta-pills">
            <span className="pill pill-primary">{document.category}</span>
            <span className="pill pill-success"><CheckCircle size={14} /> {document.status}</span>
            <span className="pill pill-outline">{document.year}</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn btn-primary" onClick={() => navigate('/ocr')}>
            <ScanText size={18} /> Coba Ulang OCR
          </button>
        </div>
      </div>

      <div className="document-content-grid">
        <div>
          <div className="doc-section-card">
            <h3><Layout size={18} /> Preview Isi Dokumen</h3>
            <div className="preview-container" style={{ height: '600px', width: '100%', overflow: 'hidden', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
              <iframe 
                src={document.url} 
                title={document.title} 
                width="100%" 
                height="100%" 
                style={{ border: 'none' }}
              />
            </div>
          </div>
          
          <div className="doc-section-card">
            <h3><ScanText size={18} /> Hasil Ekstraksi OCR</h3>
            <div className="ocr-result-box">
              {document.ocrText}
            </div>
          </div>
        </div>

        <div>
          <div className="doc-section-card">
            <h3><Info size={18} /> Metadata Dokumen</h3>
            <table className="meta-table">
              <tbody>
                <tr>
                  <td>Instansi</td>
                  <td>{document.institution}</td>
                </tr>
                <tr>
                  <td>Tahun</td>
                  <td>{document.year}</td>
                </tr>
                <tr>
                  <td>Tanggal Dokumen</td>
                  <td>{document.date}</td>
                </tr>
                <tr>
                  <td>Total Halaman</td>
                  <td>{document.pages}</td>
                </tr>
                <tr>
                  <td>Kategori</td>
                  <td>{document.category}</td>
                </tr>
                <tr>
                  <td>Status</td>
                  <td style={{color: 'var(--success)'}}>{document.status}</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div className="doc-section-card">
            <h3>Deskripsi</h3>
            <p style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--text-secondary)' }}>
              {document.description}
            </p>
          </div>
          
          {document.citations && document.citations.length > 0 && (
            <div className="doc-section-card" style={{ backgroundColor: '#f0fdf4', borderColor: '#bbf7d0' }}>
              <h3 style={{ color: 'var(--success)' }}><CheckCircle size={18} /> Digunakan sebagai Sumber</h3>
              <p style={{ fontSize: '14px', color: '#166534' }}>
                Dokumen ini merupakan salah satu referensi jawaban Asisten Pandu dengan {document.citations.length} kutipan relevan.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Document;
