import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { loadUploadLimits } from './config/uploads';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));

/* Read the server's upload limits before the first paint (capped at 2.5s, and
   rendering goes ahead with the defaults if the backend is down). */
loadUploadLimits().finally(() => {
  root.render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>,
  );
  /* The app has painted: fade the splash from index.html out, then remove it. */
  const splash = document.getElementById('splash');
  if (splash) {
    requestAnimationFrame(() => splash.classList.add('is-leaving'));
    setTimeout(() => splash.remove(), 320);
  }
});
