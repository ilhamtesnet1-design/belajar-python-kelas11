import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

/* Existing Workspace Imports */
import MainLayout from './components/layout/MainLayout';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Assistant from './pages/Assistant';
import Documents from './pages/Documents';
import DocumentDetail from './pages/DocumentDetail';
import SourceDetail from './pages/SourceDetail';
import OCR from './pages/OCR';
import FAQ from './pages/FAQ';
import Help from './pages/Help';
import Settings from './pages/Settings';
import History from './pages/History';

/* Admin Imports */
import AdminLayout from './components/layout/AdminLayout';
import AdminDashboard from './pages/admin/Dashboard';
import AdminRegistri from './pages/admin/Registri';
import AdminValidasi from './pages/admin/Validasi';
import AdminEvaluasi from './pages/admin/Evaluasi';
import AdminOCR from './pages/admin/OCR';
import AdminFAQ from './pages/admin/FAQ';
import AdminPengaturan from './pages/admin/Pengaturan';

// Legacy SIAKAD Imports (Kept for safe routing if referenced elsewhere)
import AdminMahasiswa from './pages/admin/Mahasiswa';
import AdminDokumen from './pages/admin/Dokumen';
import AdminProposal from './pages/admin/Proposal';
import AdminBimbingan from './pages/admin/Bimbingan';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      
      {/* Student Workspace routes with main layout sidebar */}
      <Route element={<MainLayout />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/assistant" element={<Assistant />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/document/:id" element={<DocumentDetail />} />
        <Route path="/source/:id" element={<SourceDetail />} />
        <Route path="/ocr" element={<OCR />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/help" element={<Help />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/riwayat" element={<History />} />
      </Route>

      {/* Admin Panel routes */}
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<Navigate to="/admin/dashboard" replace />} />
        {/* Core Pandu RAG Admin Routes */}
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="registri" element={<AdminRegistri />} />
        <Route path="ocr" element={<AdminOCR />} />
        <Route path="validasi" element={<AdminValidasi />} />
        <Route path="evaluasi" element={<AdminEvaluasi />} />
        <Route path="faq" element={<AdminFAQ />} />
        <Route path="pengaturan" element={<AdminPengaturan />} />
        
        {/* Legacy Routing */}
        <Route path="mahasiswa" element={<AdminMahasiswa />} />
        <Route path="dokumen" element={<AdminDokumen />} />
        <Route path="proposal" element={<AdminProposal />} />
        <Route path="bimbingan" element={<AdminBimbingan />} />
      </Route>
    </Routes>
  );
}

export default App;
