/* Chat history lives in the user's account (GET/POST /api/conversations), so it
   follows them from the web to the phone app. Every change fires
   `jangkar_history_update` so the sidebar, dashboard and history page refresh. */
import { api } from './client';

const notify = () => window.dispatchEvent(new Event('jangkar_history_update'));

/* Only what's needed to redraw a message later; transient UI state is dropped. */
export const toStored = (m) => ({
  role: m.role,
  content: m.content,
  meta: m.role === 'assistant'
    ? { isRefusal: Boolean(m.isRefusal), logId: m.logId ?? null, privateDoc: m.privateDoc || null, citations: m.citations || [] }
    : { privateDoc: m.privateDoc || null },
});

export const fromStored = (m) => ({
  id: String(m.id),
  role: m.role,
  content: m.content,
  isRefusal: Boolean(m.meta?.isRefusal),
  logId: m.meta?.logId ?? null,
  privateDoc: m.meta?.privateDoc || null,
  citations: m.meta?.citations || [],
});

export const listConversations = (q) => api(`/api/conversations${q ? `?q=${encodeURIComponent(q)}` : ''}`);
export const getConversation = (id) => api(`/api/conversations/${id}`);

export async function saveExchange(conversationId, messages) {
  const payload = { messages: messages.map(toStored) };
  const res = conversationId
    ? await api(`/api/conversations/${conversationId}/messages`, { method: 'POST', body: payload })
    : await api('/api/conversations', { method: 'POST', body: payload });
  notify();
  return res.id;
}

export async function renameConversation(id, title) {
  await api(`/api/conversations/${id}`, { method: 'PATCH', body: { title } });
  notify();
}

export async function deleteConversation(id) {
  await api(`/api/conversations/${id}`, { method: 'DELETE' });
  notify();
}

export async function deleteAllConversations() {
  await api('/api/conversations', { method: 'DELETE' });
  notify();
}

/* One-time move of chats that older versions kept only in this browser. */
const LEGACY_KEY = 'jangkar_chats';
let migrating = null;
export function migrateLocalHistory() {
  if (migrating) return migrating;
  migrating = (async () => {
    let legacy = [];
    try { legacy = JSON.parse(localStorage.getItem(LEGACY_KEY) || '[]'); } catch { return 0; }
    if (!Array.isArray(legacy) || legacy.length === 0) return 0;
    let moved = 0;
    for (const chat of [...legacy].reverse()) {
      const messages = (chat.messages || []).filter(m => !m.isError && m.content);
      if (!messages.length) continue;
      try {
        await api('/api/conversations', { method: 'POST', body: { title: chat.title, messages: messages.slice(0, 50).map(toStored) } });
        moved += 1;
      } catch {
        return moved;            // offline or rejected: keep the local copy and try next time
      }
    }
    try { localStorage.removeItem(LEGACY_KEY); } catch { /* ignore */ }
    if (moved) notify();
    return moved;
  })().finally(() => { migrating = null; });
  return migrating;
}
