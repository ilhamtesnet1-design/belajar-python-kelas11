// Penghubung frontend <-> backend Pandu (FastAPI).
// Dev: Vite meneruskan /api ke http://localhost:8000 (lihat vite.config.js).
// Produksi: set VITE_API_URL di .env frontend bila backend beda domain.
const BASE = import.meta.env.VITE_API_URL || '';
const TOKEN_KEY = 'jangkar_token';

export const auth = {
  get token() {
    try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
  },
  set(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem('jangkar_user', JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem('jangkar_user');
  },
  get user() {
    try { return JSON.parse(localStorage.getItem('jangkar_user')); } catch { return null; }
  },
  get isAdmin() {
    return Boolean(this.token) && this.user?.role === 'admin';
  },
  get isLoggedIn() {
    return Boolean(this.token);
  },
};

/** "/login?next=/assistant%3Fq%3D..." — come back to where you were after signing in. */
export const loginUrl = (next, mode) => {
  const params = new URLSearchParams();
  if (mode) params.set('mode', mode);
  if (next && next !== '/login') params.set('next', next);
  const q = params.toString();
  return q ? `/login?${q}` : '/login';
};

export async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {};
  if (auth.token) headers.Authorization = `Bearer ${auth.token}`;
  let payload;
  if (form) payload = form;                      // FormData (upload file)
  else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  const res = await fetch(BASE + path, { method, headers, body: payload });
  if (res.status === 401 && auth.token) {
    /* Session expired: sign out and come back here after logging in again. */
    auth.clear();
    if (!location.pathname.startsWith('/login')) {
      location.href = loginUrl(location.pathname + location.search);
    }
  }
  if (!res.ok) {
    let msg = `Error ${res.status}`;
    try { const j = await res.json(); msg = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail); } catch { /* ignore */ }
    throw new Error(msg);
  }
  return res.status === 204 ? null : res.json();
}

export const fileUrl = (path) => (path ? BASE + path : null);

// Ubah format backend (snake_case) -> format yang dipakai komponen (camelCase)
export const mapCitation = (c) => ({
  documentId: c.document_id,
  documentName: c.document_name,
  version: c.version,
  status: c.status,
  section: c.section || '-',
  page: c.page,
  quote: c.quote,
  fileUrl: fileUrl(c.file_url),
  private: Boolean(c.private),
});

/** A student's own uploaded PDF, opened in a new tab (token in the query
    because a plain tab can't send an Authorization header). */
export const privateFileUrl = (docId, page) =>
  `${BASE}/api/my-documents/${docId}/file?token=${encodeURIComponent(auth.token || '')}${page ? `#page=${page}` : ''}`;

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : null);

export const mapDocument = (d) => ({
  id: String(d.id),
  name: d.name,
  category: d.category,
  docNumber: d.doc_number,
  version: d.version,
  year: d.year || '-',
  origin: d.origin,
  description: d.description,
  docType: d.doc_type,
  status: d.status,
  statusNote: d.status_note,
  validFrom: d.valid_from,
  validUntilRaw: d.valid_until,
  validUntil: fmtDate(d.valid_until) || 'Sampai dicabut',
  validity: d.valid_until ? `Berlaku hingga ${fmtDate(d.valid_until)}` : 'Berlaku sampai dicabut',
  pages: d.pages || 0,
  chunkCount: d.chunk_count,
  ingestStatus: d.ingest_status,
  ingestError: d.ingest_error,
  usable: d.usable,
  fileUrl: fileUrl(d.file_url),
  updated: fmtDate(d.updated_at),
});
