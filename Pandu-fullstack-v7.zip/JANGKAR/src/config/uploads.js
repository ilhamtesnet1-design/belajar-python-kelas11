/**
 * One source of truth for every upload control in Pandu.
 *
 * Before this file the limits disagreed across screens — the registry said
 * 10MB, the add-document form said 20MB, the OCR queue said 5MB — so a file
 * that one screen accepted another silently rejected. Change a limit here and
 * every screen, hint text and validation message follows.
 */

export const MB = 1024 * 1024;

export const UPLOAD_LIMITS = {
  /* Official documents: statutes, academic guides, rector decrees.
     A scanned 200-page guide routinely passes 60MB, so 100MB is the headroom. */
  document: {
    maxBytes: 100 * MB,
    accept: '.pdf,application/pdf',
    extensions: ['pdf'],
    label: 'PDF',
  },

  /* Batch intake: several documents at once, zipped. */
  archive: {
    maxBytes: 200 * MB,
    accept: '.zip,application/zip,application/x-zip-compressed',
    extensions: ['zip'],
    label: 'ZIP',
    maxEntries: 50,
  },

  /* Pages pushed through OCR one at a time. */
  scan: {
    maxBytes: 25 * MB,
    accept: '.pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg',
    extensions: ['pdf', 'png', 'jpg', 'jpeg'],
    label: 'PDF, PNG atau JPG',
  },

  /* Profile photographs. */
  avatar: {
    maxBytes: 5 * MB,
    accept: '.png,.jpg,.jpeg,image/png,image/jpeg',
    extensions: ['png', 'jpg', 'jpeg'],
    label: 'JPG atau PNG',
  },
};

/** 104857600 -> "100 MB". Keeps one decimal only when it earns it. */
export function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB'];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  const rounded = value >= 10 || Number.isInteger(value)
    ? Math.round(value)
    : Math.round(value * 10) / 10;
  return `${rounded} ${units[unit]}`;
}

/** "Maks. 100 MB" — the hint shown under a drop zone. */
export function limitHint(kind) {
  const rule = UPLOAD_LIMITS[kind];
  if (!rule) return '';
  const size = `maks. ${formatBytes(rule.maxBytes)}`;
  return rule.maxEntries
    ? `${rule.label} — ${size}, hingga ${rule.maxEntries} dokumen`
    : `${rule.label} — ${size}`;
}

/**
 * Check one file against a rule.
 * Returns { ok: true } or { ok: false, message } where the message says what
 * was wrong and what to do about it, not just that something failed.
 */
export function validateFile(file, kind) {
  const rule = UPLOAD_LIMITS[kind];
  if (!rule) return { ok: false, message: 'Jenis unggahan tidak dikenal.' };
  if (!file) return { ok: false, message: 'Belum ada berkas yang dipilih.' };

  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (!rule.extensions.includes(ext)) {
    return {
      ok: false,
      message: `Format .${ext} belum didukung. Unggah berkas ${rule.label}.`,
    };
  }

  if (file.size > rule.maxBytes) {
    return {
      ok: false,
      message: `Ukuran berkas ${formatBytes(file.size)}, melebihi batas ${formatBytes(rule.maxBytes)}. Kompres berkas atau pecah menjadi beberapa bagian.`,
    };
  }

  if (file.size === 0) {
    return { ok: false, message: 'Berkas kosong. Periksa kembali berkas sumbernya.' };
  }

  return { ok: true };
}

/**
 * Pull the limits the backend actually enforces (GET /api/config/public) and
 * overwrite the defaults above. Called once before the app first renders, so
 * every hint and every client-side check uses the server's numbers. If the
 * backend is unreachable the defaults stay, and the server still has the
 * final say on every upload.
 */
/* Who may ask questions. Filled from the same /api/config/public call; the
   default (login required) is the safe one if the backend can't be reached. */
export const AUTH_CONFIG = {
  studentLoginRequired: true,
  allowedEmailDomains: [],
};

export async function loadUploadLimits({ timeoutMs = 2500 } = {}) {
  const base = (import.meta.env && import.meta.env.VITE_API_URL) || '';
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}/api/config/public`, { signal: controller.signal });
    if (!res.ok) return false;
    const { uploads, auth: authCfg } = await res.json();
    if (authCfg) {
      AUTH_CONFIG.studentLoginRequired = authCfg.student_login_required !== false;
      AUTH_CONFIG.allowedEmailDomains = Array.isArray(authCfg.allowed_email_domains) ? authCfg.allowed_email_domains : [];
    }
    for (const [kind, rule] of Object.entries(uploads || {})) {
      if (!UPLOAD_LIMITS[kind]) continue;
      if (Number.isFinite(rule.max_bytes)) UPLOAD_LIMITS[kind].maxBytes = rule.max_bytes;
      if (Number.isFinite(rule.max_entries)) UPLOAD_LIMITS[kind].maxEntries = rule.max_entries;
    }
    return true;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

/** Which rule a picked file falls under on a screen that takes PDF or ZIP. */
export function kindForFile(file) {
  const ext = (file?.name?.split('.').pop() || '').toLowerCase();
  return UPLOAD_LIMITS.archive.extensions.includes(ext) ? 'archive' : 'document';
}
