export const documents = [
  {
    id: "doc-1",
    name: "Buku Panduan PKL",
    category: "PKL",
    version: "v1.2",
    validity: "Berlaku hingga 2027",
    status: "Terverifikasi",
    fileUrl: "/documents/Buku Panduan PKL.pdf",
    pages: 45,
    description: "Panduan resmi pelaksanaan Praktek Kerja Lapangan bagi mahasiswa aktif yang telah memenuhi SKS prasyarat."
  },
  {
    id: "doc-2",
    name: "Pelaksanaan TA Mahasiswa UNP",
    category: "Tugas Akhir",
    version: "v2.0",
    validity: "Berlaku (Revisi Terakhir 2025)",
    status: "Terverifikasi",
    fileUrl: "/documents/Pelaksanaan TA Mahasiswa UNP.pdf",
    pages: 32,
    description: "Pedoman baku terkait syarat, proses bimbingan, naskah skripsi, hingga pelaksanaan Yudisium Tugas Akhir."
  }
];
