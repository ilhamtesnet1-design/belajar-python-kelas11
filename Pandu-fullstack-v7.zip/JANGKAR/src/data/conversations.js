export const initialConversations = [
  {
    id: "msg-1",
    role: "user",
    content: "Apa saja persyaratan pengajuan tugas akhir?"
  },
  {
    id: "msg-2",
    role: "assistant",
    content: "Pengajuan tugas akhir harus memenuhi persyaratan akademik yang ditetapkan dalam dokumen resmi kampus. Beberapa syarat umum meliputi telah menyelesaikan minimal SKS tertentu sesuai program studi dan tidak memiliki nilai E.",
    citation: {
      documentId: "doc-2",
      documentName: "Pelaksanaan TA Mahasiswa UNP",
      status: "Resmi",
      section: "Persyaratan Tugas Akhir",
      page: 5,
      quote: "Mahasiswa diizinkan mengambil mata kuliah Tugas Akhir (Skripsi) apabila telah mengumpulkan paling sedikit 120 SKS dengan IPK minimal 2.00 dan tidak terdapat nilai E."
    }
  }
];

export const mockRefusalMessage = {
  id: "msg-err",
  role: "assistant",
  content: "Mohon maaf, Pandu tidak dapat menjumpai pedoman atau peraturan terkait hal tersebut di dalam kumpulan dokumen resmi Universitas. Silakan hubungi bagian kemahasiswaan atau fakultas masing-masing untuk panduan lebih lanjut.",
  isRefusal: true
};
