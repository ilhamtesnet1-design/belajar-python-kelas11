export const mockOCRData = {
  "doc-1": {
    rawText: `B U K U     P E D O M A N
Pengalaman  Kerja Lapangan  (PKL)
Mahasiswa FT UNP Padang

FAKULTAS   TEKNIK
UNIVERSITAS   NEGERI PADANG
2 0 2 6`,
    processedText: `BUKU PEDOMAN
Pengalaman Kerja Lapangan (PKL)
Mahasiswa FT UNP Padang

FAKULTAS TEKNIK
UNIVERSITAS NEGERI PADANG
2026`,
    stats: {
      chars: 114,
      words: 14,
      paragraphs: 2
    }
  },
  "doc-2": {
    rawText: `BAB   2
PELAKSANAAN  T U G A S   A K H I R 
1. Persyaratan Tugas Akhir
Mahasiswa diizinkan mengambil mata   kuliah Tugas Akhir (Skripsi) apabila telah  mengumpulkan paling sedikit 120 SKS dengan IPK minimal 2.00 dan   tidak terdapat nilai E.

2.  Prosedur   Pengajuan
Mahasiswa yang memenuhi syarat  wajib mendaftar     melalui portal akademik resmi sebelum batas waktu yang   ditentukan  kalender akademik.`,
    processedText: `BAB 2
PELAKSANAAN TUGAS AKHIR

1. Persyaratan Tugas Akhir
Mahasiswa diizinkan mengambil mata kuliah Tugas Akhir (Skripsi) apabila telah mengumpulkan paling sedikit 120 SKS dengan IPK minimal 2.00 dan tidak terdapat nilai E.

2. Prosedur Pengajuan
Mahasiswa yang memenuhi syarat wajib mendaftar melalui portal akademik resmi sebelum batas waktu yang ditentukan kalender akademik.`,
    stats: {
      chars: 421,
      words: 62,
      paragraphs: 4
    }
  }
};
