import React from 'react';
import head from '../../assets/mascot/panda-head.webp';
import head2x from '../../assets/mascot/panda-head@2x.webp';
import './BrandMark.css';

/* Pandu's logo: the red panda's face on the brand navy. `bare` drops the tile
   for places that already sit on a coloured surface (chat avatars). */
const BrandMark = ({ size = 36, bare = false, className = '' }) => (
  <span
    className={`brand-mark${bare ? ' is-bare' : ''} ${className}`}
    style={{ '--brand-size': `${size}px` }}
    aria-hidden="true"
  >
    <img src={head} srcSet={`${head} 1x, ${head2x} 2x`} alt="" width={size} height={size} draggable="false" />
  </span>
);

export default BrandMark;
