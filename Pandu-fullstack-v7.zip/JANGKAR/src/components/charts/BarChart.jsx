import React, { useId, useState } from 'react';
import './charts.css';

/**
 * Vertical bar chart drawn as plain SVG — no charting dependency.
 *
 * data: [{ label, value, color }]
 * Colours are passed in by the caller because document status is a *status*
 * scale (verified / waiting / expired / revoked), not a categorical one, so
 * the reserved status tokens apply and must not be reused as "series 4".
 */
const BarChart = ({
  data = [],
  height = 240,
  valueSuffix = '',
  caption = '',
}) => {
  const [active, setActive] = useState(null);
  const titleId = useId();

  const W = 520;
  const H = height;
  const padTop = 24;
  const padBottom = 48;
  const padLeft = 40;
  const padRight = 12;

  const plotW = W - padLeft - padRight;
  const plotH = H - padTop - padBottom;

  const rawMax = Math.max(...data.map(d => d.value), 0);
  /* Round the ceiling up to something a tick label can name honestly. */
  const niceMax = rawMax <= 4 ? 4 : Math.ceil(rawMax / 5) * 5;
  const ticks = [0, niceMax / 4, niceMax / 2, (niceMax * 3) / 4, niceMax];

  const band = plotW / Math.max(data.length, 1);
  const barW = Math.min(band * 0.52, 64);

  const yFor = value => padTop + plotH - (value / niceMax) * plotH;

  return (
    <div className="chart-wrap">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="chart-svg"
        role="img"
        aria-labelledby={titleId}
        preserveAspectRatio="xMidYMid meet"
      >
        <title id={titleId}>{caption || 'Diagram batang'}</title>

        {/* Grid and y labels */}
        {ticks.map(tick => (
          <g key={tick}>
            <line
              x1={padLeft}
              y1={yFor(tick)}
              x2={W - padRight}
              y2={yFor(tick)}
              stroke="var(--viz-grid)"
              strokeWidth="1"
              fill="none"
            />
            <text
              x={padLeft - 10}
              y={yFor(tick) + 4}
              textAnchor="end"
              className="chart-tick"
              fill="var(--viz-axis)"
            >
              {Number.isInteger(tick) ? tick : tick.toFixed(1)}
            </text>
          </g>
        ))}

        {data.map((d, i) => {
          const cx = padLeft + band * i + band / 2;
          const barH = (d.value / niceMax) * plotH;
          const isActive = active === i;

          return (
            <g key={d.label}>
              {/* Zero-height categories still get a baseline tick so the
                  category reads as present-but-empty, not missing. */}
              {d.value === 0 ? (
                <rect
                  x={cx - barW / 2}
                  y={padTop + plotH - 2}
                  width={barW}
                  height="2"
                  rx="1"
                  fill="var(--border-strong)"
                />
              ) : (
                <rect
                  x={cx - barW / 2}
                  y={yFor(d.value)}
                  width={barW}
                  height={Math.max(barH, 3)}
                  rx="4"
                  fill={d.color}
                  opacity={active === null || isActive ? 1 : 0.45}
                  className="chart-bar"
                />
              )}

              {/* Direct value label — few enough bars that every one earns it. */}
              <text
                x={cx}
                y={yFor(d.value) - 8}
                textAnchor="middle"
                className="chart-value"
                fill="var(--text-primary)"
              >
                {d.value}{valueSuffix}
              </text>

              <text
                x={cx}
                y={padTop + plotH + 22}
                textAnchor="middle"
                className="chart-label"
                fill="var(--text-secondary)"
              >
                {d.label}
              </text>

              {/* Hit target spans the whole band, wider than the bar. */}
              <rect
                x={padLeft + band * i}
                y={padTop}
                width={band}
                height={plotH}
                fill="transparent"
                onMouseEnter={() => setActive(i)}
                onMouseLeave={() => setActive(null)}
              />
            </g>
          );
        })}

        {/* Baseline */}
        <line
          x1={padLeft}
          y1={padTop + plotH}
          x2={W - padRight}
          y2={padTop + plotH}
          stroke="var(--border-strong)"
          strokeWidth="1"
          fill="none"
        />
      </svg>

      {active !== null && data[active] && (
        <div
          className="chart-tooltip"
          style={{ left: `${((padLeft + band * active + band / 2) / W) * 100}%` }}
        >
          <span className="chart-tooltip-swatch" style={{ backgroundColor: data[active].color }} />
          <span>{data[active].label}</span>
          <strong className="tabular">{data[active].value}{valueSuffix}</strong>
        </div>
      )}

      {/* Same numbers, reachable without seeing the drawing. */}
      <table className="sr-only">
        <caption>{caption}</caption>
        <tbody>
          {data.map(d => (
            <tr key={d.label}>
              <th scope="row">{d.label}</th>
              <td>{d.value}{valueSuffix}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BarChart;
