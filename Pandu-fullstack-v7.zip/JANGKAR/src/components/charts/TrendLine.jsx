import React, { useId, useState } from 'react';
import './charts.css';

/**
 * Multi-series line chart for metric history.
 *
 * series: [{ name, color, values: number[] }]
 * labels: string[]  (one per x position, shared by every series)
 * target: optional number — drawn as a dashed reference line.
 *
 * One y-scale only. Two measures of different magnitude belong in two charts,
 * never on a second axis.
 */
const TrendLine = ({
  series = [],
  labels = [],
  target = null,
  targetLabel = 'Target',
  min = 0,
  max = 100,
  unit = '%',
  caption = '',
  height = 260,
}) => {
  const [hover, setHover] = useState(null);
  const titleId = useId();

  const W = 560;
  const H = height;
  const padTop = 20;
  const padBottom = 40;
  const padLeft = 44;
  const padRight = 64; /* room for the direct end labels */

  const plotW = W - padLeft - padRight;
  const plotH = H - padTop - padBottom;

  const step = labels.length > 1 ? plotW / (labels.length - 1) : 0;
  const xFor = i => padLeft + step * i;
  const yFor = v => padTop + plotH - ((v - min) / (max - min)) * plotH;

  const ticks = [min, min + (max - min) / 2, max];

  return (
    <div className="chart-wrap">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="chart-svg"
        role="img"
        aria-labelledby={titleId}
        preserveAspectRatio="xMidYMid meet"
        onMouseLeave={() => setHover(null)}
      >
        <title id={titleId}>{caption || 'Grafik tren'}</title>

        {ticks.map(tick => (
          <g key={tick}>
            <line
              x1={padLeft}
              y1={yFor(tick)}
              x2={W - padRight}
              y2={yFor(tick)}
              stroke="var(--viz-grid)"
              strokeWidth="1"
              fill="none"
            />
            <text
              x={padLeft - 10}
              y={yFor(tick) + 4}
              textAnchor="end"
              className="chart-tick"
              fill="var(--viz-axis)"
            >
              {tick}{unit}
            </text>
          </g>
        ))}

        {target !== null && (
          <g>
            <line
              x1={padLeft}
              y1={yFor(target)}
              x2={W - padRight}
              y2={yFor(target)}
              stroke="var(--accent)"
              strokeWidth="1.5"
              strokeDasharray="5 4"
              fill="none"
            />
            {/* Identified by the dashed swatch in the legend; an in-plot label
                inevitably collides with a series somewhere. */}
          </g>
        )}

        {series.map(s => {
          /* null = not measured in that run. The line breaks there instead of
             dropping to zero, which would read as a real collapse. */
          let pen = 'M';
          const d = s.values
            .map((v, i) => {
              if (v === null || v === undefined) { pen = 'M'; return ''; }
              const seg = `${pen} ${xFor(i)} ${yFor(v)}`;
              pen = 'L';
              return seg;
            })
            .filter(Boolean)
            .join(' ');
          const lastIndex = s.values.reduce((last, v, i) => (v === null || v === undefined ? last : i), -1);
          if (lastIndex < 0) return null;
          const lone = s.values.map((v, i) => (
            v !== null && v !== undefined
            && (s.values[i - 1] === null || s.values[i - 1] === undefined)
            && (s.values[i + 1] === null || s.values[i + 1] === undefined) ? i : null
          )).filter(i => i !== null && i !== lastIndex);
          return (
            <g key={s.name}>
              <path
                d={d}
                fill="none"
                stroke={s.color}
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* A point with no neighbours draws no line, so mark it. */}
              {lone.map(i => (
                <circle key={i} cx={xFor(i)} cy={yFor(s.values[i])} r="3" fill={s.color} stroke="var(--surface)" strokeWidth="1.5" />
              ))}
              {/* Emphasised endpoint, ringed so overlapping series stay legible. */}
              <circle
                cx={xFor(lastIndex)}
                cy={yFor(s.values[lastIndex])}
                r="4"
                fill={s.color}
                stroke="var(--surface)"
                strokeWidth="2"
              />
              <text
                x={xFor(lastIndex) + 10}
                y={yFor(s.values[lastIndex]) + 4}
                className="chart-end-label"
                fill={s.color}
              >
                {s.values[lastIndex]}{unit}
              </text>
            </g>
          );
        })}

        {/* Crosshair */}
        {hover !== null && (
          <line
            x1={xFor(hover)}
            y1={padTop}
            x2={xFor(hover)}
            y2={padTop + plotH}
            stroke="var(--border-strong)"
            strokeWidth="1"
            fill="none"
          />
        )}

        {hover !== null && series.filter(s => s.values[hover] !== null && s.values[hover] !== undefined).map(s => (
          <circle
            key={`dot-${s.name}`}
            cx={xFor(hover)}
            cy={yFor(s.values[hover])}
            r="4"
            fill={s.color}
            stroke="var(--surface)"
            strokeWidth="2"
          />
        ))}

        {labels.map((label, i) => (
          <g key={label}>
            <text
              x={xFor(i)}
              y={padTop + plotH + 22}
              textAnchor="middle"
              className="chart-label"
              fill="var(--text-secondary)"
            >
              {label}
            </text>
            <rect
              x={xFor(i) - step / 2}
              y={padTop}
              width={step || plotW}
              height={plotH}
              fill="transparent"
              onMouseEnter={() => setHover(i)}
            />
          </g>
        ))}

        <line
          x1={padLeft}
          y1={padTop + plotH}
          x2={W - padRight}
          y2={padTop + plotH}
          stroke="var(--border-strong)"
          strokeWidth="1"
          fill="none"
        />
      </svg>

      {hover !== null && (
        <div
          className="chart-tooltip chart-tooltip-stack"
          style={{ left: `${(xFor(hover) / W) * 100}%` }}
        >
          <strong className="chart-tooltip-title">{labels[hover]}</strong>
          {series.map(s => (
            <span key={s.name} className="chart-tooltip-row">
              <span className="chart-tooltip-swatch" style={{ backgroundColor: s.color }} />
              {s.name}
              <strong className="tabular">
                {s.values[hover] === null || s.values[hover] === undefined ? 'belum diukur' : `${s.values[hover]}${unit}`}
              </strong>
            </span>
          ))}
        </div>
      )}

      <div className="chart-legend">
        {series.map(s => (
          <span key={s.name} className="chart-legend-item">
            <span className="chart-legend-swatch" style={{ backgroundColor: s.color }} />
            {s.name}
          </span>
        ))}
        {target !== null && (
          <span className="chart-legend-item">
            <span className="chart-legend-dash" />
            {targetLabel}
          </span>
        )}
      </div>

      <table className="sr-only">
        <caption>{caption}</caption>
        <thead>
          <tr>
            <th scope="col">Periode</th>
            {series.map(s => <th key={s.name} scope="col">{s.name}</th>)}
          </tr>
        </thead>
        <tbody>
          {labels.map((label, i) => (
            <tr key={label}>
              <th scope="row">{label}</th>
              {series.map(s => (
                <td key={s.name}>{s.values[i] === null || s.values[i] === undefined ? '—' : `${s.values[i]}${unit}`}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TrendLine;
