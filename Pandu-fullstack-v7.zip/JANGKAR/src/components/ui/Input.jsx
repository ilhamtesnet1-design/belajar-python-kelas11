import React from 'react';
import './Input.css';

export const Input = ({ icon, label, className = '', ...props }) => {
  return (
    <div className={`input-wrapper ${className}`}>
      {label && <label className="input-label">{label}</label>}
      <div className="input-container">
        {icon && <span className="input-icon">{icon}</span>}
        <input 
          className={`input-field ${icon ? 'has-icon' : ''}`} 
          {...props} 
        />
      </div>
    </div>
  );
};

export const Textarea = ({ icon, className = '', ...props }) => {
  return (
    <div className={`input-wrapper ${className}`}>
      <div className="input-container">
        {icon && <span className="input-icon textarea-icon">{icon}</span>}
        <textarea 
          className={`input-field textarea-field ${icon ? 'has-icon' : ''}`} 
          {...props} 
        />
      </div>
    </div>
  );
};
