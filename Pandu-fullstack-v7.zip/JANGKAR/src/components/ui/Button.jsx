import React from 'react';
import './Button.css';

export const Button = ({ children, variant = 'primary', icon, fullWidth, className = '', ...props }) => {
  return (
    <button 
      className={`btn btn-${variant} ${fullWidth ? 'btn-full' : ''} ${className}`} 
      {...props}
    >
      {icon && <span className="btn-icon">{icon}</span>}
      {children}
    </button>
  );
};
