import React from 'react';
import './Card.css';

export const Card = ({ children, className = '', padding = 'md' }) => {
  return (
    <div className={`card p-${padding} ${className}`}>
      {children}
    </div>
  );
};
