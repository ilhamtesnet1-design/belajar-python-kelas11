import React, { useState } from 'react';
import { ShieldCheck, Copy, Check, Phone, ThumbsUp, ThumbsDown, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import CitationCard from '../citation/CitationCard';
import PandaMascot from '../mascot/PandaMascot';
import { api } from '../../api/client';
import './ChatMessage.css';
import BrandMark from '../brand/BrandMark';

const ChatMessage = ({ message }) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);

  const citations = message.citations || [];
  const isRefusal = Boolean(message.isRefusal);
  const isError = Boolean(message.isError);
  const privateDoc = message.privateDoc || null;   // name of the student's own PDF, if asked about one
  const [vote, setVote] = useState(message.feedback ?? null);

  /* Feedback lands on the anonymous query log and feeds the admin
     dashboard's positive/negative count. Clicking the same thumb again
     withdraws the vote. */
  const sendFeedback = async (value) => {
    if (!message.logId) return;
    const next = vote === value ? 0 : value;
    const previous = vote;
    setVote(next || null);
    try {
      await api(`/api/chat/${message.logId}/feedback`, { method: 'POST', body: { value: next } });
    } catch {
      setVote(previous);
    }
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* Clipboard blocked — the text stays selectable on the page. */
    }
  };

  /* Answers arrive as plain text; keep the author's paragraph breaks instead
     of flattening everything into one block. */
  const paragraphs = String(message.content || '')
    .split(/\n{2,}/)
    .map(part => part.trim())
    .filter(Boolean);

  if (isUser) {
    return (
      <div className="chat-message-row user-row">
        <div className="chat-bubble user-bubble">
          <div className="chat-message-content">
            {paragraphs.map((text, i) => <p key={i}>{text}</p>)}
          </div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="chat-message-row assistant-row">
        <div className="chat-bubble assistant-bubble error-bubble" role="alert">
          <div className="assistant-message-header">
            <PandaMascot mood="error" size={44} className="is-avatar" />
            <div className="assistant-meta">
              <span className="assistant-name">Pandu</span>
              <span className="assistant-role">Pertanyaan belum terjawab</span>
            </div>
          </div>
          <div className="chat-message-content"><p>{message.content}</p></div>
        </div>
      </div>
    );
  }

  return (
    <div className="chat-message-row assistant-row">
      <div className={`chat-bubble assistant-bubble${isRefusal ? ' refusal-bubble' : ''}`}>
        <div className="assistant-message-header">
          {isRefusal ? (
            <PandaMascot mood="refused" size={44} className="is-avatar" />
          ) : (
            <BrandMark size={36} bare />
          )}
          <div className="assistant-meta">
            <span className="assistant-name">Pandu</span>
            <span className="assistant-role">Asisten Akademik</span>
          </div>
          {isRefusal ? (
            <div className="answer-badge refusal">{privateDoc ? 'Tidak ada di dokumen Anda' : 'Informasi tidak ditemukan'}</div>
          ) : privateDoc ? (
            <div className="answer-badge private" title={privateDoc}>
              <FileText size={14} /> Dari dokumen Anda
            </div>
          ) : citations.length > 0 ? (
            <div className="answer-badge verified">
              <ShieldCheck size={14} /> {citations.length} sumber resmi
            </div>
          ) : null}
        </div>

        <div className="chat-message-content">
          {paragraphs.map((text, i) => <p key={i}>{text}</p>)}
        </div>

        {/* A refusal is a feature, not an error: it means no verified document
            covered the question. Say so, and give the student a next step. */}
        {privateDoc && !isRefusal && (
          <p className="private-note">
            Disusun dari <strong>{privateDoc}</strong> yang Anda unggah — bukan dokumen resmi kampus. Periksa kutipannya sebelum dipakai.
          </p>
        )}

        {isRefusal && !privateDoc && (
          <div className="refusal-next">
            <p>Pandu tidak menyusun jawaban di luar dokumen resmi universitas. Untuk pertanyaan ini, hubungi unit akademik terkait.</p>
            <Link to="/help" className="refusal-action">
              <Phone size={14} /> Hubungi unit akademik
            </Link>
          </div>
        )}

        {citations.length > 0 && (
          <div className="message-citations">
            <div className="citations-heading">
              <span className="eyebrow">Dasar jawaban</span>
              <span className="citations-count tabular">{citations.length} kutipan</span>
            </div>
            {citations.map((citation, idx) => (
              <CitationCard key={idx} citation={citation} index={idx + 1} />
            ))}
          </div>
        )}

        <div className="message-actions">
          {!isRefusal && (
            <button type="button" className="message-action" onClick={copy}>
              {copied ? <Check size={14} /> : <Copy size={14} />}
              {copied ? 'Tersalin' : 'Salin jawaban'}
            </button>
          )}
          {message.logId && (
            <div className="message-vote" role="group" aria-label="Apakah jawaban ini membantu?">
              <span className="message-vote-label">Membantu?</span>
              <button
                type="button"
                className={`message-action${vote === 1 ? ' is-active up' : ''}`}
                aria-pressed={vote === 1}
                onClick={() => sendFeedback(1)}
              >
                <ThumbsUp size={14} /> Ya
              </button>
              <button
                type="button"
                className={`message-action${vote === -1 ? ' is-active down' : ''}`}
                aria-pressed={vote === -1}
                onClick={() => sendFeedback(-1)}
              >
                <ThumbsDown size={14} /> Tidak
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
