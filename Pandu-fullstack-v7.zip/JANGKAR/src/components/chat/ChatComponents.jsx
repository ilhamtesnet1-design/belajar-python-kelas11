import React from 'react';
import { ShieldCheck, Copy, ExternalLink, ChevronDown, Anchor } from 'lucide-react';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import './ChatComponents.css';

export const ChatBubbleUser = ({ message }) => {
  return (
    <div className="chat-bubble chat-bubble-user">
      <div className="chat-content-user">
        <p>{message}</p>
      </div>
      <div className="chat-avatar-user">MA</div>
    </div>
  );
};

export const ChatBubbleSystem = ({ children, time = 'Baru saja' }) => {
  return (
    <div className="chat-bubble chat-bubble-system">
      <div className="chat-avatar-system">
        <Anchor size={16} />
      </div>
      <div className="chat-content-system">
        <div className="system-header">
          <span className="system-name">Pandu</span>
          <span className="system-status-dot"></span>
          <span className="system-time">{time}</span>
        </div>
        <div className="system-body">
          {children}
        </div>
      </div>
    </div>
  );
};

export const SourceCitation = ({ title, docName, article, page, version }) => {
  return (
    <Card className="source-citation-card" padding="sm">
      <div className="source-header">
        <Badge variant="default" className="source-type-badge">Panduan Akademik</Badge>
        <div className="source-status">
          <Badge variant="success" className="source-status-badge"><ShieldCheck size={12} /> Terverifikasi</Badge>
          <Badge variant="success" className="source-status-badge">Berlaku</Badge>
        </div>
      </div>
      
      <h4 className="source-title">{title}</h4>
      
      <div className="source-meta">
        <span className="meta-item"># {article}</span>
        <span className="meta-item">
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
          Halaman {page}
        </span>
        {version && (
          <span className="meta-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            Versi {version}
          </span>
        )}
      </div>
      
      <div className="source-actions">
        <Button variant="outline" size="sm" icon={<ExternalLink size={14} />}>Lihat Sumber</Button>
        <Button variant="ghost" size="sm" icon={<Copy size={14} />}>Salin Referensi</Button>
      </div>
    </Card>
  );
};

export const RefusalBanner = () => {
  return (
    <div className="refusal-banner">
      <div className="refusal-header">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span>Informasi tidak ditemukan dalam sumber resmi</span>
      </div>
      <ul className="refusal-list">
        <li><span>×</span> Pertanyaan bersifat personal (data akademik mahasiswa)</li>
        <li><span>×</span> Informasi tidak tersedia dalam dokumen publik UNP</li>
        <li><span>×</span> Pandu tidak memiliki akses ke sistem data mahasiswa</li>
      </ul>
    </div>
  );
};
