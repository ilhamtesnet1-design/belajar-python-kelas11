import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, ChevronRight, Quote, ChevronDown } from 'lucide-react';
import { privateFileUrl } from '../../api/client';
import './CitationCard.css';

const CitationCard = ({ citation, index }) => {
  const [expanded, setExpanded] = useState(false);
  const navigate = useNavigate();

  if (!citation) return null;

  const quote = (citation.quote || '').trim();
  const isLong = quote.length > 220;
  const shown = expanded || !isLong ? quote : `${quote.slice(0, 220).trimEnd()}…`;

  return (
    <article className="citation-card">
      <header className="citation-header">
        <span className="citation-index tabular">{index ?? 1}</span>
        <div className="citation-doc-info">
          <FileText size={15} className="citation-icon" aria-hidden="true" />
          <span className="citation-doc-name">{citation.documentName}</span>
        </div>
        {citation.status && (
          <span className={`citation-status${citation.private ? ' is-private' : ''}`}>{citation.status}</span>
        )}
      </header>

      {/* The excerpt is the point of a citation — it lets a student check the
          claim without opening the PDF. */}
      {quote && (
        <blockquote className="citation-quote">
          <Quote size={14} className="citation-quote-mark" aria-hidden="true" />
          <p>{shown}</p>
          {isLong && (
            <button type="button" className="citation-expand" onClick={() => setExpanded(!expanded)}>
              {expanded ? 'Ringkas' : 'Baca selengkapnya'}
              <ChevronDown size={13} className={expanded ? 'is-open' : ''} />
            </button>
          )}
        </blockquote>
      )}

      <footer className="citation-footer">
        <dl className="citation-details">
          <div className="detail-item">
            <dt>Bagian</dt>
            <dd>{citation.section || '—'}</dd>
          </div>
          <div className="detail-item">
            <dt>Halaman</dt>
            <dd className="tabular">{citation.page ?? '—'}</dd>
          </div>
          {citation.version && citation.version !== '-' && (
            <div className="detail-item">
              <dt>Versi</dt>
              <dd>{citation.version}</dd>
            </div>
          )}
        </dl>

        <button
          type="button"
          className="citation-action-btn"
          onClick={() => (citation.private
            /* A student's own PDF opens directly at the cited page; it has no
               registry entry to show on the source page. */
            ? window.open(privateFileUrl(citation.documentId, citation.page), '_blank', 'noopener')
            : navigate(`/source/${citation.documentId}`, { state: { citation } }))}
        >
          {citation.private ? 'Buka PDF Anda' : 'Lihat sumber'} <ChevronRight size={15} />
        </button>
      </footer>
    </article>
  );
};

export default CitationCard;
