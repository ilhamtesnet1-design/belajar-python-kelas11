import React from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import { auth, loginUrl } from '../../api/client';
import { AUTH_CONFIG } from '../../config/uploads';
import './MainLayout.css';

/* The student workspace is for signed-in UNP students. The backend enforces
   this too (REQUIRE_STUDENT_LOGIN); this guard just sends people to the
   login page first instead of letting every request fail. */
const MainLayout = () => {
  const location = useLocation();
  if (AUTH_CONFIG.studentLoginRequired && !auth.isLoggedIn) {
    return <Navigate to={loginUrl(location.pathname + location.search)} replace />;
  }
  return (
    <div className="app-layout">
      <Sidebar />
      <div className="main-scrollable-area">
        <main className="main-content-container">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
