import React, { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Anchor, Home, MessageSquare, FileText, ScanText, Menu, X, Bell, User } from 'lucide-react';
import './layout.css';

const Sidebar = ({ isOpen, toggleSidebar }) => {
  return (
    <>
      <div className={`mobile-overlay ${isOpen ? 'open' : ''}`} onClick={toggleSidebar}></div>
      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <NavLink to="/" className="logo">
            <Anchor size={24} />
            Pandu
          </NavLink>
        </div>
        <nav className="sidebar-nav">
          <NavLink to="/dashboard" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`} onClick={toggleSidebar}>
            <Home size={20} />
            Dashboard
          </NavLink>
          <NavLink to="/assistant" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`} onClick={toggleSidebar}>
            <MessageSquare size={20} />
            Asisten Pandu
          </NavLink>
          {/* Using /dashboard for document as user didn't request a separate document list page, just Document Detail, but wait, 'Dokumen' was in the sidebar spec. Let's make it point to dashboard for now or a mockup */}
          <NavLink to="/dashboard" className={({ isActive }) => `nav-item`} onClick={toggleSidebar}>
            <FileText size={20} />
            Dokumen
          </NavLink>
          <NavLink to="/ocr" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`} onClick={toggleSidebar}>
            <ScanText size={20} />
            OCR Dokumen
          </NavLink>
        </nav>
      </aside>
    </>
  );
};

const Header = ({ toggleSidebar }) => {
  const location = useLocation();
  
  let title = "Pandu";
  if (location.pathname.startsWith('/dashboard')) title = "Dashboard";
  else if (location.pathname.startsWith('/assistant')) title = "Asisten Pandu";
  else if (location.pathname.startsWith('/ocr')) title = "OCR Dokumen";
  else if (location.pathname.startsWith('/source')) title = "Detail Sumber";
  else if (location.pathname.startsWith('/document')) title = "Detail Dokumen";

  return (
    <header className="header">
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <button className="mobile-menu-btn" onClick={toggleSidebar}>
          <Menu size={24} />
        </button>
        <span className="header-title">{title}</span>
      </div>
      <div className="header-actions">
        <button className="btn-outline" style={{ border: 'none', padding: '8px' }}>
          <Bell size={20} color="var(--text-secondary)" />
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
          <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--primary-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary-dark)' }}>
            <User size={18} />
          </div>
          <span style={{ fontSize: '14px', fontWeight: '500', display: 'none' }} className="d-md-block">Mahasiswa</span>
        </div>
      </div>
    </header>
  );
};

const Layout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="layout-container">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      <div className="main-content">
        <Header toggleSidebar={toggleSidebar} />
        <main className="page-container">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
