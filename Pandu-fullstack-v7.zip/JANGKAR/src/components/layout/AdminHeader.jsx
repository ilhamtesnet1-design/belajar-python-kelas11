import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Bell, ChevronDown, ChevronRight } from 'lucide-react';
import { api, auth } from '../../api/client';
import './AdminHeader.css';

/* One map, so a new route can never fall through to a generic title the way
   /registri, /validasi and /evaluasi previously did. */
const PAGE_TITLES = [
  ['/admin/dashboard', 'Dashboard Overview'],
  ['/admin/registri', 'Registri Dokumen'],
  ['/admin/ocr', 'OCR Dokumen'],
  ['/admin/validasi', 'Validasi Dokumen'],
  ['/admin/evaluasi', 'Evaluasi Sistem'],
  ['/admin/faq', 'Manajemen FAQ'],
  ['/admin/pengaturan', 'Pengaturan Sistem'],
  ['/admin/mahasiswa', 'Data Mahasiswa'],
  ['/admin/dokumen', 'Dokumen Resmi'],
  ['/admin/proposal', 'Proposal & Tugas Akhir'],
  ['/admin/bimbingan', 'Monitoring Bimbingan'],
];

const AdminHeader = () => {
  const location = useLocation();
  const user = auth.user;
  const [pending, setPending] = useState(0);

  /* The bell shows something real: documents waiting for validation.
     Re-checked on every admin navigation. */
  useEffect(() => {
    api(`/api/documents?status=${encodeURIComponent('Menunggu Validasi')}`)
      .then(rows => setPending(rows.length))
      .catch(() => setPending(0));
  }, [location.pathname]);

  const match = PAGE_TITLES.find(([prefix]) => location.pathname.startsWith(prefix));
  const title = match ? match[1] : 'Admin Control Panel';

  const initials = (user?.name || user?.username || 'Admin')
    .split(' ')
    .slice(0, 2)
    .map(part => part[0])
    .join('')
    .toUpperCase();

  return (
    <header className="admin-header">
      <nav className="admin-breadcrumb" aria-label="Remah roti">
        <Link to="/admin/dashboard">Admin</Link>
        <ChevronRight size={14} aria-hidden="true" />
        <span aria-current="page">{title}</span>
      </nav>

      <div className="admin-header-actions">
        <Link
          to="/admin/validasi"
          className="admin-header-notification"
          aria-label={pending ? `${pending} dokumen menunggu validasi` : 'Tidak ada dokumen menunggu validasi'}
          title={pending ? `${pending} dokumen menunggu validasi` : 'Tidak ada dokumen menunggu validasi'}
        >
          <Bell size={18} />
          {pending > 0 && <span className="admin-notification-count tabular" aria-hidden="true">{pending > 9 ? '9+' : pending}</span>}
        </Link>

        <Link to="/admin/pengaturan" className="admin-header-profile">
          <div className="admin-profile-avatar">{initials}</div>
          <div className="admin-profile-info">
            <span className="admin-profile-name">{user?.name || user?.username || 'Admin'}</span>
            <span className="admin-profile-role">{user?.role || 'Administrator'}</span>
          </div>
          <ChevronDown size={16} aria-hidden="true" />
        </Link>
      </div>
    </header>
  );
};

export default AdminHeader;
