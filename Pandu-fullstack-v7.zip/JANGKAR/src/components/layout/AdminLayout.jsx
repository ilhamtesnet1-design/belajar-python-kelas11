import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { auth } from '../../api/client';
import AdminSidebar from './AdminSidebar';
import AdminHeader from './AdminHeader';
import './AdminLayout.css';

const AdminLayout = () => {
  // Panel admin hanya untuk akun ber-role admin; mahasiswa diarahkan ke ruang mahasiswa.
  if (!auth.token) return <Navigate to="/login?next=/admin/dashboard" replace />;
  if (!auth.isAdmin) return <Navigate to="/dashboard" replace />;
  return (
    <div className="admin-app-layout">
      <AdminSidebar />
      <div className="admin-main-scrollable-area">
        <AdminHeader />
        <main className="admin-main-content-container">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
