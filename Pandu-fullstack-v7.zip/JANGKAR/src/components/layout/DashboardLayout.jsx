import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { MessageSquare, HelpCircle, FileText, Info, Plus, Settings, Bell, LayoutDashboard } from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import './DashboardLayout.css';

export const DashboardLayout = ({ role = 'student' }) => {
  const location = useLocation();
  const isAdmin = role === 'admin';

  return (
    <div className="dashboard-layout">
      {/* Sidebar */}
      <aside className="dashboard-sidebar">
        <div className="sidebar-header">
          <Link to="/" className="logo-link">
            <div className="logo-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/></svg>
            </div>
            <span className="logo-text">Pandu</span>
          </Link>
          {isAdmin && <span className="admin-badge">Admin</span>}
        </div>

        <div className="sidebar-action">
          <Button fullWidth icon={<Plus size={16} />}>
            {isAdmin ? 'Tambah Dokumen' : 'Chat Baru'}
          </Button>
        </div>

        <div className="sidebar-menu-section">
          <p className="menu-label">MENU</p>
          <nav className="sidebar-nav">
            {isAdmin ? (
              <>
                <Link to="/admin" className={`nav-item ${location.pathname === '/admin' ? 'active' : ''}`}>
                  <LayoutDashboard size={18} />
                  <span>Dashboard</span>
                </Link>
                <Link to="/admin/documents" className={`nav-item ${location.pathname.includes('/documents') ? 'active' : ''}`}>
                  <FileText size={18} />
                  <span>Dokumen Resmi</span>
                </Link>
              </>
            ) : (
              <>
                <Link to="/chat" className={`nav-item ${location.pathname === '/chat' ? 'active' : ''}`}>
                  <MessageSquare size={18} />
                  <span>Chat Asisten</span>
                </Link>
                <Link to="#faq" className="nav-item">
                  <HelpCircle size={18} />
                  <span>FAQ</span>
                </Link>
                <Link to="#dokumen" className="nav-item">
                  <FileText size={18} />
                  <span>Dokumen Resmi</span>
                </Link>
                <Link to="#bantuan" className="nav-item">
                  <Info size={18} />
                  <span>Bantuan</span>
                </Link>
              </>
            )}
          </nav>
        </div>

        {!isAdmin && (
          <div className="sidebar-menu-section flex-1">
            <p className="menu-label">RIWAYAT</p>
            <nav className="sidebar-nav history-nav">
              <Link to="/chat?q=syarat-yudisium" className="nav-item history-item active">
                <MessageSquare size={14} />
                <span>Bagaimana syarat yudisium?</span>
              </Link>
              <Link to="/chat?q=jadwal-wisuda" className="nav-item history-item">
                <MessageSquare size={14} />
                <span>Jadwal wisuda 2026...</span>
              </Link>
              <Link to="/chat?q=syarat-tugas-akhir" className="nav-item history-item">
                <MessageSquare size={14} />
                <span>Syarat tugas akhir...</span>
              </Link>
            </nav>
          </div>
        )}

        <div className="sidebar-footer">
          <div className="user-profile">
            <div className="user-avatar">
              {isAdmin ? 'AD' : 'MA'}
            </div>
            <div className="user-info">
              <p className="user-name">{isAdmin ? 'Administrator' : 'Mahasiswa UNP'}</p>
              <p className="user-id">{isAdmin ? 'NIP: 19800101...' : 'NIM: 21234567890'}</p>
            </div>
            <button className="settings-btn">
              <Settings size={18} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="dashboard-main-area">
        {/* Header */}
        <header className="dashboard-header">
          <div className="header-title-area">
            <h1 className="header-title">{isAdmin ? 'Admin Dashboard' : 'Asisten Pandu'}</h1>
            <div className="status-indicator">
              <span className="status-dot"></span>
              <span className="status-text">Sistem aktif</span>
            </div>
          </div>
          <div className="header-actions">
            <Badge variant="default" className="doc-count-badge">
              <FileText size={14} /> 24 Dokumen {isAdmin ? 'Terdaftar' : 'Aktif'}
            </Badge>
            <button className="notification-btn">
              <Bell size={20} />
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="dashboard-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
