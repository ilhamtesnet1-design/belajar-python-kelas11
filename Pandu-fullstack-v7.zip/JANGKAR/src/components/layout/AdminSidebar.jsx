import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Library,
  ScanText,
  CheckSquare,
  BarChart4,
  HelpCircle,
  Settings,
  LogOut,
} from 'lucide-react';
import { auth } from '../../api/client';
import './AdminSidebar.css';
import BrandMark from '../brand/BrandMark';

/* Grouped so the sidebar reads as three jobs rather than one flat list:
   get documents in, keep quality honest, run the system. */
const menuGroups = [
  {
    label: 'Ikhtisar',
    items: [
      { path: '/admin/dashboard', name: 'Dashboard', icon: LayoutDashboard },
    ],
  },
  {
    label: 'Dokumen',
    items: [
      { path: '/admin/registri', name: 'Registri Dokumen', icon: Library },
      { path: '/admin/ocr', name: 'OCR Dokumen', icon: ScanText },
      { path: '/admin/validasi', name: 'Validasi Dokumen', icon: CheckSquare },
    ],
  },
  {
    label: 'Kualitas & Sistem',
    items: [
      { path: '/admin/evaluasi', name: 'Evaluasi Sistem', icon: BarChart4 },
      { path: '/admin/faq', name: 'FAQ', icon: HelpCircle },
      { path: '/admin/pengaturan', name: 'Pengaturan', icon: Settings },
    ],
  },
];

const AdminSidebar = () => {
  const navigate = useNavigate();
  const user = auth.user;

  /* Signing out has to drop the token, not just change the URL. */
  const signOut = () => {
    auth.clear();
    navigate('/login', { replace: true });
  };

  return (
    <aside className="admin-sidebar">
      <div className="admin-sidebar-header">
        <BrandMark size={34} className="admin-sidebar-mark" />
        <div>
          <div className="admin-sidebar-title">Pandu</div>
          <div className="admin-sidebar-sub">Panel Admin</div>
        </div>
      </div>

      <nav className="admin-sidebar-nav">
        {menuGroups.map(group => (
          <div className="admin-sidebar-group" key={group.label}>
            <span className="admin-sidebar-group-label">{group.label}</span>
            {group.items.map(item => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => `admin-sidebar-item ${isActive ? 'active' : ''}`}
                >
                  <Icon size={18} />
                  <span>{item.name}</span>
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="admin-sidebar-footer">
        {user && (
          <div className="admin-sidebar-user">
            <span className="admin-sidebar-user-avatar">
              {(user.name || user.username || 'A').slice(0, 1).toUpperCase()}
            </span>
            <div className="admin-sidebar-user-text">
              <strong>{user.name || user.username || 'Admin'}</strong>
              <span>{user.role || 'Administrator'}</span>
            </div>
          </div>
        )}
        <button type="button" className="admin-sidebar-item as-button" onClick={signOut}>
          <LogOut size={18} />
          <span>Keluar</span>
        </button>
      </div>
    </aside>
  );
};

export default AdminSidebar;
