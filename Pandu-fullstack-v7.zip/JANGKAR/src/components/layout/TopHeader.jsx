import React from 'react';
import './TopHeader.css';

const TopHeader = ({ title, action }) => {
  return (
    <header className="global-top-header">
      <div className="header-left">
        <h1 className="header-page-title">{title}</h1>
      </div>
      {action && (
        <div className="header-right">
          {action}
        </div>
      )}
    </header>
  );
};

export default TopHeader;
