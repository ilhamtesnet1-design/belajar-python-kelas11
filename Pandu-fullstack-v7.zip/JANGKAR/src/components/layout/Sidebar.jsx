import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { MessageSquare, FileText, ScanText, LogOut, Menu, X, Plus, Settings, HelpCircle, MessageCircleQuestion, History } from 'lucide-react';
import Button from '../common/Button';
import { auth } from '../../api/client';
import { listConversations, migrateLocalHistory } from '../../api/history';
import './Sidebar.css';
import BrandMark from '../brand/BrandMark';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [recentHistory, setRecentHistory] = useState([]);
  const navigate = useNavigate();
  const user = auth.user;
  const initials = (user?.name || 'Mahasiswa').split(' ').filter(Boolean).slice(0, 2).map(p => p[0]).join('').toUpperCase();

  /* Signing out drops the session on this device; the chat history stays in
     the account and reappears on the next sign-in, here or on another device. */
  const signOut = () => {
    auth.clear();
    navigate('/', { replace: true });
  };

  useEffect(() => {
    const loadHistory = () => listConversations()
      .then(rows => setRecentHistory(rows.slice(0, 8)))
      .catch(() => setRecentHistory([]));

    /* Chats older versions kept only in this browser move into the account once. */
    migrateLocalHistory().finally(loadHistory);
    window.addEventListener('jangkar_history_update', loadHistory);
    return () => window.removeEventListener('jangkar_history_update', loadHistory);
  }, []);

  const navItems = [
    { name: 'Chat Asisten', path: '/assistant', icon: MessageSquare },
    { name: 'Riwayat Chat', path: '/riwayat', icon: History },
    { name: 'FAQ', path: '/faq', icon: MessageCircleQuestion },
    { name: 'Dokumen Resmi', path: '/documents', icon: FileText },
    { name: 'OCR', path: '/ocr', icon: ScanText },
    { name: 'Bantuan', path: '/help', icon: HelpCircle },
  ];

  const toggleSidebar = () => setIsOpen(!isOpen);

  return (
    <>
      <button className="mobile-menu-btn" onClick={toggleSidebar}>
        <Menu size={24} />
      </button>

      <div className={`sidebar-overlay ${isOpen ? 'show' : ''}`} onClick={toggleSidebar}></div>

      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo"><BrandMark size={30} /> Pandu</div>
          <button className="sidebar-close-btn" onClick={toggleSidebar}>
            <X size={20} />
          </button>
        </div>

        <div className="sidebar-action">
          <Button 
            fullWidth 
            onClick={() => {
              navigate(`/assistant?new=${Date.now()}`);
              setIsOpen(false);
            }} 
            icon={<Plus size={18} />}
          >
            Chat Baru
          </Button>
        </div>

        <div className="sidebar-content">
          <nav className="sidebar-nav">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
                onClick={() => setIsOpen(false)}
              >
                <item.icon className="nav-icon" size={18} />
                <span className="nav-text">{item.name}</span>
              </NavLink>
            ))}
          </nav>

          <div className="sidebar-section">
            <span className="section-label">RIWAYAT</span>
            <div className="history-list">
              {recentHistory.map((hist) => (
                <button 
                  key={hist.id} 
                  className="history-item"
                  onClick={() => {
                    navigate(`/assistant?chatId=${hist.id}`);
                    setIsOpen(false);
                  }}
                >
                  <MessageSquare size={14} className="history-icon" />
                  <span className="history-text">{hist.title}</span>
                </button>
              ))}
              {recentHistory.length === 0 && (
                <div style={{ padding: '0 16px', fontSize: '13px', color: 'var(--text-muted)' }}>Belum ada riwayat</div>
              )}
            </div>
          </div>
        </div>

        <div className="sidebar-footer">
          <div className="profile-section">
            <div className="avatar">{initials}</div>
            <div className="profile-info">
              <span className="profile-name">{user?.name || 'Mahasiswa'}</span>
              <span className="profile-role" title={user?.email}>{user?.email || 'Mahasiswa UNP'}</span>
            </div>
            
            <div className="profile-actions">
              <button className="icon-btn" title="Pengaturan" onClick={() => { navigate('/settings'); setIsOpen(false); }}>
                <Settings size={16} />
              </button>
              <button className="icon-btn" title="Keluar" aria-label="Keluar" onClick={signOut}>
                <LogOut size={16} />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
