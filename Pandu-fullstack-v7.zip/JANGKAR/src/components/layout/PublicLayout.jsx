import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { Button } from '../ui/Button';
import './PublicLayout.css';

export const PublicLayout = () => {
  return (
    <div className="public-layout">
      <header className="public-header">
        <div className="container public-header-inner">
          <Link to="/" className="logo-link">
            <div className="logo-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/></svg>
            </div>
            <span className="logo-text">Pandu</span>
          </Link>
          <nav className="public-nav">
            <Link to="/">Beranda</Link>
            <Link to="#tentang">Tentang</Link>
            <Link to="#cara-kerja">Cara Kerja</Link>
            <Link to="#dokumen">Dokumen Resmi</Link>
            <Link to="#faq">FAQ</Link>
          </nav>
          <div className="public-actions">
            <Link to="/login">
              <Button variant="ghost">Masuk</Button>
            </Link>
            <Link to="/chat">
              <Button variant="primary">Mulai Bertanya</Button>
            </Link>
          </div>
        </div>
      </header>
      
      <main className="public-main">
        <Outlet />
      </main>
      
      <footer className="public-footer">
        <div className="container public-footer-inner">
          <div className="footer-col">
            <div className="logo-link logo-footer">
              <div className="logo-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/></svg>
              </div>
              <span className="logo-text">Pandu</span>
            </div>
            <p className="footer-desc">
              Asisten Informasi akademik resmi Universitas Negeri Padang berbasis teknologi RAG.
            </p>
            <p className="footer-copyright">
              © 2026 Pandu — Universitas Negeri Padang.
            </p>
          </div>
          <div className="footer-col">
            <h4 className="footer-heading">Navigasi</h4>
            <Link to="/">Beranda</Link>
            <Link to="#tentang">Tentang Pandu</Link>
            <Link to="#cara-kerja">Cara Kerja</Link>
            <Link to="#dokumen">Dokumen Resmi</Link>
            <Link to="#faq">FAQ</Link>
          </div>
          <div className="footer-col">
            <h4 className="footer-heading">Layanan</h4>
            <Link to="/chat">Mulai Bertanya</Link>
            <Link to="/login">Riwayat Pencarian</Link>
            <Link to="#bantuan">Bantuan</Link>
          </div>
          <div className="footer-col">
            <h4 className="footer-heading">Informasi</h4>
            <Link to="#kebijakan">Kebijakan Privasi</Link>
            <Link to="#syarat">Syarat & Ketentuan</Link>
            <Link to="#kontak">Kontak Akademik</Link>
          </div>
          <div className="footer-col">
            <h4 className="footer-heading">Kontak</h4>
            <p>akademik@unp.ac.id</p>
            <p>Padang, Sumatera Barat</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
