import React from 'react';
import './AppHeader.css';

const AppHeader = ({ eyebrow, title, description, action }) => {
  return (
    <div className="app-header">
      <div className="header-content">
        {eyebrow && <span className="header-eyebrow">{eyebrow}</span>}
        <h1 className="header-title">{title}</h1>
        {description && <p className="header-description">{description}</p>}
      </div>
      {action && (
        <div className="header-action">
          {action}
        </div>
      )}
    </div>
  );
};

export default AppHeader;
