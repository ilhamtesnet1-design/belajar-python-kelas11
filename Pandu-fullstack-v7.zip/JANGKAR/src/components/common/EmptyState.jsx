import React from 'react';

const EmptyState = ({ icon: Icon, title, description }) => {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '48px 24px',
      textAlign: 'center',
      backgroundColor: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      height: '100%'
    }}>
      {Icon && (
        <div style={{
          backgroundColor: 'var(--primary-light)',
          color: 'var(--primary)',
          padding: '16px',
          borderRadius: '50%',
          marginBottom: '16px'
        }}>
          <Icon size={32} />
        </div>
      )}
      <h3 style={{ marginBottom: '8px' }}>{title}</h3>
      <p style={{ color: 'var(--text-secondary)', maxWidth: '400px' }}>{description}</p>
    </div>
  );
};

export default EmptyState;
