import React from 'react';
import { AlertCircle } from 'lucide-react';
import './StateUI.css';
import Button from './Button';

export const EmptyState = ({ icon: Icon, title, description, action }) => (
  <div className="state-ui-container">
    {Icon && <div className="state-ui-icon empty-icon"><Icon size={48} /></div>}
    <h3 className="state-ui-title">{title}</h3>
    <p className="state-ui-description">{description}</p>
    {action && (
      <div className="state-ui-action">
        <Button onClick={action.onClick}>{action.label}</Button>
      </div>
    )}
  </div>
);

export const ErrorState = ({ title = "Terjadi Kesalahan", description, onRetry }) => (
  <div className="state-ui-container error-state">
    <div className="state-ui-icon error-icon"><AlertCircle size={48} /></div>
    <h3 className="state-ui-title">{title}</h3>
    <p className="state-ui-description">{description}</p>
    {onRetry && (
      <div className="state-ui-action">
        <Button variant="outline" onClick={onRetry}>Coba Lagi</Button>
      </div>
    )}
  </div>
);

export const LoadingState = ({ message = "Memuat data..." }) => (
  <div className="state-ui-container">
    <div className="state-ui-spinner"></div>
    <p className="state-ui-description">{message}</p>
  </div>
);
