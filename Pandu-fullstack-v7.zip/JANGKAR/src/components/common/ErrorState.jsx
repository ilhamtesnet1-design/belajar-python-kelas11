import React from 'react';
import { AlertCircle } from 'lucide-react';
import Button from './Button';

const ErrorState = ({ title = 'Terjadi Kesalahan', description = 'Gagal memproses permintaan Anda.', onRetry }) => {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '48px 24px',
      textAlign: 'center',
      backgroundColor: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)'
    }}>
      <div style={{
        backgroundColor: '#FEF2F2',
        color: 'var(--error)',
        padding: '16px',
        borderRadius: '50%',
        marginBottom: '16px'
      }}>
        <AlertCircle size={32} />
      </div>
      <h3 style={{ marginBottom: '8px' }}>{title}</h3>
      <p style={{ color: 'var(--text-secondary)', marginBottom: onRetry ? '24px' : '0' }}>{description}</p>
      
      {onRetry && (
        <Button variant="secondary" onClick={onRetry}>
          Coba Lagi
        </Button>
      )}
    </div>
  );
};

export default ErrorState;
