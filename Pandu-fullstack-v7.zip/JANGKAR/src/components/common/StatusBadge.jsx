import React from 'react';
import Badge from './Badge';

const StatusBadge = ({ status }) => {
  let badgeVariant = 'gray';

  // Map known statuses to colors
  const s = status?.toLowerCase() || '';
  if (s.includes('verifikasi') || s.includes('resmi')) {
    badgeVariant = 'success';
  } else if (s.includes('menunggu') || s.includes('proses')) {
    badgeVariant = 'warning';
  } else if (s.includes('error') || s.includes('gagal')) {
    badgeVariant = 'error';
  }

  return <Badge variant={badgeVariant}>{status}</Badge>;
};

export default StatusBadge;
