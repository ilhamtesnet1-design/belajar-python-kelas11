import React from 'react';
import './Badge.css';

const Badge = ({ children, variant = 'gray', className = '' }) => {
  return (
    <span className={`jangkar-badge badge-${variant} ${className}`}>
      {children}
    </span>
  );
};

export default Badge;
