import React from 'react';
import './Card.css';

const Card = ({ children, padding = 'md', className = '', onClick }) => {
  const isClickable = !!onClick;
  const classes = [
    'jangkar-card',
    `card-padding-${padding}`,
    isClickable ? 'card-clickable' : '',
    className
  ].filter(Boolean).join(' ');

  return (
    <div className={classes} onClick={onClick}>
      {children}
    </div>
  );
};

export default Card;
