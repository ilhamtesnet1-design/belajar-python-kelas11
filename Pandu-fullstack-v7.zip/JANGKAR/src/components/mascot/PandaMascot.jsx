import React, { useEffect, useMemo, useState } from 'react';
import './PandaMascot.css';

/* Every pose, bundled by the build (hashed URLs), 256px + 512px for high-DPI screens. */
import p_hello from '../../assets/mascot/panda-hello.webp';
import p_hello2x from '../../assets/mascot/panda-hello@2x.webp';
import p_cheer from '../../assets/mascot/panda-cheer.webp';
import p_cheer2x from '../../assets/mascot/panda-cheer@2x.webp';
import p_wave from '../../assets/mascot/panda-wave.webp';
import p_wave2x from '../../assets/mascot/panda-wave@2x.webp';
import p_worried from '../../assets/mascot/panda-worried.webp';
import p_worried2x from '../../assets/mascot/panda-worried@2x.webp';
import p_surprised from '../../assets/mascot/panda-surprised.webp';
import p_surprised2x from '../../assets/mascot/panda-surprised@2x.webp';
import p_laugh from '../../assets/mascot/panda-laugh.webp';
import p_laugh2x from '../../assets/mascot/panda-laugh@2x.webp';
import p_thinking from '../../assets/mascot/panda-thinking.webp';
import p_thinking2x from '../../assets/mascot/panda-thinking@2x.webp';
import p_determined from '../../assets/mascot/panda-determined.webp';
import p_determined2x from '../../assets/mascot/panda-determined@2x.webp';
import p_reading from '../../assets/mascot/panda-reading.webp';
import p_reading2x from '../../assets/mascot/panda-reading@2x.webp';
import p_sleeping from '../../assets/mascot/panda-sleeping.webp';
import p_sleeping2x from '../../assets/mascot/panda-sleeping@2x.webp';
import p_wave_small from '../../assets/mascot/panda-wave-small.webp';
import p_wave_small2x from '../../assets/mascot/panda-wave-small@2x.webp';
import p_back from '../../assets/mascot/panda-back.webp';
import p_back2x from '../../assets/mascot/panda-back@2x.webp';
import p_backpack from '../../assets/mascot/panda-backpack.webp';
import p_backpack2x from '../../assets/mascot/panda-backpack@2x.webp';
import p_semangat from '../../assets/mascot/panda-semangat.webp';
import p_semangat2x from '../../assets/mascot/panda-semangat@2x.webp';

const POSES = {
  'hello': { x1: p_hello, x2: p_hello2x },
  'cheer': { x1: p_cheer, x2: p_cheer2x },
  'wave': { x1: p_wave, x2: p_wave2x },
  'worried': { x1: p_worried, x2: p_worried2x },
  'surprised': { x1: p_surprised, x2: p_surprised2x },
  'laugh': { x1: p_laugh, x2: p_laugh2x },
  'thinking': { x1: p_thinking, x2: p_thinking2x },
  'determined': { x1: p_determined, x2: p_determined2x },
  'reading': { x1: p_reading, x2: p_reading2x },
  'sleeping': { x1: p_sleeping, x2: p_sleeping2x },
  'wave-small': { x1: p_wave_small, x2: p_wave_small2x },
  'back': { x1: p_back, x2: p_back2x },
  'backpack': { x1: p_backpack, x2: p_backpack2x },
  'semangat': { x1: p_semangat, x2: p_semangat2x },
};

/* What the panda does in each situation. `captions` advance with the frames. */
const MOODS = {
  searching: {
    frames: ['reading', 'thinking', 'determined', 'reading', 'surprised'],
    interval: 750,
    captions: ['Membuka dokumen resmi…', 'Mencari pasal yang cocok…', 'Memeriksa sumbernya…', 'Menyusun jawaban…'],
    label: 'Pandu sedang mencari jawaban di dokumen resmi',
  },
  'reading-own': {
    frames: ['reading', 'thinking', 'reading', 'backpack'],
    interval: 800,
    captions: ['Membaca dokumen Anda…', 'Mencari bagian yang relevan…', 'Menyusun jawaban…'],
    label: 'Pandu sedang membaca dokumen Anda',
  },
  uploading: {
    frames: ['backpack', 'reading'],
    interval: 900,
    captions: ['Menerima PDF…', 'Membaca isi dokumen…'],
    label: 'Dokumen sedang diproses',
  },
  history: {
    frames: ['back', 'reading'],
    interval: 700,
    captions: ['Membuka riwayat chat…'],
    label: 'Memuat riwayat chat',
  },
  welcome: { frames: ['hello', 'wave', 'hello', 'wave-small'], interval: 1600, label: '' },
  answered: { frames: ['cheer', 'laugh'], interval: 650, label: '' },
  refused: { frames: ['worried'], label: '' },
  error: { frames: ['sleeping'], label: '' },
  encourage: { frames: ['semangat'], label: '' },
};

const reducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/* Fetch every frame of a mood up front so swapping never shows a blank. */
const preload = (names) => names.forEach((n) => {
  const p = POSES[n];
  if (!p) return;
  const img = new Image();
  img.src = p.x1;
  if (p.x2) img.srcset = `${p.x1} 1x, ${p.x2} 2x`;
});

const PandaMascot = ({ mood = 'searching', size = 72, caption = false, className = '' }) => {
  const cfg = MOODS[mood] || MOODS.searching;
  const [tick, setTick] = useState(0);
  const still = useMemo(reducedMotion, []);

  useEffect(() => { preload(cfg.frames); setTick(0); }, [mood]);

  useEffect(() => {
    if (still || cfg.frames.length < 2) return undefined;
    const t = setInterval(() => setTick((n) => n + 1), cfg.interval);
    return () => clearInterval(t);
  }, [mood, still]);

  const pose = cfg.frames[tick % cfg.frames.length];
  const src = POSES[pose] || POSES.hello;
  const text = cfg.captions ? cfg.captions[Math.floor(tick / 2) % cfg.captions.length] : null;

  return (
    <div className={`panda-mascot ${className}`} style={{ '--panda-size': `${size}px` }}>
      <span className="panda-stage" aria-hidden="true">
        {/* key forces a fresh element per pose, which replays the hop */}
        <img
          key={`${pose}-${tick}`}
          className={still ? '' : 'panda-hop'}
          src={src.x1}
          srcSet={src.x2 ? `${src.x1} 1x, ${src.x2} 2x` : undefined}
          width={size}
          height={size}
          alt=""
          draggable="false"
        />
      </span>
      {cfg.label && <span className="sr-only" role="status">{cfg.label}</span>}
      {caption && text && <span key={text} className="panda-caption" aria-hidden="true">{text}</span>}
    </div>
  );
};

export default PandaMascot;
