import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, ArrowRight } from 'lucide-react';
import Card from '../common/Card';
import StatusBadge from '../common/StatusBadge';
import './DocumentCard.css';

const DocumentCard = ({ document }) => {
  const navigate = useNavigate();

  return (
    <Card className="document-card" onClick={() => navigate(`/document/${document.id}`)}>
      <div className="doc-card-header">
        <div className="doc-icon-wrapper">
          <FileText size={20} className="doc-icon" />
        </div>
        <StatusBadge status={document.status} />
      </div>
      
      <div className="doc-card-body">
        <h3 className="doc-title">{document.name}</h3>
        <p className="doc-category">{document.category} • {document.version}</p>
      </div>
      
      <div className="doc-card-footer">
        <span className="doc-pages">{document.pages} Halaman</span>
        <div className="doc-action">
          Lihat Detail <ArrowRight size={16} />
        </div>
      </div>
    </Card>
  );
};

export default DocumentCard;
