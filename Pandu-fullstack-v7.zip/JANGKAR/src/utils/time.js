/**
 * The backend stores UTC. On SQLite the timezone is dropped on the way out,
 * so "2026-10-20T02:22:00" arrives without a "Z" — read that as UTC, not as
 * local time, or every timestamp shifts by the WIB offset.
 */
export function parseServerDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  const s = String(value);
  const hasZone = /([zZ]|[+-]\d{2}:?\d{2})$/.test(s);
  const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(s);
  const d = new Date(hasZone || isDateOnly ? s : `${s}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

const hm = d => d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace(':', '.');

/** "Hari ini, 09.22" · "Kemarin, 16.10" · "3 hari lalu" · "12 Okt 2026" */
export function formatWhen(value, now = new Date()) {
  const d = parseServerDate(value);
  if (!d) return '—';
  const startOf = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const days = Math.round((startOf(now) - startOf(d)) / 86400000);
  if (days <= 0) return `Hari ini, ${hm(d)}`;
  if (days === 1) return `Kemarin, ${hm(d)}`;
  if (days < 7) return `${days} hari lalu`;
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

/** Whole days from today until a date-only value; negative once it has passed. */
export function daysUntil(value, now = new Date()) {
  const d = parseServerDate(value);
  if (!d) return null;
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const target = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  return Math.round((target - today) / 86400000);
}
