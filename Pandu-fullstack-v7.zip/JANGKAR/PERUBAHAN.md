# Perubahan UI JANGKAR

Palet navy #123B66 + emas #C9A24D dan font Inter/Poppins dipertahankan.

## Batas unggah — satu sumber kebenaran
`src/config/uploads.js`. Sebelumnya tidak konsisten (Registri 10MB, AddDocument 20MB, OCR 5MB).
- Dokumen PDF: 100 MB
- Arsip ZIP (batch): 200 MB, maks. 50 dokumen
- Scan OCR (PDF/PNG/JPG): 25 MB
- Foto profil: 5 MB
Ubah angka di file ini, semua layar ikut. Catatan: batas di backend (FastAPI/proxy) harus disamakan.

## Bug yang diperbaiki
- Tombol "Keluar" admin tidak menghapus token (sesi tetap aktif).
- Judul header admin salah di /registri, /validasi, /evaluasi.
- Status penolakan (refused) dari backend tidak pernah ditampilkan di chat.
- Kutipan dokumen (`quote`) tidak pernah dirender di kartu sitasi.
- SourceDetail & DocumentDetail menampilkan layar kosong saat memuat / dokumen tidak ada.
- Tombol "Filter" di Registri & Validasi tidak berfungsi.
- Halaman Validasi: tombol "Periksa" hanya alert().

## Fitur baru
- Chart SVG asli (tanpa library): status dokumen di dashboard, tren evaluasi + garis target di Evaluasi.
- Panel tinjauan Validasi: metadata, buka PDF, checklist wajib, catatan (wajib saat menolak), setujui/tolak via API.
- Upload drag & drop dengan validasi ukuran/format dan pesan error yang jelas.
- Chat: textarea yang membesar, Enter kirim / Shift+Enter baris baru, salin jawaban, tanya ulang, sitasi bernomor.
- Dashboard mahasiswa: "Lanjutkan percakapan" dari riwayat lokal.
- Empty state & skeleton loading di tabel admin.
- Login: error inline, penjelasan peran mahasiswa/admin.

## File baru
src/config/uploads.js · src/components/charts/{BarChart,TrendLine}.jsx, charts.css · src/pages/admin/Validasi.css

## Belum dikerjakan
Halaman legacy (Mahasiswa, Dokumen, Proposal, Bimbingan) dan duplikat komponen ui/ vs common/ tidak disentuh.
Data di admin Dashboard & Evaluasi masih contoh statis — sambungkan ke API bila endpoint-nya ada.

---

# Tahap 2 — Integrasi dengan jangkar-backend

Semua halaman admin & mahasiswa utama kini memakai API backend; tidak ada lagi angka contoh di Dashboard, Evaluasi, OCR, Pengaturan.
Setiap panggilan `api()` di frontend sudah dicocokkan otomatis dengan route backend (35/35 cocok, termasuk metode HTTP).

## Backend — yang ditambah/diubah
| Endpoint | Fungsi |
|---|---|
| `GET /api/config/public` | batas unggah; frontend membacanya saat start (`loadUploadLimits` di main.jsx) |
| `POST /api/documents` | batas dari `MAX_UPLOAD_MB` (100MB), berkas di-stream ke disk per 1MB, bukan dimuat utuh ke RAM |
| `POST /api/documents/batch` | unggah ZIP (200MB, maks. 50 PDF); tahan zip bomb, lewati duplikat & non-PDF dengan alasan |
| `GET /api/dashboard/activity` | linimasa aktivitas dari jejak waktu registri & evaluasi |
| `GET /api/dashboard/summary` | + `expiring_soon` (≤30 hari), `eval_questions` |
| `GET /api/dashboard/system` | konfigurasi aktif untuk Pengaturan (hanya baca) |
| `PATCH /api/auth/me`, `POST /api/auth/password` | ubah nama & kata sandi admin (dibatasi laju) |

Tidak ada perubahan skema database — `jangkar.db` lama tetap bisa dipakai. Tes baru di `tests/test_api.py` (jalankan `pytest`).

## Frontend — yang tersambung
- Dashboard admin: statistik, grafik status, aktivitas, antrean → data asli.
- Registri: unggah PDF **atau ZIP**; tombol Edit kini menyimpan lewat PATCH.
- Validasi: catatan dikirim ke backend; tombol setujui terkunci sampai teks selesai diolah; antrean memperbarui diri tiap 5 detik.
- Evaluasi: metrik dari run terakhir, tren dari riwayat run, tombol "Jalankan evaluasi", impor CSV, detail per pertanyaan, panel penggunaan nyata.
- OCR → "Pengolahan Teks Dokumen": teks hasil ekstraksi asli, proses ulang, tempel teks OCR untuk PDF hasil pindai (pemisah halaman `---`).
- Pengaturan: profil, ganti kata sandi, konfigurasi sistem.
- Chat: tombol "Membantu? Ya/Tidak" → umpan balik; error server tidak lagi tampil sebagai "informasi tidak ditemukan".
- Dashboard mahasiswa: dokumen dari API (sebelumnya data statis ber-id `doc-1` yang selalu "tidak ditemukan").
- Tanggal dari server (UTC) ditampilkan benar dalam WIB (`src/utils/time.js`).

## Masih statis
FAQ (admin & mahasiswa), OCR mahasiswa (`/ocr`), halaman legacy (Mahasiswa/Dokumen/Proposal/Bimbingan). `src/pages/Document.jsx` mengimpor `mockDocuments` yang tidak ada, tapi tidak dipakai di routing.
Backend tidak punya mesin OCR — teks OCR dibuat di luar (mis. Tesseract) lalu ditempel di halaman Pengolahan Teks.

---

# Tahap 3 — Landing page interaktif + pemeriksaan menyeluruh

## Cara verifikasi kali ini
Frontend di-build sungguhan dengan `bun` (180+ modul, tanpa error), lalu dijalankan di Chromium dengan server tiruan
yang meniru respons backend. Alur klik diuji otomatis: demo landing (pilih contoh & ketik sendiri), lanjut ke Asisten,
FAQ dari API, kartu dokumen → detail, validasi form FAQ & Registri, menu HP. Tidak ada error JavaScript.
Backend tetap belum dijalankan di sini (FastAPI tidak bisa di-install) — jalankan `pytest`.

## Landing page (`/`)
- Demo "Coba langsung" memanggil `POST /api/chat/ask` sungguhan: jawaban + kutipan sumber, atau status penolakan.
- Jumlah dokumen dan daftar dokumen diambil dari `/api/documents/public`; kartu membuka detail dokumen.
- "Cara Kerja" berupa tab interaktif (klik atau panah keyboard), sesuai tahap pipeline RAG di backend.
- FAQ diambil dari backend (`/api/faq`), dengan daftar bawaan bila server mati.
- Navigasi menandai bagian yang sedang dibaca; menu hamburger di HP; konten tidak lagi bergantung pada animasi scroll untuk terlihat.

## Ditemukan & diperbaiki saat pemeriksaan menyeluruh
- FAQ admin: tombol Tambah/Edit/Hapus/Filter tidak berfungsi → FAQ kini tersimpan di backend (tabel baru `faqs`, migrasi `0002_faq`).
- FAQ mahasiswa: isi statis dengan klaim "100% valid" → diambil dari backend, klaim diganti yang jujur.
- Lonceng notifikasi admin selalu bertitik merah tanpa makna → kini jumlah dokumen menunggu validasi, membuka antrean.
- Pengaturan mahasiswa menampilkan NIM & prodi palsu (bertentangan dengan "tanpa akun") → kini riwayat percakapan (bisa dihapus) + penjelasan privasi.
- Sidebar mahasiswa menampilkan "NIM:12345678" → "Tanpa akun".
- Registri: 11 `alert()` → pesan di halaman dan di form.
- Bentrok nama kelas CSS antar halaman (`.stat-item`, `.faq-item`, `.header-actions`) yang merusak tampilan landing.
- Label target grafik Evaluasi terpotong/menabrak garis; tombol "Tambah Dokumen" terlipat dua baris.

## Masih statis / di luar cakupan
Halaman OCR mahasiswa (`/ocr`) masih contoh; halaman legacy (Mahasiswa, Dokumen, Proposal, Bimbingan) tidak ada di menu dan tidak disentuh.

---

# Tahap 4 — Khusus mahasiswa UNP, 6 dokumen di database, tanya PDF sendiri

## Akses
- Mahasiswa wajib daftar/masuk sebelum bertanya (email apa pun untuk sementara; nanti SSO UNP).
  Batasi ke email kampus kapan saja lewat `ALLOWED_EMAIL_DOMAINS` di `.env` backend.
- Landing: tombol "Masuk / Daftar"; "Masuk Admin" pindah ke footer. Pertanyaan di demo dibawa melewati pendaftaran lalu langsung dijawab.
- Akun mahasiswa tidak bisa membuka panel admin (frontend mengalihkan, backend menolak 403).
- Bug lama diperbaiki: login dengan email tanpa kata "admin" sebelumnya langsung masuk asisten tanpa autentikasi.

## Database (`jangkar-backend/jangkar.db`)
| Dokumen | Status | Alasan |
|---|---|---|
| Kalender Akademik UNP 2026/2027 | Terverifikasi | berlaku s.d. 30 Juni 2027 |
| Juknis Pendaftaran Yudisium (Portal) | Terverifikasi | panduan portal, tanpa batas waktu |
| Buku Panduan PKL | Terverifikasi | hlm. 1–8 (sampul & daftar isi) dilewati |
| Jadwal & Tata Cara Pendaftaran Yudisium (Wisuda 143) | Kedaluwarsa | periode Januari–Juni 2026 sudah lewat; hlm. 2 berupa gambar |
| Jadwal & Tata Cara Pendaftaran Wisuda Periode 143 | Kedaluwarsa | wisuda 29–30 Juni 2026 sudah lewat |
| Pelaksanaan TA Mahasiswa UNP | Menunggu Validasi | hasil pindai tanpa teks — perlu OCR |
Verifikasi otomatis ini hanya untuk pengembangan — tinjau ulang di panel admin.
Bug database lama diperbaiki: kolom `documents.skip_pages` tidak ada sehingga backend error saat membaca dokumen;
kini backend menambahkan kolom yang tertinggal secara otomatis saat start.

## Tanya PDF sendiri
- Tombol klip di Chat → unggah PDF → tanyakan apa saja; termasuk "ringkas dokumen ini" / "apa isi utamanya".
- Jawaban berlabel "Dari dokumen Anda", tombol "Buka PDF Anda" membuka halaman yang dikutip.
- Hanya pemilik yang bisa mengakses; tidak dicatat; terhapus otomatis setelah 72 jam; kelola di Pengaturan.

## Penting: kualitas jawaban
Dengan `LLM_PROVIDER=fake` (bawaan), JANGKAR tidak menyusun jawaban — hanya mengambil satu kalimat dokumen,
dan dengan ambang bawaan 0.35 hampir semua pertanyaan ditolak. Untuk jawaban yang mengikuti permintaan
pengguna, pakai model sungguhan (OpenAI, atau Ollama lokal gratis) — lihat `.env.example`, lalu `python -m scripts.reingest_all`.

---

# Tahap 5 — Siap dipakai dengan model gratis (Gemini free tier / Ollama)
- Penilaian "apakah potongan dokumen memuat jawaban" kini 1 panggilan untuk semua potongan (sebelumnya 1 panggilan
  per potongan). Satu pertanyaan = 2 panggilan model, bukan 6 — penting agar kuota jalur gratis tidak cepat habis.
- Saat API membalas 429 (batas laju), backend menunggu sebentar lalu mencoba sekali lagi.
- Alamat API dengan garis miring di akhir tidak lagi menghasilkan URL ganda (`//chat/completions`).
- `.env.example` berisi contoh konfigurasi Gemini.

---

# Tahap 6 — Maskot panda merah
- 14 pose dipotong dari lembar stiker, latar transparan, pinggiran kuning/merah sisa penghapusan latar dibersihkan,
  semua pose berdiri di garis lantai yang sama. File: `src/assets/mascot/` (WebP 256px + 512px untuk layar tajam).
- Komponen `src/components/mascot/PandaMascot.jsx`, dipakai di:
  - Chat & demo landing saat mencari jawaban: membaca → berpikir → serius → membaca → kaget, dengan keterangan
    "Membuka dokumen resmi… / Mencari pasal yang cocok… / Memeriksa sumbernya… / Menyusun jawaban…"
  - Saat menanyakan PDF sendiri: membaca ↔ berpikir ↔ ransel
  - Sambutan chat: menyapa ↔ melambai · Jawaban ditolak: cemas · Server mati: tidur · Ajakan login: "Semangat Terus!"
- Setiap ganti pose ada lompatan kecil; berhenti beranimasi bila pengguna mengaktifkan "kurangi gerakan".

---

# Tahap 7 — Nama Pandu, aplikasi HP, riwayat chat di akun
- **Nama baru: Pandu (Pemandu Akademik UNP).** Logo kepala panda di sidebar, login, landing, avatar chat.
  Nama internal (folder, `jangkar.db`, kunci `jangkar_*` di browser) sengaja tidak diganti agar data lama tetap terbaca.
- **Splash screen**: panda + "Pandu", tampil sampai konfigurasi server termuat, lalu memudar.
- **Ikon & PWA**: favicon, apple-touch-icon, ikon 192/512/maskable, `manifest.webmanifest` (bisa "Tambah ke layar utama").
- **Riwayat chat tersimpan di server per akun** (`/api/conversations`), bisa dibuka dari HP/laptop lain.
  Riwayat lama yang tersimpan di browser dipindahkan otomatis sekali saat login.
- **Halaman Riwayat Chat** (`/riwayat`): cari, dikelompokkan per waktu, ganti judul, hapus.
- **Hapus akun dari dalam aplikasi** (Pengaturan → Hapus akun) — syarat wajib Play Store & App Store.
- **Siap dibungkus jadi aplikasi** dengan Capacitor: `capacitor.config.json` (id.ac.unp.pandu), `.env.mobile.example`,
  panduan lengkap di `MOBILE.md`. CORS backend sudah mengizinkan `capacitor://localhost` & `https://localhost`.
- **Tampilan HP**: jarak aman untuk poni/garis bawah layar, tinggi layar mengikuti `100dvh`,
  kotak ketik chat selalu terlihat (hanya daftar pesan yang menggulir), placeholder dipersingkat.
- **Teks privasi diperbarui**: riwayat chat disimpan per akun; log evaluasi tetap anonim; PDF pribadi tidak dicatat dan terhapus otomatis.
