import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // Semua request /api/... diteruskan ke backend FastAPI (jangkar-backend)
    proxy: {
      '/api': 'http://localhost:8000',
    },
  },
})
