# Merilis Pandu sebagai aplikasi Android & iOS

Pandu adalah aplikasi web (React + Vite). Untuk Play Store / App Store, web ini dibungkus dengan
**Capacitor** — tidak perlu menulis ulang aplikasi. Konfigurasinya sudah ada di `capacitor.config.json`.

## 1. Siapkan backend yang bisa diakses dari HP
HP tidak bisa memanggil `localhost` komputer Anda. Backend harus di-deploy ke server dengan HTTPS
(VPS kampus, Railway, Render, dsb.). Lalu:
- salin `.env.mobile.example` menjadi `.env.production`, isi `VITE_API_URL`;
- di `.env` backend, pastikan `CORS_ORIGINS` memuat `http://localhost,https://localhost,capacitor://localhost`
  (sudah menjadi nilai bawaan).

## 2. Pasang Capacitor (sekali saja)
```
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
npm run build
npx cap add android
npx cap add ios          # hanya di Mac
```

## 3. Setiap kali ada perubahan
```
npm run build
npx cap sync
npx cap open android     # buka Android Studio -> Run / Build > Generate Signed Bundle
npx cap open ios         # buka Xcode -> Product > Archive
```

## 4. Ikon & splash
- Ikon: `public/icons/icon-512.png` dan `icon-maskable-512.png` (latar navy, kepala panda di zona aman).
  Untuk ikon native semua ukuran: `npm install -D @capacitor/assets` lalu
  `npx capacitor-assets generate --iconBackgroundColor "#123B66" --splashBackgroundColor "#F5F8FC"`
  dengan `assets/icon.png` = salinan `public/icons/icon-512.png`, `assets/splash.png` = panda + nama.
- Splash di dalam aplikasi sudah ada di `index.html` (tampil selama aplikasi memuat).

## 5. Syarat toko aplikasi yang sudah dipenuhi
- [x] Hapus akun dari dalam aplikasi — Pengaturan > Hapus akun (`DELETE /api/auth/me`).
- [x] Penjelasan data yang disimpan — Pengaturan > Privasi.
- [x] Tampilan HP, area aman notch/poni (`viewport-fit=cover` + `env(safe-area-inset-*)`).
- [ ] **Kebijakan privasi** di URL publik (wajib diisi di Play Console & App Store Connect).
      Isinya bisa diambil dari bagian Privasi di Pengaturan.
- [ ] Akun pengembang: Google Play (bayar sekali), Apple Developer (tahunan).
- [ ] Akun demo untuk peninjau toko (mereka harus bisa login), cantumkan di catatan peninjauan.

## Catatan
- Riwayat chat tersimpan di akun (server), jadi tetap ada setelah aplikasi di-install ulang.
- Tautan "Buka PDF" membuka PDF di browser bawaan HP.
