# Menjalankan Pandu (frontend + backend)

1. Backend
   cd jangkar-backend
   python -m venv .venv
   .venv\Scripts\activate          (Windows)
   pip install -r requirements.txt
   uvicorn app.main:app --reload --port 8000
   Cek: http://localhost:8000/api/health dan http://localhost:8000/docs
   Tes: pytest

2. Frontend (terminal lain)
   cd JANGKAR
   salin folder node_modules lama ke sini, atau jalankan: npm install
   npm run dev   ->  http://localhost:5173

Vite meneruskan /api ke localhost:8000.
Login admin bawaan: admin@jangkar.local / admin123 — ganti di Pengaturan > Keamanan Akun.

Aplikasi HP (Android / iOS)
   Lihat JANGKAR/MOBILE.md. Ringkasnya: backend harus online (HTTPS), isi VITE_API_URL di .env.mobile,
   lalu npm run build → npx cap add android / ios → npx cap sync → buka di Android Studio / Xcode.
