import enum
from datetime import date, datetime, timezone

from sqlalchemy import (Boolean, Date, DateTime, Enum, Float, ForeignKey, Integer,
                        String, Text, JSON)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, EmbeddingType


def now():
    return datetime.now(timezone.utc)


class DocStatus(str, enum.Enum):
    PENDING = "Menunggu Validasi"
    VERIFIED = "Terverifikasi"
    EXPIRED = "Kedaluwarsa"
    REVOKED = "Dicabut"


class DocType(str, enum.Enum):
    REGULATION = "aturan"        # berlaku sampai dicabut
    ANNOUNCEMENT = "pengumuman"  # berbatas waktu, wajib valid_until


class IngestStatus(str, enum.Enum):
    NONE = "belum"
    PROCESSING = "diproses"
    DONE = "selesai"
    FAILED = "gagal"


def _enum(e):
    return Enum(e, values_callable=lambda x: [m.value for m in x], native_enum=False, length=32)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="admin")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Document(Base):
    """Registri dokumen: asal, versi, masa berlaku, status keabsahan."""
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    category: Mapped[str] = mapped_column(String(100), default="Umum")
    doc_number: Mapped[str | None] = mapped_column(String(100))
    version: Mapped[str] = mapped_column(String(50), default="V.1")
    year: Mapped[int | None] = mapped_column(Integer)
    origin: Mapped[str] = mapped_column(String(255), default="Fakultas Teknik")
    source_url: Mapped[str | None] = mapped_column(String(500))
    description: Mapped[str | None] = mapped_column(Text)
    doc_type: Mapped[DocType] = mapped_column(_enum(DocType), default=DocType.REGULATION)
    valid_from: Mapped[date | None] = mapped_column(Date)
    valid_until: Mapped[date | None] = mapped_column(Date)
    status: Mapped[DocStatus] = mapped_column(_enum(DocStatus), default=DocStatus.PENDING, index=True)
    status_note: Mapped[str | None] = mapped_column(Text)
    supersedes_id: Mapped[int | None] = mapped_column(ForeignKey("documents.id"))

    file_path: Mapped[str | None] = mapped_column(String(500))
    file_sha256: Mapped[str | None] = mapped_column(String(64), index=True)
    pages: Mapped[int | None] = mapped_column(Integer)
    skip_pages: Mapped[str | None] = mapped_column(String(100))  # mis. "1-2,90-103" (sampul/lampiran)
    ingest_status: Mapped[IngestStatus] = mapped_column(_enum(IngestStatus), default=IngestStatus.NONE)
    ingest_error: Mapped[str | None] = mapped_column(Text)

    verified_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)

    chunks: Mapped[list["Chunk"]] = relationship(back_populates="document", cascade="all, delete-orphan")

    def is_usable(self, today: date | None = None) -> bool:
        """Hanya dokumen terverifikasi & masih berlaku yang boleh jadi dasar jawaban."""
        today = today or date.today()
        if self.status != DocStatus.VERIFIED:
            return False
        if self.valid_from and self.valid_from > today:
            return False
        if self.valid_until and self.valid_until < today:
            return False
        return True


class Chunk(Base):
    __tablename__ = "chunks"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id", ondelete="CASCADE"), index=True)
    chunk_index: Mapped[int] = mapped_column(Integer)
    page: Mapped[int] = mapped_column(Integer)
    section: Mapped[str | None] = mapped_column(String(255))  # mis. "Pasal 12" / "BAB II"
    text: Mapped[str] = mapped_column(Text)
    embedding: Mapped[list[float] | None] = mapped_column(EmbeddingType)
    document: Mapped[Document] = relationship(back_populates="chunks")


class QueryLog(Base):
    """Catatan jejak — SENGAJA tanpa identitas pengguna (tanpa user_id/IP/user-agent)."""
    __tablename__ = "query_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    question: Mapped[str] = mapped_column(Text)
    answer: Mapped[str] = mapped_column(Text)
    refused: Mapped[bool] = mapped_column(Boolean, default=False)
    refusal_reason: Mapped[str | None] = mapped_column(String(50))
    top_similarity: Mapped[float | None] = mapped_column(Float)
    grounding_score: Mapped[float | None] = mapped_column(Float)
    citations: Mapped[list | None] = mapped_column(JSON)
    latency_ms: Mapped[int] = mapped_column(Integer)
    feedback: Mapped[int | None] = mapped_column(Integer)  # 1 / -1
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)


class EvalQuestion(Base):
    """Set evaluasi berlabel (target 150 pertanyaan)."""
    __tablename__ = "eval_questions"
    id: Mapped[int] = mapped_column(primary_key=True)
    question: Mapped[str] = mapped_column(Text)
    expected_answer: Mapped[str | None] = mapped_column(Text)
    should_refuse: Mapped[bool] = mapped_column(Boolean, default=False)
    expected_document_id: Mapped[int | None] = mapped_column(ForeignKey("documents.id", ondelete="SET NULL"))
    expected_page: Mapped[int | None] = mapped_column(Integer)
    expected_section: Mapped[str | None] = mapped_column(String(255))
    category: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class EvalRun(Base):
    __tablename__ = "eval_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    config: Mapped[dict] = mapped_column(JSON)       # threshold dll (untuk uji ablasi)
    summary: Mapped[dict] = mapped_column(JSON)
    results: Mapped[list] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Faq(Base):
    """FAQ yang dikelola admin dan tampil di halaman FAQ mahasiswa.

    Berbeda dari jawaban RAG: isi FAQ ditulis manusia, untuk pertanyaan tentang
    layanan itu sendiri (cara pakai, privasi, kontak) yang tidak ada di dokumen.
    """
    __tablename__ = "faqs"
    id: Mapped[int] = mapped_column(primary_key=True)
    question: Mapped[str] = mapped_column(String(500))
    answer: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(100), default="Umum")
    is_published: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)


class UserDocument(Base):
    """PDF yang diunggah mahasiswa untuk ditanyakan sendiri.

    Sengaja tabel terpisah dari `documents`: dokumen pribadi tidak pernah masuk
    registri resmi, tidak pernah dicari untuk pertanyaan umum, dan hanya bisa
    diakses pemiliknya. Dihapus otomatis setelah `expires_at`.
    """
    __tablename__ = "user_documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255))
    file_path: Mapped[str] = mapped_column(String(500))
    file_sha256: Mapped[str] = mapped_column(String(64), index=True)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    pages: Mapped[int | None] = mapped_column(Integer)
    ingest_status: Mapped[IngestStatus] = mapped_column(_enum(IngestStatus), default=IngestStatus.NONE)
    ingest_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)

    chunks: Mapped[list["UserChunk"]] = relationship(back_populates="document", cascade="all, delete-orphan")

    @property
    def version(self) -> str:   # dipakai pipeline saat membentuk sitasi
        return "-"


class UserChunk(Base):
    __tablename__ = "user_chunks"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_document_id: Mapped[int] = mapped_column(ForeignKey("user_documents.id", ondelete="CASCADE"), index=True)
    chunk_index: Mapped[int] = mapped_column(Integer)
    page: Mapped[int] = mapped_column(Integer)
    section: Mapped[str | None] = mapped_column(String(255))
    text: Mapped[str] = mapped_column(Text)
    embedding: Mapped[list[float] | None] = mapped_column(EmbeddingType)
    document: Mapped[UserDocument] = relationship(back_populates="chunks")


class Conversation(Base):
    """Riwayat chat milik seorang pengguna, supaya bisa dibuka lagi dari perangkat lain.

    Terpisah dari query_logs: query_logs dipakai untuk evaluasi mutu dan tetap tanpa
    identitas; riwayat ini milik pengguna dan bisa ia hapus kapan saja.
    """
    __tablename__ = "conversations"
    id: Mapped[int] = mapped_column(primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200), default="Percakapan baru")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)

    messages: Mapped[list["ConversationMessage"]] = relationship(
        back_populates="conversation", cascade="all, delete-orphan", order_by="ConversationMessage.id")


class ConversationMessage(Base):
    __tablename__ = "conversation_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    conversation_id: Mapped[int] = mapped_column(ForeignKey("conversations.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(16))          # "user" | "assistant"
    content: Mapped[str] = mapped_column(Text)
    meta: Mapped[dict | None] = mapped_column(JSON)          # sitasi, status tolak, nama PDF pribadi, dll.
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    conversation: Mapped[Conversation] = relationship(back_populates="messages")
