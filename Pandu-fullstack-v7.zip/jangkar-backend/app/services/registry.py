from datetime import date

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.models import DocStatus, Document


def expire_outdated(db: Session, today: date | None = None) -> int:
    """Pengeluaran otomatis: dokumen yang lewat valid_until -> Kedaluwarsa."""
    today = today or date.today()
    res = db.execute(update(Document)
                     .where(Document.status == DocStatus.VERIFIED,
                            Document.valid_until.is_not(None),
                            Document.valid_until < today)
                     .values(status=DocStatus.EXPIRED,
                             status_note=f"Otomatis kedaluwarsa pada {today.isoformat()}"))
    db.commit()
    return res.rowcount or 0


def revoke_superseded(db: Session, doc: Document) -> None:
    """Saat versi baru diverifikasi, versi lama yang digantikannya otomatis dicabut."""
    if doc.supersedes_id:
        old = db.get(Document, doc.supersedes_id)
        if old and old.status == DocStatus.VERIFIED:
            old.status = DocStatus.REVOKED
            old.status_note = f"Digantikan oleh dokumen #{doc.id} ({doc.version})"
