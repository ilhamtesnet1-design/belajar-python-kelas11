"""PDF -> teks per halaman -> potongan (chunk) beranotasi halaman & pasal -> embedding."""
from pypdf import PdfReader
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Chunk, Document, IngestStatus, UserChunk, UserDocument
from app.rag.providers import get_embedder
from app.rag.text import find_sections, normalize_whitespace


def extract_pages(path: str) -> list[str]:
    reader = PdfReader(path)
    return [normalize_whitespace(p.extract_text() or "") for p in reader.pages]


def parse_page_ranges(spec: str | None) -> set[int]:
    """'1-2, 90-103, 7' -> {1,2,7,90..103}"""
    out: set[int] = set()
    for part in (spec or "").replace(" ", "").split(","):
        if not part:
            continue
        a, _, b = part.partition("-")
        lo, hi = int(a), int(b or a)
        if lo < 1 or hi < lo:
            raise ValueError(part)
        out.update(range(lo, hi + 1))
    return out


def chunk_pages(pages: list[str], size: int, overlap: int, skip: set[int] | None = None) -> list[dict]:
    chunks, current_section = [], None
    for page_no, text in enumerate(pages, 1):
        if not text or (skip and page_no in skip):
            continue
        sections = find_sections(text)
        start = 0
        while start < len(text):
            end = min(start + size, len(text))
            if end < len(text):                       # potong di batas kalimat/baris
                cut = max(text.rfind(". ", start, end), text.rfind("\n", start, end))
                if cut > start + size // 2:
                    end = cut + 1
            # pasal yang berlaku = label terakhir yang muncul sebelum (atau di awal) potongan
            before = [lbl for pos, lbl in sections if pos <= start + 40]
            sec = before[-1] if before else current_section
            seen = [lbl for pos, lbl in sections if pos < end]
            if seen:
                current_section = seen[-1]
            body = text[start:end].strip()
            if len(body) > 30:
                chunks.append({"page": page_no, "section": sec, "text": body})
            if end >= len(text):
                break
            start = max(end - overlap, start + 1)
    return chunks


def ingest_document(db: Session, doc: Document, pages: list[str] | None = None) -> Document:
    """pages=None -> ekstrak dari PDF; pages=[...] -> teks hasil OCR per halaman."""
    s = get_settings()
    doc.ingest_status, doc.ingest_error = IngestStatus.PROCESSING, None
    db.commit()
    try:
        pages = [normalize_whitespace(p) for p in pages] if pages is not None else extract_pages(doc.file_path)
        if not any(pages):
            raise ValueError("PDF tidak memiliki lapisan teks (perlu OCR terlebih dahulu).")
        parts = chunk_pages(pages, s.chunk_size, s.chunk_overlap, parse_page_ranges(doc.skip_pages))
        if not parts:
            raise ValueError("Tidak ada teks yang bisa diindeks (cek skip_pages / perlu OCR).")
        vectors = get_embedder().embed([p["text"] for p in parts])
        doc.chunks.clear()
        db.flush()
        for i, (p, v) in enumerate(zip(parts, vectors)):
            doc.chunks.append(Chunk(chunk_index=i, page=p["page"], section=p["section"],
                                    text=p["text"], embedding=v))
        doc.pages = len(pages)
        doc.ingest_status = IngestStatus.DONE
    except Exception as e:  # noqa: BLE001
        db.rollback()
        doc = db.get(Document, doc.id)
        doc.ingest_status, doc.ingest_error = IngestStatus.FAILED, str(e)[:1000]
    db.commit()
    return doc


def ingest_user_document(db: Session, doc: UserDocument) -> UserDocument:
    """Ekstrak + potong + embed PDF milik mahasiswa (cara yang sama dengan dokumen resmi)."""
    s = get_settings()
    doc.ingest_status, doc.ingest_error = IngestStatus.PROCESSING, None
    db.commit()
    try:
        pages = extract_pages(doc.file_path)
        if not any(pages):
            raise ValueError("PDF ini tidak memiliki teks yang bisa dibaca (kemungkinan hasil pindai/foto). "
                             "Unggah versi PDF yang teksnya bisa disalin.")
        parts = chunk_pages(pages, s.chunk_size, s.chunk_overlap)
        if not parts:
            raise ValueError("Tidak ada teks yang cukup panjang untuk diindeks.")
        vectors = get_embedder().embed([p["text"] for p in parts])
        doc.chunks.clear()
        db.flush()
        for i, (p, v) in enumerate(zip(parts, vectors)):
            doc.chunks.append(UserChunk(chunk_index=i, page=p["page"], section=p["section"],
                                        text=p["text"], embedding=v))
        doc.pages = len(pages)
        doc.ingest_status = IngestStatus.DONE
    except Exception as e:  # noqa: BLE001
        db.rollback()
        doc = db.get(UserDocument, doc.id)
        doc.ingest_status, doc.ingest_error = IngestStatus.FAILED, str(e)[:1000]
    db.commit()
    return doc
