import re

STOPWORDS = set("""yang dan di ke dari untuk dengan pada adalah ini itu atau dalam oleh
akan tidak sebagai juga bagi apa apakah bagaimana berapa kapan siapa mana saya aku kami
kita bisa dapat harus ada para se serta tersebut setiap telah sudah jika bila maka
the a an of to is are""".split())


def tokenize(text: str) -> list[str]:
    toks = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return [t for t in toks if t not in STOPWORDS and len(t) > 1]


def normalize_whitespace(text: str) -> str:
    text = text.replace("­", "")
    text = re.sub(r"-\n(\w)", r"\1", text)          # sambung kata terpotong
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


SECTION_RE = re.compile(
    r"^\s*((?:BAB|Bab)\s+[IVXLC\d]+|Pasal\s+\d+[A-Za-z]?|PASAL\s+\d+[A-Za-z]?)\b", re.M)


def find_sections(text: str) -> list[tuple[int, str]]:
    """Kembalikan (posisi karakter, label) untuk setiap BAB/Pasal pada teks."""
    out = []
    for m in SECTION_RE.finditer(text):
        kind, num = re.sub(r"\s+", " ", m.group(1)).split(" ", 1)
        out.append((m.start(), ("BAB " if kind.upper() == "BAB" else "Pasal ") + num.upper()))
    return out
