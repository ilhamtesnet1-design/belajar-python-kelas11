"""Penyedia embedding & LLM. 'fake' = offline deterministik; 'openai' = API kompatibel OpenAI."""
import hashlib
import json
import math

import httpx

from app.config import get_settings
from app.rag.text import tokenize


class FakeEmbedder:
    def __init__(self, dim: int):
        self.dim = dim

    def embed(self, texts: list[str]) -> list[list[float]]:
        out = []
        for t in texts:
            v = [0.0] * self.dim
            toks = tokenize(t)
            grams = toks + [a + "_" + b for a, b in zip(toks, toks[1:])]
            for g in grams:
                h = int(hashlib.md5(g.encode()).hexdigest(), 16)
                v[h % self.dim] += 1.0 if (h >> 8) % 2 else -1.0
            n = math.sqrt(sum(x * x for x in v)) or 1.0
            out.append([x / n for x in v])
        return out


class OpenAICompatEmbedder:
    def __init__(self, s):
        self.s = s

    def embed(self, texts: list[str]) -> list[list[float]]:
        res = []
        for i in range(0, len(texts), 64):
            r = _post_with_retry(self.s, "/embeddings",
                                 {"model": self.s.embedding_model, "input": texts[i:i + 64]}, timeout=60)
            res += [d["embedding"] for d in sorted(r.json()["data"], key=lambda d: d["index"])]
        return res


class FakeLLM:
    """Ekstraktif: ambil kalimat dari konteks dengan tumpang-tindih kata terbanyak.
    HANYA untuk uji alur offline — tidak menyusun jawaban sungguhan."""
    def answer(self, question: str, contexts: list[dict], private: bool = False) -> str:
        q = set(tokenize(question))
        best, score = None, -1
        for i, c in enumerate(contexts, 1):
            for sent in c["text"].replace("\n", " ").split(". "):
                s = len(q & set(tokenize(sent)))
                if s > score:
                    best, score = (sent.strip().rstrip(".") + f". [{i}]"), s
        return best or ""

    def judge_grounding(self, question: str, context: str) -> float:
        q = set(tokenize(question))
        hit = len(q & set(tokenize(context)))
        if not q or (len(q) > 1 and hit < 2):   # minimal 2 kata kunci cocok
            return 0.0
        return hit / len(q)

    def judge_grounding_batch(self, question: str, contexts: list[str]) -> list[float]:
        return [self.judge_grounding(question, c) for c in contexts]


_BULAN = ("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
          "Agustus", "September", "Oktober", "November", "Desember")


def _today_id() -> str:
    from datetime import date
    d = date.today()
    return f"{d.day} {_BULAN[d.month - 1]} {d.year}"


SYSTEM_PROMPT = """Kamu adalah Pandu, asisten layanan akademik Universitas Negeri Padang (UNP).
Tanggal hari ini: {today}.
Aturan WAJIB:
1. Jawab HANYA berdasarkan potongan dokumen di bagian KONTEKS. Jangan memakai pengetahuan luar.
2. Setiap klaim diberi penanda sumber [n] sesuai nomor potongan.
3. Jika konteks tidak memuat jawabannya, balas persis: TIDAK_DITEMUKAN
4. Ikuti bentuk yang diminta penanya: daftar, langkah-langkah, perbandingan, ringkasan, atau jawaban singkat.
   Bila tidak diminta bentuk tertentu, jawab langsung dan ringkas, lalu tambahkan rincian yang relevan.
5. Tanggal, angka, syarat, dan nama menu ditulis persis seperti di dokumen.
6. Bila dokumen mengatur periode tertentu (mis. semester atau periode wisuda), sebutkan periodenya, dan
   kaitkan dengan tanggal hari ini bila penanya bertanya "kapan", "berikutnya", atau "sekarang".
7. Bahasa Indonesia baku yang mudah dipahami mahasiswa."""

PRIVATE_SYSTEM_PROMPT = """Kamu adalah Pandu, asisten yang membantu mahasiswa memahami dokumen PDF yang
DIUNGGAH SENDIRI oleh mahasiswa tersebut. Dokumen ini BUKAN dokumen resmi yang diverifikasi kampus.
Tanggal hari ini: {today}.
Aturan WAJIB:
1. Jawab HANYA berdasarkan potongan dokumen di bagian KONTEKS. Jangan memakai pengetahuan luar.
2. Setiap klaim diberi penanda sumber [n] sesuai nomor potongan.
3. Jika konteks tidak memuat jawabannya, balas persis: TIDAK_DITEMUKAN
4. Lakukan apa yang diminta penanya terhadap isi dokumen: menjawab, meringkas, membuat daftar poin,
   menjelaskan istilah, membandingkan bagian, atau menyusun langkah — tetap hanya dari isi konteks.
5. Tanggal, angka, dan nama ditulis persis seperti di dokumen.
6. Bahasa Indonesia yang mudah dipahami."""


class OpenAICompatLLM:
    def __init__(self, s):
        self.s = s

    def _chat(self, messages, max_tokens=400) -> str:
        r = _post_with_retry(self.s, "/chat/completions",
                             {"model": self.s.llm_model, "messages": messages,
                              "temperature": 0, "max_tokens": max_tokens},
                             timeout=self.s.llm_timeout_seconds)
        return r.json()["choices"][0]["message"]["content"].strip()

    def answer(self, question: str, contexts: list[dict], private: bool = False) -> str:
        ctx = "\n\n".join(f"[{i}] ({c['document_name']}, {c['section'] or '-'}, hlm. {c['page']})\n{c['text']}"
                          for i, c in enumerate(contexts, 1))
        system = (PRIVATE_SYSTEM_PROMPT if private else SYSTEM_PROMPT).format(today=_today_id())
        out = self._chat([{"role": "system", "content": system},
                          {"role": "user", "content": f"KONTEKS:\n{ctx}\n\nPERTANYAAN: {question}"}],
                         max_tokens=700)
        return "" if "TIDAK_DITEMUKAN" in out else out

    def judge_grounding(self, question: str, context: str) -> float:
        return self.judge_grounding_batch(question, [context])[0]

    def judge_grounding_batch(self, question: str, contexts: list[str]) -> list[float]:
        """Nilai semua potongan dalam SATU panggilan (dulu satu panggilan per potongan).
        Penting untuk API gratis yang membatasi jumlah permintaan per menit."""
        blocks = "\n\n".join(f"[{i}]\n{c}" for i, c in enumerate(contexts, 1))
        prompt = ("Untuk setiap KONTEKS bernomor, nilai apakah ia memuat informasi yang cukup untuk menjawab "
                  f"PERTANYAAN. Balas JSON saja: {{\"scores\": [{len(contexts)} angka 0-1 sesuai urutan]}}.\n\n"
                  f"PERTANYAAN: {question}\n\nKONTEKS:\n{blocks}")
        raw = self._chat([{"role": "user", "content": prompt}], max_tokens=20 + 8 * len(contexts))
        try:
            data = json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
            if "scores" in data:
                scores = [float(x) for x in data["scores"]]
            else:                                   # model menjawab satu skor untuk semua
                scores = [float(data["score"])] * len(contexts)
        except (ValueError, KeyError, TypeError):
            return [0.0] * len(contexts)          # tak terbaca -> anggap tidak terjangkar (aman: menolak)
        return (scores + [0.0] * len(contexts))[:len(contexts)]


def _post_with_retry(s, path: str, payload: dict, timeout: float):
    """POST ke API kompatibel OpenAI. Saat kena batas laju (429) — sering terjadi di jalur
    gratis — tunggu sebentar lalu coba sekali lagi sebelum menyerah."""
    import time
    url = s.openai_base_url.rstrip("/") + path
    headers = {"Authorization": f"Bearer {s.openai_api_key}"}
    r = httpx.post(url, headers=headers, json=payload, timeout=timeout)
    if r.status_code == 429:
        try:
            wait = float(r.headers.get("retry-after", "3"))
        except ValueError:
            wait = 3.0
        time.sleep(min(max(wait, 1.0), 8.0))
        r = httpx.post(url, headers=headers, json=payload, timeout=timeout)
    r.raise_for_status()
    return r


def get_embedder():
    s = get_settings()
    return OpenAICompatEmbedder(s) if s.embedding_provider == "openai" else FakeEmbedder(s.embedding_dim)


def get_llm():
    s = get_settings()
    return OpenAICompatLLM(s) if s.llm_provider == "openai" else FakeLLM()
