"""Pipeline RAG: retrieve -> gerbang kemiripan -> gerbang penjangkaran -> generate -> sitasi / tolak."""
import logging
import math
import time
from dataclasses import dataclass, field
from datetime import date

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Chunk, DocStatus, Document, UserChunk, UserDocument
from app.rag.providers import get_embedder, get_llm

log = logging.getLogger("jangkar.rag")


@dataclass
class RagConfig:
    top_k: int
    similarity_threshold: float
    grounding_threshold: float
    use_similarity_gate: bool = True
    use_grounding_gate: bool = True

    @classmethod
    def default(cls, **over):
        s = get_settings()
        base = dict(top_k=s.top_k, similarity_threshold=s.similarity_threshold,
                    grounding_threshold=s.grounding_threshold)
        base.update({k: v for k, v in over.items() if v is not None})
        return cls(**base)


@dataclass
class RagResult:
    answer: str
    refused: bool
    refusal_reason: str | None
    citations: list[dict] = field(default_factory=list)
    top_similarity: float | None = None
    grounding_score: float | None = None
    latency_ms: int = 0
    contexts: list[str] = field(default_factory=list)   # teks potongan yang dipakai (untuk RAGAS)


def _usable_filter(today: date):
    """Penapisan keabsahan di level query: hanya Terverifikasi & dalam masa berlaku."""
    return and_(Document.status == DocStatus.VERIFIED,
                or_(Document.valid_from.is_(None), Document.valid_from <= today),
                or_(Document.valid_until.is_(None), Document.valid_until >= today))


def _cos(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def retrieve(db: Session, question: str, k: int) -> list[tuple[Chunk, float]]:
    qv = get_embedder().embed([question])[0]
    base = select(Chunk).join(Document).where(_usable_filter(date.today()))
    if db.bind.dialect.name == "postgresql":
        from pgvector.sqlalchemy import Vector
        from sqlalchemy import Float, bindparam
        qparam = bindparam("qv", qv, type_=Vector(len(qv)))
        dist = Chunk.embedding.op("<=>", return_type=Float)(qparam)   # jarak kosinus pgvector
        rows = db.execute(base.add_columns(dist.label("d")).order_by(dist).limit(k)).all()
        return [(c, 1 - float(d)) for c, d in rows]
    chunks = db.scalars(base).all()               # fallback SQLite (test)
    scored = sorted(((c, _cos(qv, c.embedding)) for c in chunks if c.embedding), key=lambda x: -x[1])
    return scored[:k]


def _citation(c: Chunk, score: float) -> dict:
    d = c.document
    quote = c.text if len(c.text) <= 400 else c.text[:400].rsplit(" ", 1)[0] + "…"
    return {"document_id": d.id, "document_name": d.name, "version": d.version,
            "status": d.status.value, "section": c.section, "page": c.page,
            "quote": quote, "score": round(score, 4),
            "file_url": f"/api/documents/{d.id}/file#page={c.page}" if d.file_path else None}


def answer_question(db: Session, question: str, cfg: RagConfig | None = None,
                    retriever=None, cite=None, refusal_message: str | None = None,
                    private: bool = False) -> RagResult:
    """retriever/cite/refusal_message kosong = jalur dokumen resmi (perilaku semula).
    Diisi oleh answer_from_user_document() untuk PDF pribadi mahasiswa."""
    s = get_settings()
    cfg = cfg or RagConfig.default()
    t0 = time.perf_counter()
    retriever = retriever or (lambda q, k: retrieve(db, q, k))
    cite = cite or _citation
    message = refusal_message or s.refusal_message

    def done(r: RagResult):
        r.latency_ms = int((time.perf_counter() - t0) * 1000)
        return r

    def refuse(reason, **kw):
        return done(RagResult(answer=message, refused=True, refusal_reason=reason, **kw))

    try:
        return _answer(question, cfg, done, refuse, retriever, cite, private)
    except Exception as e:  # noqa: BLE001 — model/API gagal: lebih baik menolak daripada mengarang
        log.exception("Pipeline RAG gagal: %s", e)
        return refuse("layanan_model_gagal")


def _answer(question, cfg, done, refuse, retriever, cite, private=False) -> RagResult:
    hits = retriever(question, cfg.top_k)
    if not hits:
        return refuse("tidak_ada_dokumen")
    top = hits[0][1]

    # Gerbang 1 — kemiripan: buang potongan yang tidak setopik
    if cfg.use_similarity_gate:
        hits = [(c, sc) for c, sc in hits if sc >= cfg.similarity_threshold]
        if not hits:
            return refuse("gerbang_kemiripan", top_similarity=top)

    llm = get_llm()
    # Gerbang 2 — penjangkaran: potongan benar-benar memuat jawabannya
    g = 1.0
    if cfg.use_grounding_gate:
        judged = llm.judge_grounding_batch(question, [c.text for c, _ in hits])
        scored = [(c, sc, gs) for (c, sc), gs in zip(hits, judged)]
        g = max(x[2] for x in scored)
        hits = [(c, sc) for c, sc, gs in scored if gs >= cfg.grounding_threshold]
        if not hits:
            return refuse("gerbang_penjangkaran", top_similarity=top, grounding_score=g)

    contexts = [{"text": c.text, "page": c.page, "section": c.section,
                 "document_name": c.document.name} for c, _ in hits]
    answer = llm.answer(question, contexts, private=private)
    if not answer.strip():
        return refuse("llm_tidak_menemukan", top_similarity=top, grounding_score=g)

    # Sitasi: hanya potongan yang dirujuk [n] oleh jawaban (fallback: potongan teratas)
    used = [i for i in range(1, len(hits) + 1) if f"[{i}]" in answer] or [1]
    cites = [cite(*hits[i - 1]) for i in used]
    return done(RagResult(answer=answer, refused=False, refusal_reason=None, citations=cites,
                          top_similarity=top, grounding_score=g, contexts=[c["text"] for c in contexts]))



# ---------- PDF pribadi mahasiswa ----------

PRIVATE_REFUSAL = ("Pandu tidak menemukan bagian dokumen Anda yang menjawab pertanyaan ini. "
                   "Coba gunakan kata-kata yang ada di dokumen, atau tanyakan bagian yang lebih spesifik.")


def _retrieve_user_document(db: Session, doc: UserDocument, question: str, k: int):
    """Hanya potongan dari SATU dokumen milik penanya — tidak pernah dokumen orang lain."""
    qv = get_embedder().embed([question])[0]
    chunks = db.scalars(select(UserChunk).where(UserChunk.user_document_id == doc.id)).all()
    scored = sorted(((c, _cos(qv, c.embedding)) for c in chunks if c.embedding), key=lambda x: -x[1])
    return scored[:k]


def _private_citation(c: UserChunk, score: float) -> dict:
    d = c.document
    quote = c.text if len(c.text) <= 400 else c.text[:400].rsplit(" ", 1)[0] + "…"
    return {"document_id": d.id, "document_name": d.name, "version": "-",
            "status": "Dokumen Anda", "section": c.section, "page": c.page,
            "quote": quote, "score": round(score, 4), "private": True,
            "file_url": f"/api/my-documents/{d.id}/file#page={c.page}"}


OVERVIEW_WORDS = ("ringkas", "rangkum", "ringkasan", "rangkuman", "isi utama", "inti", "intinya",
                  "gambaran umum", "tentang apa", "poin penting", "poin utama", "summary", "jelaskan dokumen",
                  "isi dokumen", "garis besar")


def _is_overview(question: str) -> bool:
    q = question.lower()
    return any(w in q for w in OVERVIEW_WORDS)


def _spread_chunks(db: Session, doc: UserDocument, n: int):
    """Untuk permintaan ringkasan: ambil potongan yang tersebar merata dari awal sampai akhir dokumen."""
    chunks = db.scalars(select(UserChunk).where(UserChunk.user_document_id == doc.id)
                        .order_by(UserChunk.chunk_index)).all()
    if len(chunks) <= n:
        return [(c, 1.0) for c in chunks]
    step = len(chunks) / n
    return [(chunks[int(i * step)], 1.0) for i in range(n)]


def answer_from_user_document(db: Session, doc: UserDocument, question: str,
                              cfg: RagConfig | None = None) -> RagResult:
    """Jawab dari SATU PDF milik penanya.

    Pertanyaan biasa melewati gerbang yang sama dengan dokumen resmi. Permintaan
    ringkasan ("ringkas dokumen ini", "apa isi utamanya") tidak cocok dengan potongan
    mana pun secara spesifik, jadi konteksnya diambil merata dari seluruh dokumen dan
    gerbang kemiripan dilewati — model tetap dibatasi hanya pada isi konteks itu.
    """
    if _is_overview(question):
        return answer_question(db, question,
                               RagConfig.default(top_k=8, use_similarity_gate=False, use_grounding_gate=False),
                               retriever=lambda q, k: _spread_chunks(db, doc, k),
                               cite=_private_citation, refusal_message=PRIVATE_REFUSAL, private=True)
    return answer_question(db, question, cfg,
                           retriever=lambda q, k: _retrieve_user_document(db, doc, q, k),
                           cite=_private_citation, refusal_message=PRIVATE_REFUSAL, private=True)
