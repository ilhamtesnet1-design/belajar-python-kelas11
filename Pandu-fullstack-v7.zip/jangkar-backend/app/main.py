from contextlib import asynccontextmanager

from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, text

from app.api import auth, chat, conversations, dashboard, documents, evaluation, faq, my_documents
from app.config import get_settings
from app.db import Base, SessionLocal, engine
from app.models import Faq, User
from app.security import hash_password
from app.services.registry import expire_outdated


def run_migrations():
    """PostgreSQL: skema dikelola Alembic (migrations/). SQLite (dev/test): create_all."""
    import os
    from alembic import command
    from alembic.config import Config
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cfg = Config(os.path.join(root, "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(root, "migrations"))
    cfg.attributes["configure_logger"] = False
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        command.upgrade(cfg, "head")


def _sqlite_add_missing_columns():
    """create_all() membuat tabel baru tetapi tidak menambah kolom ke tabel lama.

    Database SQLite dev yang dibuat sebelum sebuah kolom ditambahkan ke model
    (mis. documents.skip_pages) akan gagal di setiap query ("no such column").
    Kolom nullable yang hilang ditambahkan di sini; skema PostgreSQL tetap
    dikelola Alembic.
    """
    from sqlalchemy import inspect
    insp = inspect(engine)
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if not insp.has_table(table.name):
                continue
            have = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in have or not col.nullable:
                    continue
                ddl = col.type.compile(dialect=engine.dialect)
                conn.execute(text(f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {ddl}'))


def init_db():
    if get_settings().is_postgres:
        run_migrations()
    else:
        Base.metadata.create_all(engine)
        _sqlite_add_missing_columns()
    s = get_settings()
    with SessionLocal() as db:
        if not db.scalar(select(User).where(User.email == s.admin_email.lower())):
            db.add(User(email=s.admin_email.lower(), name="Admin Akademik",
                        password_hash=hash_password(s.admin_password), role="admin"))
            db.commit()
        if not db.scalar(select(Faq.id).limit(1)):
            db.add_all([Faq(question=q, answer=a, category=c, sort_order=i)
                        for i, (q, a, c) in enumerate(DEFAULT_FAQS)])
            db.commit()
        expire_outdated(db)


DEFAULT_FAQS = [
    ("Apa itu Pandu?",
     "Pandu adalah asisten yang membantu mahasiswa menemukan ketentuan akademik langsung dari "
     "dokumen resmi universitas, lengkap dengan dokumen, pasal, dan halaman sumbernya.", "Umum"),
    ("Apakah jawaban Pandu pasti benar?",
     "Pandu hanya menjawab dari dokumen resmi yang sudah diverifikasi admin, dan menolak menjawab "
     "bila tidak ada sumber yang mendukung. Meski begitu, selalu periksa kutipan dan dokumen aslinya "
     "lewat tombol Lihat Sumber, dan tanyakan ke unit akademik untuk keputusan resmi.", "Umum"),
    ("Apakah saya perlu akun?",
     "Ya. Pandu khusus untuk mahasiswa UNP, jadi Anda perlu mendaftar dan masuk dengan email "
     "sebelum bertanya. Pertanyaan Anda tetap dicatat tanpa dikaitkan ke akun.", "Privasi"),
    ("Apakah pertanyaan saya disimpan?",
     "Ada dua catatan terpisah. Riwayat chat disimpan di akun Anda supaya bisa dibuka lagi dari HP atau "
     "laptop lain — hanya Anda yang bisa melihatnya, dan bisa dihapus kapan saja di Pengaturan. Selain itu, "
     "pertanyaan tentang dokumen resmi dicatat untuk evaluasi mutu sistem tanpa nama, email, maupun alamat IP.", "Privasi"),
    ("Bagaimana melihat sumber sebuah jawaban?",
     "Di bawah setiap jawaban ada kartu sumber berisi nama dokumen, bagian, halaman, dan kutipan. "
     "Tombol Lihat Sumber membuka PDF di halaman yang dikutip.", "Penggunaan"),
]


def _expire_job():
    with SessionLocal() as db:
        expire_outdated(db)


def _purge_user_documents_job():
    with SessionLocal() as db:
        my_documents.purge_expired_user_documents(db)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    sched = BackgroundScheduler(timezone="Asia/Jakarta")
    sched.add_job(_expire_job, "cron", hour=0, minute=5)
    sched.add_job(_purge_user_documents_job, "interval", hours=1)
    sched.start()
    yield
    sched.shutdown()


app = FastAPI(title="Pandu API", version="0.1.0",
              description="Asisten Layanan Akademik Berbasis Dokumen Resmi Kampus — backend",
              lifespan=lifespan)
app.add_middleware(CORSMiddleware,
                   allow_origins=[o.strip() for o in get_settings().cors_origins.split(",")],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
for r in (auth, documents, chat, conversations, dashboard, evaluation, faq, my_documents):
    app.include_router(r.router)


@app.get("/api/config/public", tags=["sistem"])
def public_config():
    """Pengaturan yang perlu diketahui frontend, tanpa login.

    Frontend membaca batas unggah dari sini, jadi teks "maks. 100 MB" di layar
    dan batas yang ditegakkan server selalu satu angka yang sama.
    """
    s = get_settings()
    mb = 1024 * 1024
    return {
        "uploads": {
            "document": {"max_bytes": s.max_upload_mb * mb},
            "archive": {"max_bytes": s.max_zip_mb * mb, "max_entries": s.max_zip_entries},
            "scan": {"max_bytes": s.max_scan_mb * mb},
            "avatar": {"max_bytes": s.max_avatar_mb * mb},
        },
        "chat": {"max_question_chars": 1000},
        "my_documents": {"max_active": s.max_user_documents, "ttl_hours": s.user_document_ttl_hours},
        "auth": {
            "student_login_required": s.require_student_login,
            "allowed_email_domains": s.email_domains,
        },
    }


@app.get("/api/health", tags=["sistem"])
def health():
    with SessionLocal() as db:
        db.execute(text("SELECT 1"))
    return {"status": "ok"}
