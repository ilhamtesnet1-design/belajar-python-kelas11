"""Pembatas laju sederhana (in-memory, per proses).
IP hanya dipakai sementara di memori untuk menghitung jumlah request — TIDAK disimpan ke database/log,
sehingga tetap sesuai syarat charter "catatan jejak tidak memuat identitas pengguna".
Catatan: bila nanti memakai >1 worker/server, ganti dengan Redis."""
import threading
import time
from collections import defaultdict, deque
from datetime import date

from fastapi import HTTPException, Request

from app.config import get_settings

_lock = threading.Lock()
_hits: dict[str, deque] = defaultdict(deque)
_daily = {"day": None, "count": 0}


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _check(key: str, limit: int, window: int):
    if limit <= 0:
        return
    now = time.monotonic()
    with _lock:
        q = _hits[key]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            retry = int(window - (now - q[0])) + 1
            raise HTTPException(429, f"Terlalu banyak permintaan. Coba lagi dalam {retry} detik.",
                                headers={"Retry-After": str(retry)})
        q.append(now)


def chat_limit(request: Request):
    s = get_settings()
    _check(f"chat:{_client_ip(request)}", s.chat_rate_per_minute, 60)
    if s.daily_question_limit > 0:               # rem anggaran API model
        with _lock:
            today = date.today()
            if _daily["day"] != today:
                _daily.update(day=today, count=0)
            if _daily["count"] >= s.daily_question_limit:
                raise HTTPException(429, "Kuota pertanyaan harian sistem sudah habis. Coba lagi besok.")
            _daily["count"] += 1


def login_limit(request: Request):
    s = get_settings()
    _check(f"login:{_client_ip(request)}", s.login_rate_per_15min, 900)


def password_limit(request: Request):
    """Ganti kata sandi memakai kuota yang sama dengan login, tapi kunci terpisah,
    supaya menebak kata sandi lama lewat endpoint ini sama lambatnya."""
    s = get_settings()
    _check(f"password:{_client_ip(request)}", s.login_rate_per_15min, 900)


def reset():
    with _lock:
        _hits.clear()
        _daily.update(day=None, count=0)
