from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.models import User

bearer = HTTPBearer(auto_error=False)


def hash_password(p: str) -> str:
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()


def verify_password(p: str, h: str) -> bool:
    return bcrypt.checkpw(p.encode(), h.encode())


def create_token(user: User) -> str:
    s = get_settings()
    payload = {"sub": str(user.id), "role": user.role,
               "exp": datetime.now(timezone.utc) + timedelta(minutes=s.jwt_expire_minutes)}
    return jwt.encode(payload, s.jwt_secret, algorithm="HS256")


def _user_from_token(cred: HTTPAuthorizationCredentials | None, db: Session) -> User:
    if not cred:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Silakan masuk terlebih dahulu")
    try:
        data = jwt.decode(cred.credentials, get_settings().jwt_secret, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Sesi tidak valid / kedaluwarsa, silakan masuk lagi")
    user = db.get(User, int(data["sub"]))
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Akun tidak aktif")
    return user


def require_user(cred: HTTPAuthorizationCredentials | None = Depends(bearer),
                 db: Session = Depends(get_db)) -> User:
    """Pengguna mana pun yang sudah masuk (mahasiswa atau admin)."""
    return _user_from_token(cred, db)


def require_admin(cred: HTTPAuthorizationCredentials | None = Depends(bearer),
                  db: Session = Depends(get_db)) -> User:
    user = _user_from_token(cred, db)
    if user.role != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Akses ditolak")
    return user


def require_chat_access(cred: HTTPAuthorizationCredentials | None = Depends(bearer),
                        db: Session = Depends(get_db)) -> None:
    """Bertanya butuh login bila REQUIRE_STUDENT_LOGIN aktif.

    Dependensi ini hanya MEMERIKSA login; identitas pengguna sengaja tidak
    diteruskan ke handler, sehingga catatan pertanyaan tidak bisa dikaitkan
    ke akun siapa pun.
    """
    if get_settings().require_student_login:
        _user_from_token(cred, db)
