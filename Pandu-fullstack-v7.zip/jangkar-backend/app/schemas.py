from datetime import date, datetime
from pydantic import BaseModel, ConfigDict, Field

from app.models import DocStatus, DocType, IngestStatus


class LoginIn(BaseModel):
    email: str
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


class DocumentBase(BaseModel):
    name: str
    category: str = "Umum"
    doc_number: str | None = None
    version: str = "V.1"
    year: int | None = None
    origin: str = "Fakultas Teknik"
    source_url: str | None = None
    description: str | None = None
    doc_type: DocType = DocType.REGULATION
    valid_from: date | None = None
    valid_until: date | None = None
    supersedes_id: int | None = None
    skip_pages: str | None = None


class DocumentUpdate(BaseModel):
    name: str | None = None
    category: str | None = None
    doc_number: str | None = None
    version: str | None = None
    year: int | None = None
    origin: str | None = None
    source_url: str | None = None
    description: str | None = None
    doc_type: DocType | None = None
    valid_from: date | None = None
    valid_until: date | None = None
    supersedes_id: int | None = None
    skip_pages: str | None = None


class DocumentOut(DocumentBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: DocStatus
    status_note: str | None
    pages: int | None
    ingest_status: IngestStatus
    ingest_error: str | None
    file_url: str | None = None
    chunk_count: int = 0
    usable: bool = False
    verified_at: datetime | None
    created_at: datetime
    updated_at: datetime


class StatusChange(BaseModel):
    note: str | None = None


class AskIn(BaseModel):
    question: str = Field(min_length=3, max_length=1000)


class Citation(BaseModel):
    document_id: int
    document_name: str
    version: str
    status: str
    section: str | None
    page: int
    quote: str
    score: float
    file_url: str | None
    private: bool = False          # True = dari PDF yang diunggah mahasiswa, bukan dokumen resmi


class AskOut(BaseModel):
    log_id: int | None = None      # None untuk tanya-jawab dokumen pribadi (tidak dicatat)
    answer: str
    refused: bool
    refusal_reason: str | None = None
    citations: list[Citation] = []
    latency_ms: int


class FeedbackIn(BaseModel):
    value: int = Field(ge=-1, le=1)


class EvalQuestionIn(BaseModel):
    question: str
    expected_answer: str | None = None
    should_refuse: bool = False
    expected_document_id: int | None = None
    expected_page: int | None = None
    expected_section: str | None = None
    category: str | None = None


class EvalQuestionOut(EvalQuestionIn):
    model_config = ConfigDict(from_attributes=True)
    id: int


class EvalRunIn(BaseModel):
    similarity_threshold: float | None = None
    grounding_threshold: float | None = None
    top_k: int | None = None
    use_grounding_gate: bool = True
    use_similarity_gate: bool = True
