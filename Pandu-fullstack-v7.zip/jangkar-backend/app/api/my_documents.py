"""PDF pribadi mahasiswa: unggah, tanyakan isinya, hapus.

Batasan yang sengaja dijaga:
- Hanya pemilik yang bisa melihat, menanyakan, atau mengunduh dokumennya.
- Dokumen pribadi tidak pernah masuk registri resmi dan tidak pernah dicari
  untuk pertanyaan umum di /api/chat/ask.
- Tanya-jawab tentang dokumen pribadi TIDAK dicatat ke query_logs, karena isinya
  bisa memuat data pribadi.
- Dokumen dihapus otomatis setelah USER_DOCUMENT_TTL_HOURS.
"""
import os
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.documents import _limit, _storage_path, _stream_to_disk, _title_from_filename
from app.config import get_settings
from app.db import SessionLocal, get_db
from app.models import IngestStatus, User, UserDocument
from app.rag.ingest import ingest_user_document
from app.rag.pipeline import answer_from_user_document
from app.ratelimit import chat_limit
from app.schemas import AskIn, AskOut
from app.security import bearer, require_user

router = APIRouter(prefix="/api/my-documents", tags=["dokumen pribadi mahasiswa"])


class UserDocumentOut(BaseModel):
    id: int
    name: str
    size_bytes: int
    pages: int | None
    chunk_count: int
    ingest_status: str
    ingest_error: str | None
    created_at: datetime
    expires_at: datetime


def _utc(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _out(d: UserDocument) -> UserDocumentOut:
    return UserDocumentOut(id=d.id, name=d.name, size_bytes=d.size_bytes, pages=d.pages,
                           chunk_count=len(d.chunks), ingest_status=d.ingest_status.value,
                           ingest_error=d.ingest_error, created_at=d.created_at, expires_at=d.expires_at)


def _remove(db: Session, d: UserDocument):
    if d.file_path and os.path.exists(d.file_path):
        os.remove(d.file_path)
    db.delete(d)


def purge_expired_user_documents(db: Session) -> int:
    """Hapus dokumen pribadi yang sudah lewat masa simpan (dipanggil penjadwal & saat daftar)."""
    now = datetime.now(timezone.utc)
    n = 0
    for d in db.scalars(select(UserDocument)).all():
        if _utc(d.expires_at) <= now:
            _remove(db, d)
            n += 1
    if n:
        db.commit()
    return n


def _own(db: Session, doc_id: int, user: User) -> UserDocument:
    d = db.get(UserDocument, doc_id)
    # Dokumen milik orang lain diperlakukan sama dengan tidak ada (404, bukan 403),
    # supaya keberadaannya pun tidak bocor.
    if not d or d.owner_id != user.id or _utc(d.expires_at) <= datetime.now(timezone.utc):
        raise HTTPException(404, "Dokumen tidak ditemukan")
    return d


def _run_ingest(doc_id: int):
    db = SessionLocal()
    try:
        ingest_user_document(db, db.get(UserDocument, doc_id))
    finally:
        db.close()


@router.get("", response_model=list[UserDocumentOut])
def list_mine(db: Session = Depends(get_db), user: User = Depends(require_user)):
    purge_expired_user_documents(db)
    rows = db.scalars(select(UserDocument).where(UserDocument.owner_id == user.id)
                      .order_by(UserDocument.created_at.desc())).all()
    return [_out(d) for d in rows]


@router.post("", response_model=UserDocumentOut, status_code=201)
async def upload(bg: BackgroundTasks, file: UploadFile = File(...),
                 db: Session = Depends(get_db), user: User = Depends(require_user)):
    s = get_settings()
    purge_expired_user_documents(db)
    active = db.scalars(select(UserDocument).where(UserDocument.owner_id == user.id)).all()
    if len(active) >= s.max_user_documents:
        raise HTTPException(409, f"Maksimal {s.max_user_documents} dokumen aktif. Hapus salah satu dokumen lama dulu.")

    path = _storage_path()
    sha = await _stream_to_disk(file, _limit("max_upload_mb"), path, magic=b"%PDF")
    same = next((d for d in active if d.file_sha256 == sha), None)
    if same:                                   # berkas yang sama diunggah lagi: pakai yang sudah ada
        os.remove(path)
        return _out(same)

    d = UserDocument(owner_id=user.id, name=_title_from_filename(file.filename or "Dokumen"),
                     file_path=path, file_sha256=sha, size_bytes=os.path.getsize(path),
                     ingest_status=IngestStatus.NONE,
                     expires_at=datetime.now(timezone.utc) + timedelta(hours=s.user_document_ttl_hours))
    db.add(d)
    db.commit()
    bg.add_task(_run_ingest, d.id)
    return _out(d)


@router.get("/{doc_id}", response_model=UserDocumentOut)
def get_mine(doc_id: int, db: Session = Depends(get_db), user: User = Depends(require_user)):
    return _out(_own(db, doc_id, user))


@router.get("/{doc_id}/file")
def get_file(doc_id: int, token: str | None = None,
             cred: HTTPAuthorizationCredentials | None = Depends(bearer),
             db: Session = Depends(get_db)):
    """PDF milik sendiri. Token boleh lewat query karena tab/iframe PDF tak bisa mengirim header."""
    if token:
        cred = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
    user = require_user(cred, db)
    d = _own(db, doc_id, user)
    return FileResponse(d.file_path, media_type="application/pdf", filename=f"{d.name}.pdf",
                        content_disposition_type="inline")


@router.delete("/{doc_id}", status_code=204)
def delete_mine(doc_id: int, db: Session = Depends(get_db), user: User = Depends(require_user)):
    _remove(db, _own(db, doc_id, user))
    db.commit()


@router.post("/{doc_id}/ask", response_model=AskOut, dependencies=[Depends(chat_limit)])
def ask_mine(doc_id: int, body: AskIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    """Jawab hanya dari dokumen ini. Tidak dicatat ke query_logs."""
    d = _own(db, doc_id, user)
    if d.ingest_status != IngestStatus.DONE:
        msg = ("Dokumen masih diproses, coba lagi sebentar." if d.ingest_status in (IngestStatus.NONE, IngestStatus.PROCESSING)
               else f"Dokumen tidak bisa dibaca: {d.ingest_error}")
        raise HTTPException(409, msg)
    r = answer_from_user_document(db, d, body.question.strip())
    return AskOut(log_id=None, answer=r.answer, refused=r.refused, refusal_reason=r.refusal_reason,
                  citations=r.citations, latency_ms=r.latency_ms)
