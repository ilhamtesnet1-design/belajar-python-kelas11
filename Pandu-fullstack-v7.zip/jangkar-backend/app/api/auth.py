import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Conversation, User, UserDocument
from app.ratelimit import login_limit, password_limit
from app.schemas import LoginIn, TokenOut
from app.config import get_settings
from app.security import create_token, hash_password, require_user, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=TokenOut, dependencies=[Depends(login_limit)])
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Email atau kata sandi salah")
    if not user.is_active:
        raise HTTPException(403, "Akun dinonaktifkan. Hubungi admin akademik.")
    return TokenOut(access_token=create_token(user),
                    user={"id": user.id, "email": user.email, "name": user.name, "role": user.role})


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    email: str = Field(max_length=255)
    password: str = Field(min_length=8, max_length=128)


@router.post("/register", response_model=TokenOut, status_code=201, dependencies=[Depends(login_limit)])
def register(body: RegisterIn, db: Session = Depends(get_db)):
    """Pendaftaran akun mahasiswa (role "mahasiswa").

    Untuk sementara email apa pun diterima. Setelah SSO/izin kampus tersedia,
    isi ALLOWED_EMAIL_DOMAINS (mis. "student.unp.ac.id") untuk membatasi ke
    email UNP. Akun hanya dipakai untuk masuk — pertanyaan tetap dicatat
    tanpa dikaitkan ke akun.
    """
    email = body.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Format email tidak valid")
    domains = get_settings().email_domains
    if domains and not any(email.endswith("@" + d) or email.endswith("." + d) for d in domains):
        raise HTTPException(403, "Pendaftaran hanya untuk email " + " / ".join("@" + d for d in domains))
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email sudah terdaftar. Silakan masuk.")
    user = User(email=email, name=body.name.strip(), password_hash=hash_password(body.password), role="mahasiswa")
    db.add(user)
    db.commit()
    return TokenOut(access_token=create_token(user),
                    user={"id": user.id, "email": user.email, "name": user.name, "role": user.role})


@router.get("/me")
def me(user: User = Depends(require_user)):
    return {"id": user.id, "email": user.email, "name": user.name, "role": user.role}


class ProfileIn(BaseModel):
    name: str = Field(min_length=2, max_length=255)


class PasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


def _public(user: User) -> dict:
    return {"id": user.id, "email": user.email, "name": user.name, "role": user.role}


@router.patch("/me")
def update_me(body: ProfileIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    """Ubah nama tampilan (admin & mahasiswa). Email adalah identitas login dan tidak diubah di sini."""
    user.name = body.name.strip()
    db.commit()
    return _public(user)


@router.post("/password", status_code=204, dependencies=[Depends(password_limit)])
def change_password(body: PasswordIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    """Ganti kata sandi. Kata sandi lama wajib benar; dibatasi laju seperti login."""
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(400, "Kata sandi saat ini salah")
    if body.new_password == body.current_password:
        raise HTTPException(422, "Kata sandi baru harus berbeda dari yang lama")
    user.password_hash = hash_password(body.new_password)
    db.commit()



class DeleteAccountIn(BaseModel):
    password: str


@router.delete("/me", status_code=204, dependencies=[Depends(password_limit)])
def delete_me(body: DeleteAccountIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    """Hapus akun sendiri beserta riwayat chat & PDF pribadinya.

    Diwajibkan Google Play & App Store untuk aplikasi yang punya akun. Kata sandi
    diminta ulang supaya ponsel yang tertinggal terbuka tidak bisa menghapus akun.
    Data dihapus eksplisit (bukan mengandalkan ON DELETE CASCADE, yang di SQLite
    tidak aktif secara bawaan). Catatan evaluasi tidak tersentuh karena memang
    tidak pernah memuat identitas.
    """
    import os
    if user.role == "admin":
        raise HTTPException(403, "Akun admin tidak bisa dihapus dari sini.")
    if not verify_password(body.password, user.password_hash):
        raise HTTPException(400, "Kata sandi salah")
    for c in db.scalars(select(Conversation).where(Conversation.owner_id == user.id)).all():
        db.delete(c)
    for d in db.scalars(select(UserDocument).where(UserDocument.owner_id == user.id)).all():
        if d.file_path and os.path.exists(d.file_path):
            os.remove(d.file_path)
        db.delete(d)
    db.delete(user)
    db.commit()
