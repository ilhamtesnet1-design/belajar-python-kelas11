import hashlib
import os
import uuid
import zipfile
from datetime import date, datetime, timezone

from fastapi import (APIRouter, BackgroundTasks, Depends, File, Form, HTTPException,
                     UploadFile)
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import SessionLocal, get_db
from app.models import Chunk, DocStatus, DocType, Document, User
from app.rag.ingest import ingest_document
from app.schemas import DocumentOut, DocumentUpdate, StatusChange
from app.security import require_admin
from app.services.registry import expire_outdated, revoke_superseded

router = APIRouter(prefix="/api/documents", tags=["registri dokumen"])
MB = 1024 * 1024
READ_CHUNK = 1 * MB


def _limit(name: str) -> int:
    """Batas dalam byte, dibaca dari Settings supaya .env bisa mengubahnya."""
    return getattr(get_settings(), name) * MB


def _storage_path(suffix: str = ".pdf") -> str:
    storage = get_settings().storage_dir
    os.makedirs(storage, exist_ok=True)
    return os.path.join(storage, f"{uuid.uuid4().hex}{suffix}")


async def _stream_to_disk(file: UploadFile, limit: int, path: str, magic: bytes | None) -> str:
    """Tulis unggahan ke disk per potongan 1MB sambil menghitung SHA-256.

    Berkas 100MB tidak pernah dimuat utuh ke memori, dan unggahan yang melewati
    batas dihentikan begitu batasnya terlampaui, bukan setelah selesai diterima.
    """
    digest, size, first = hashlib.sha256(), 0, True
    try:
        with open(path, "wb") as out:
            while chunk := await file.read(READ_CHUNK):
                if first:
                    if magic and not chunk.startswith(magic):
                        raise HTTPException(415, "Berkas harus PDF" if magic == b"%PDF"
                                            else "Format berkas tidak dikenali")
                    first = False
                size += len(chunk)
                if size > limit:
                    raise HTTPException(413, f"Ukuran berkas melebihi batas {limit // MB} MB")
                digest.update(chunk)
                out.write(chunk)
        if size == 0:
            raise HTTPException(422, "Berkas kosong")
    except BaseException:
        if os.path.exists(path):
            os.remove(path)
        raise
    return digest.hexdigest()


def to_out(db: Session, d: Document) -> DocumentOut:
    out = DocumentOut.model_validate(d)
    out.chunk_count = db.scalar(select(func.count(Chunk.id)).where(Chunk.document_id == d.id)) or 0
    out.file_url = f"/api/documents/{d.id}/file" if d.file_path else None
    out.usable = d.is_usable()
    return out


def _get(db, doc_id) -> Document:
    d = db.get(Document, doc_id)
    if not d:
        raise HTTPException(404, "Dokumen tidak ditemukan")
    return d


def _validate_dates(doc_type, valid_from, valid_until):
    if doc_type == DocType.ANNOUNCEMENT and not valid_until:
        raise HTTPException(422, "Pengumuman wajib memiliki tanggal berakhir (valid_until)")
    if valid_from and valid_until and valid_until < valid_from:
        raise HTTPException(422, "valid_until harus setelah valid_from")


def _validate_skip(spec):
    from app.rag.ingest import parse_page_ranges
    try:
        parse_page_ranges(spec)
    except ValueError:
        raise HTTPException(422, 'skip_pages tidak valid. Contoh: "1-2,90-103"')


def _run_ingest(doc_id: int):
    db = SessionLocal()
    try:
        ingest_document(db, db.get(Document, doc_id))
    finally:
        db.close()


# ---------- Publik (mahasiswa): hanya dokumen yang boleh dipakai ----------
@router.get("/public", response_model=list[DocumentOut])
def list_public(db: Session = Depends(get_db)):
    docs = db.scalars(select(Document).where(Document.status == DocStatus.VERIFIED)
                      .order_by(Document.name)).all()
    return [to_out(db, d) for d in docs if d.is_usable()]


@router.get("/{doc_id}/file")
def get_file(doc_id: int, db: Session = Depends(get_db)):
    d = _get(db, doc_id)
    if not d.file_path or not d.is_usable():
        raise HTTPException(404, "Berkas tidak tersedia")
    return FileResponse(d.file_path, media_type="application/pdf", filename=f"{d.name}.pdf",
                        content_disposition_type="inline")


@router.get("/{doc_id}/admin-file")
def get_admin_file(doc_id: int, token: str, db: Session = Depends(get_db)):
    """Pratinjau PDF untuk admin (semua status). Token lewat query karena <iframe> tak bisa kirim header."""
    from fastapi.security import HTTPAuthorizationCredentials
    require_admin(HTTPAuthorizationCredentials(scheme="Bearer", credentials=token), db)
    d = _get(db, doc_id)
    if not d.file_path:
        raise HTTPException(404, "Berkas tidak tersedia")
    return FileResponse(d.file_path, media_type="application/pdf", content_disposition_type="inline")


# ---------- Admin: registri ----------
@router.get("", response_model=list[DocumentOut])
def list_docs(status: DocStatus | None = None, category: str | None = None, q: str | None = None,
              db: Session = Depends(get_db), _: User = Depends(require_admin)):
    stmt = select(Document).order_by(Document.updated_at.desc())
    if status:
        stmt = stmt.where(Document.status == status)
    if category:
        stmt = stmt.where(Document.category == category)
    if q:
        stmt = stmt.where(Document.name.ilike(f"%{q}%"))
    return [to_out(db, d) for d in db.scalars(stmt).all()]


@router.post("", response_model=DocumentOut, status_code=201)
async def create_doc(bg: BackgroundTasks,
                     file: UploadFile = File(...),
                     name: str = Form(...), category: str = Form("Umum"),
                     doc_number: str | None = Form(None), version: str = Form("V.1"),
                     year: int | None = Form(None), origin: str = Form("Fakultas Teknik"),
                     source_url: str | None = Form(None), description: str | None = Form(None),
                     doc_type: DocType = Form(DocType.REGULATION),
                     valid_from: date | None = Form(None), valid_until: date | None = Form(None),
                     supersedes_id: int | None = Form(None),
                     skip_pages: str | None = Form(None),
                     db: Session = Depends(get_db), _: User = Depends(require_admin)):
    _validate_dates(doc_type, valid_from, valid_until)
    _validate_skip(skip_pages)
    path = _storage_path()
    sha = await _stream_to_disk(file, _limit("max_upload_mb"), path, magic=b"%PDF")
    dup = db.scalar(select(Document).where(Document.file_sha256 == sha))
    if dup:
        os.remove(path)
        raise HTTPException(409, f"Berkas yang sama sudah terdaftar sebagai dokumen #{dup.id}")
    d = Document(name=name, category=category, doc_number=doc_number, version=version, year=year,
                 origin=origin, source_url=source_url, description=description, doc_type=doc_type,
                 valid_from=valid_from, valid_until=valid_until, supersedes_id=supersedes_id, skip_pages=skip_pages,
                 file_path=path, file_sha256=sha, status=DocStatus.PENDING)
    db.add(d)
    db.commit()
    bg.add_task(_run_ingest, d.id)
    return to_out(db, d)


def _title_from_filename(filename: str) -> str:
    """"Pedoman_Akademik-2024.pdf" -> "Pedoman Akademik 2024"."""
    stem = os.path.splitext(os.path.basename(filename))[0]
    return " ".join(stem.replace("_", " ").replace("-", " ").split()) or "Dokumen tanpa nama"


def _extract_pdf(zf: zipfile.ZipFile, info: zipfile.ZipInfo, limit: int, path: str) -> str:
    """Ekstrak satu PDF dari ZIP. Ukuran dihitung dari byte yang benar-benar
    keluar, bukan dari header ZIP — header bisa dipalsukan (zip bomb)."""
    if info.flag_bits & 0x1:
        raise ValueError("Berkas di dalam ZIP terkunci kata sandi")
    digest, size, first = hashlib.sha256(), 0, True
    try:
        with zf.open(info) as src, open(path, "wb") as out:
            while chunk := src.read(READ_CHUNK):
                if first:
                    if not chunk.startswith(b"%PDF"):
                        raise ValueError("Isi berkas bukan PDF")
                    first = False
                size += len(chunk)
                if size > limit:
                    raise ValueError(f"Melebihi batas {limit // MB} MB per dokumen")
                digest.update(chunk)
                out.write(chunk)
        if size == 0:
            raise ValueError("Berkas kosong")
    except BaseException:
        if os.path.exists(path):
            os.remove(path)
        raise
    return digest.hexdigest()


def _is_junk(name: str) -> bool:
    base = os.path.basename(name)
    return "__MACOSX/" in name or base.startswith(".") or base.lower() in ("thumbs.db", "desktop.ini")


@router.post("/batch", status_code=201)
async def create_batch(bg: BackgroundTasks,
                       file: UploadFile = File(...),
                       category: str = Form("Umum"), version: str = Form("V.1"),
                       year: int | None = Form(None), origin: str = Form("Fakultas Teknik"),
                       doc_type: DocType = Form(DocType.REGULATION),
                       valid_from: date | None = Form(None), valid_until: date | None = Form(None),
                       db: Session = Depends(get_db), _: User = Depends(require_admin)):
    """Unggah banyak dokumen sekaligus dalam satu ZIP.

    Metadata (kategori, versi, masa berlaku) berlaku untuk semua dokumen di
    dalam ZIP; nama dokumen diambil dari nama berkas. Setiap dokumen masuk
    sebagai "Menunggu Validasi" dan tetap harus divalidasi satu per satu.
    Berkas yang gagal tidak membatalkan yang lain — alasannya dilaporkan di
    `skipped`.
    """
    _validate_dates(doc_type, valid_from, valid_until)
    settings = get_settings()
    zip_path = _storage_path(".zip")
    await _stream_to_disk(file, _limit("max_zip_mb"), zip_path, magic=b"PK")

    created: list[Document] = []
    skipped: list[dict] = []
    try:
        try:
            zf = zipfile.ZipFile(zip_path)
        except zipfile.BadZipFile:
            raise HTTPException(415, "Arsip ZIP rusak atau bukan berkas ZIP")
        with zf:
            entries = [i for i in zf.infolist() if not i.is_dir() and not _is_junk(i.filename)]
            pdfs = [i for i in entries if i.filename.lower().endswith(".pdf")]
            for i in entries:
                if i not in pdfs:
                    skipped.append({"file": os.path.basename(i.filename), "reason": "Bukan berkas PDF"})
            if not pdfs:
                raise HTTPException(422, "Tidak ada berkas PDF di dalam ZIP")
            if len(pdfs) > settings.max_zip_entries:
                raise HTTPException(422, f"ZIP berisi {len(pdfs)} PDF, maksimal "
                                         f"{settings.max_zip_entries} per unggahan")

            seen: set[str] = set()
            for info in pdfs:
                fname = os.path.basename(info.filename)
                path = _storage_path()
                try:
                    sha = _extract_pdf(zf, info, _limit("max_upload_mb"), path)
                except ValueError as e:
                    skipped.append({"file": fname, "reason": str(e)})
                    continue
                dup = db.scalar(select(Document).where(Document.file_sha256 == sha))
                if dup or sha in seen:
                    os.remove(path)
                    reason = (f"Sudah terdaftar sebagai dokumen #{dup.id}" if dup
                              else "Duplikat berkas lain di ZIP yang sama")
                    skipped.append({"file": fname, "reason": reason})
                    continue
                seen.add(sha)
                d = Document(name=_title_from_filename(fname), category=category, version=version,
                             year=year, origin=origin, doc_type=doc_type,
                             valid_from=valid_from, valid_until=valid_until,
                             file_path=path, file_sha256=sha, status=DocStatus.PENDING)
                db.add(d)
                db.flush()
                created.append(d)
        db.commit()
    except BaseException:
        db.rollback()
        for d in created:
            if d.file_path and os.path.exists(d.file_path):
                os.remove(d.file_path)
        raise
    finally:
        if os.path.exists(zip_path):
            os.remove(zip_path)

    for d in created:
        bg.add_task(_run_ingest, d.id)
    return {"created": [to_out(db, d) for d in created], "skipped": skipped}


@router.get("/{doc_id}", response_model=DocumentOut)
def get_doc(doc_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return to_out(db, _get(db, doc_id))


@router.get("/{doc_id}/chunks")
def get_chunks(doc_id: int, page: int | None = None, db: Session = Depends(get_db),
               _: User = Depends(require_admin)):
    stmt = select(Chunk).where(Chunk.document_id == doc_id).order_by(Chunk.chunk_index)
    if page:
        stmt = stmt.where(Chunk.page == page)
    return [{"id": c.id, "index": c.chunk_index, "page": c.page, "section": c.section, "text": c.text}
            for c in db.scalars(stmt).all()]


@router.patch("/{doc_id}", response_model=DocumentOut)
def update_doc(doc_id: int, body: DocumentUpdate, db: Session = Depends(get_db),
               _: User = Depends(require_admin)):
    d = _get(db, doc_id)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(d, k, v)
    _validate_dates(d.doc_type, d.valid_from, d.valid_until)
    _validate_skip(d.skip_pages)
    db.commit()
    return to_out(db, d)


@router.post("/{doc_id}/verify", response_model=DocumentOut)
def verify_doc(doc_id: int, body: StatusChange | None = None, db: Session = Depends(get_db),
               admin: User = Depends(require_admin)):
    d = _get(db, doc_id)
    if d.ingest_status.value != "selesai":
        raise HTTPException(409, "Dokumen belum selesai diolah (ingest) — tidak bisa diverifikasi")
    if d.valid_until and d.valid_until < date.today():
        raise HTTPException(409, "Masa berlaku dokumen sudah lewat")
    d.status, d.verified_by = DocStatus.VERIFIED, admin.id
    d.verified_at = datetime.now(timezone.utc)
    d.status_note = body.note if body else None
    revoke_superseded(db, d)
    db.commit()
    return to_out(db, d)


@router.post("/{doc_id}/revoke", response_model=DocumentOut)
def revoke_doc(doc_id: int, body: StatusChange | None = None, db: Session = Depends(get_db),
               _: User = Depends(require_admin)):
    d = _get(db, doc_id)
    d.status, d.status_note = DocStatus.REVOKED, (body.note if body else "Dicabut oleh admin")
    db.commit()
    return to_out(db, d)


@router.post("/{doc_id}/reingest", response_model=DocumentOut)
def reingest(doc_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    d = _get(db, doc_id)
    if not d.file_path:
        raise HTTPException(409, "Dokumen tidak memiliki berkas")
    return to_out(db, ingest_document(db, d))


class OcrPages(BaseModel):
    pages: list[str]


@router.post("/{doc_id}/ocr-text", response_model=DocumentOut)
def ingest_ocr_text(doc_id: int, body: OcrPages, db: Session = Depends(get_db),
                    _: User = Depends(require_admin)):
    """Untuk PDF hasil pindai: modul OCR mengirim teks per halaman (index 0 = halaman 1)."""
    d = _get(db, doc_id)
    if not body.pages:
        raise HTTPException(422, "pages kosong")
    return to_out(db, ingest_document(db, d, pages=body.pages))


@router.delete("/{doc_id}", status_code=204)
def delete_doc(doc_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    d = _get(db, doc_id)
    if d.file_path and os.path.exists(d.file_path):
        os.remove(d.file_path)
    db.delete(d)
    db.commit()


@router.post("/maintenance/expire")
def run_expire(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return {"expired": expire_outdated(db)}
