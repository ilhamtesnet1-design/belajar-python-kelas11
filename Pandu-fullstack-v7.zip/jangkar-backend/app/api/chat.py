from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import QueryLog
from app.ratelimit import chat_limit
from app.rag.pipeline import answer_question
from app.schemas import AskIn, AskOut, FeedbackIn
from app.security import require_chat_access

router = APIRouter(prefix="/api/chat", tags=["percakapan"])


@router.post("/ask", response_model=AskOut, dependencies=[Depends(require_chat_access), Depends(chat_limit)])
def ask(body: AskIn, db: Session = Depends(get_db)):
    """Butuh login bila REQUIRE_STUDENT_LOGIN aktif. Log tetap tidak menyimpan identitas apa pun."""
    r = answer_question(db, body.question.strip())
    log = QueryLog(question=body.question.strip(), answer=r.answer, refused=r.refused,
                   refusal_reason=r.refusal_reason, top_similarity=r.top_similarity,
                   grounding_score=r.grounding_score, citations=r.citations, latency_ms=r.latency_ms)
    db.add(log)
    db.commit()
    return AskOut(log_id=log.id, answer=r.answer, refused=r.refused, refusal_reason=r.refusal_reason,
                  citations=r.citations, latency_ms=r.latency_ms)


@router.post("/{log_id}/feedback", status_code=204, dependencies=[Depends(require_chat_access)])
def feedback(log_id: int, body: FeedbackIn, db: Session = Depends(get_db)):
    log = db.get(QueryLog, log_id)
    if not log:
        raise HTTPException(404, "Tidak ditemukan")
    log.feedback = body.value
    db.commit()
