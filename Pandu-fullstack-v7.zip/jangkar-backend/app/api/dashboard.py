from datetime import date, datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.models import DocStatus, Document, EvalQuestion, EvalRun, IngestStatus, QueryLog, User
from app.security import require_admin

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


def _p95(values):
    if not values:
        return None
    v = sorted(values)
    return v[min(len(v) - 1, int(round(0.95 * (len(v) - 1))))]


@router.get("/summary")
def summary(days: int = 30, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    since = datetime.now(timezone.utc) - timedelta(days=days)
    logs = db.scalars(select(QueryLog).where(QueryLog.created_at >= since)).all()
    total = len(logs)
    refused = sum(1 for l in logs if l.refused)
    lat = [l.latency_ms for l in logs]
    docs = dict(db.execute(select(Document.status, func.count()).group_by(Document.status)).all())
    reasons: dict[str, int] = {}
    for l in logs:
        if l.refusal_reason:
            reasons[l.refusal_reason] = reasons.get(l.refusal_reason, 0) + 1
    cited: dict[str, int] = {}
    for l in logs:
        for c in l.citations or []:
            cited[c["document_name"]] = cited.get(c["document_name"], 0) + 1
    return {
        "period_days": days,
        "questions": total,
        "answered": total - refused,
        "refused": refused,
        "refusal_rate": round(refused / total, 3) if total else 0,
        "latency_p95_ms": _p95(lat),
        "under_5s_rate": round(sum(1 for x in lat if x < 5000) / total, 3) if total else None,
        "feedback_up": sum(1 for l in logs if l.feedback == 1),
        "feedback_down": sum(1 for l in logs if l.feedback == -1),
        "refusal_reasons": reasons,
        "top_documents": sorted(cited.items(), key=lambda x: -x[1])[:5],
        "documents": {s.value: docs.get(s, 0) for s in DocStatus},
        # Terverifikasi tetapi habis masa berlaku dalam 30 hari ke depan.
        "expiring_soon": db.scalar(select(func.count(Document.id)).where(
            Document.status == DocStatus.VERIFIED,
            Document.valid_until.is_not(None),
            Document.valid_until <= date.today() + timedelta(days=30))) or 0,
        "eval_questions": db.scalar(select(func.count(EvalQuestion.id))) or 0,
    }


@router.get("/activity")
def activity(limit: int = 10, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    """Linimasa aktivitas untuk dashboard admin.

    Disusun dari jejak waktu yang sudah ada di registri dan evaluasi (dibuat,
    diverifikasi, dicabut/kedaluwarsa, gagal diolah, evaluasi dijalankan),
    jadi tidak perlu tabel audit terpisah.
    """
    events = []
    for d in db.scalars(select(Document).order_by(Document.updated_at.desc()).limit(limit * 3)).all():
        events.append({"at": d.created_at, "kind": "uploaded", "actor": "admin",
                       "text": f"{d.name} ditambahkan ke registri", "document_id": d.id,
                       "status": DocStatus.PENDING.value})
        if d.verified_at:
            events.append({"at": d.verified_at, "kind": "verified", "actor": "admin",
                           "text": f"{d.name} diverifikasi", "document_id": d.id,
                           "status": DocStatus.VERIFIED.value})
        if d.status in (DocStatus.REVOKED, DocStatus.EXPIRED):
            verb = "dicabut" if d.status == DocStatus.REVOKED else "kedaluwarsa"
            events.append({"at": d.updated_at, "kind": d.status.name.lower(), "actor": "system"
                           if d.status == DocStatus.EXPIRED else "admin",
                           "text": f"{d.name} {verb}", "document_id": d.id, "status": d.status.value})
        if d.ingest_status == IngestStatus.FAILED:
            events.append({"at": d.updated_at, "kind": "ingest_failed", "actor": "engine",
                           "text": f"Pengolahan {d.name} gagal", "document_id": d.id,
                           "status": "Gagal"})
    for r in db.scalars(select(EvalRun).order_by(EvalRun.created_at.desc()).limit(limit)).all():
        events.append({"at": r.created_at, "kind": "eval", "actor": "engine",
                       "text": f"Evaluasi #{r.id} dijalankan ({(r.summary or {}).get('n', 0)} pertanyaan)",
                       "document_id": None, "status": "Selesai"})

    def key(e):
        at = e["at"]
        return at.replace(tzinfo=timezone.utc) if at and at.tzinfo is None else at

    events = [e for e in events if e["at"]]
    events.sort(key=key, reverse=True)
    return events[:limit]


@router.get("/unanswered")
def unanswered(limit: int = 50, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    """Pertanyaan yang ditolak — bahan untuk menambah dokumen / set evaluasi."""
    rows = db.scalars(select(QueryLog).where(QueryLog.refused.is_(True))
                      .order_by(QueryLog.created_at.desc()).limit(limit)).all()
    return [{"id": r.id, "question": r.question, "reason": r.refusal_reason,
             "top_similarity": r.top_similarity, "created_at": r.created_at} for r in rows]


@router.get("/logs")
def logs(limit: int = 100, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rows = db.scalars(select(QueryLog).order_by(QueryLog.created_at.desc()).limit(limit)).all()
    return [{"id": r.id, "question": r.question, "answer": r.answer, "refused": r.refused,
             "citations": r.citations, "latency_ms": r.latency_ms, "feedback": r.feedback,
             "created_at": r.created_at} for r in rows]



@router.get("/system")
def system(_: User = Depends(require_admin)):
    """Konfigurasi aktif (hanya baca) untuk halaman Pengaturan. Nilai diubah lewat .env."""
    s = get_settings()
    return {
        "llm_provider": s.llm_provider,
        "llm_model": s.llm_model if s.llm_provider != "fake" else None,
        "embedding_provider": s.embedding_provider,
        "embedding_model": s.embedding_model if s.embedding_provider != "fake" else None,
        "database": "PostgreSQL" if s.is_postgres else "SQLite",
        "top_k": s.top_k,
        "similarity_threshold": s.similarity_threshold,
        "grounding_threshold": s.grounding_threshold,
        "chunk_size": s.chunk_size,
        "chunk_overlap": s.chunk_overlap,
        "chat_rate_per_minute": s.chat_rate_per_minute,
        "daily_question_limit": s.daily_question_limit,
        "max_upload_mb": s.max_upload_mb,
        "max_zip_mb": s.max_zip_mb,
        "max_zip_entries": s.max_zip_entries,
    }
