"""Riwayat chat per akun: daftar, buka, tambah pesan, ganti judul, hapus."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Conversation, ConversationMessage, User
from app.security import require_user

router = APIRouter(prefix="/api/conversations", tags=["riwayat chat"])

MAX_MESSAGES_PER_CALL = 50


class MessageIn(BaseModel):
    role: str = Field(pattern="^(user|assistant)$")
    content: str = Field(min_length=1, max_length=20000)
    meta: dict | None = None


class ConversationIn(BaseModel):
    title: str | None = Field(None, max_length=200)
    messages: list[MessageIn] = Field(default_factory=list, max_length=MAX_MESSAGES_PER_CALL)


class AppendIn(BaseModel):
    messages: list[MessageIn] = Field(min_length=1, max_length=MAX_MESSAGES_PER_CALL)


class TitleIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)


def _title_from(messages: list[MessageIn]) -> str:
    first = next((m.content for m in messages if m.role == "user"), "").strip()
    first = " ".join(first.split())
    return (first[:60] + "…") if len(first) > 60 else (first or "Percakapan baru")


def _own(db: Session, cid: int, user: User) -> Conversation:
    c = db.get(Conversation, cid)
    if not c or c.owner_id != user.id:
        raise HTTPException(404, "Percakapan tidak ditemukan")
    return c


def _summary(db: Session, c: Conversation) -> dict:
    count = db.scalar(select(func.count(ConversationMessage.id)).where(ConversationMessage.conversation_id == c.id)) or 0
    last = db.scalar(select(ConversationMessage).where(ConversationMessage.conversation_id == c.id)
                     .order_by(ConversationMessage.id.desc()).limit(1))
    preview = " ".join((last.content if last else "").split())
    return {"id": c.id, "title": c.title, "created_at": c.created_at, "updated_at": c.updated_at,
            "message_count": count, "preview": preview[:120]}


def _full(c: Conversation) -> dict:
    return {"id": c.id, "title": c.title, "created_at": c.created_at, "updated_at": c.updated_at,
            "messages": [{"id": m.id, "role": m.role, "content": m.content, "meta": m.meta or {},
                          "created_at": m.created_at} for m in c.messages]}


def _add(c: Conversation, messages: list[MessageIn]):
    for m in messages:
        c.messages.append(ConversationMessage(role=m.role, content=m.content, meta=m.meta))
    c.updated_at = datetime.now(timezone.utc)


@router.get("")
def list_conversations(q: str | None = None, limit: int = 100, db: Session = Depends(get_db),
                       user: User = Depends(require_user)):
    stmt = select(Conversation).where(Conversation.owner_id == user.id)
    if q:
        stmt = stmt.where(Conversation.title.ilike(f"%{q}%"))
    rows = db.scalars(stmt.order_by(Conversation.updated_at.desc()).limit(min(limit, 500))).all()
    return [_summary(db, c) for c in rows]


@router.post("", status_code=201)
def create_conversation(body: ConversationIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    c = Conversation(owner_id=user.id, title=(body.title or "").strip() or _title_from(body.messages))
    _add(c, body.messages)
    db.add(c)
    db.commit()
    return _full(c)


@router.get("/{cid}")
def get_conversation(cid: int, db: Session = Depends(get_db), user: User = Depends(require_user)):
    return _full(_own(db, cid, user))


@router.post("/{cid}/messages")
def append_messages(cid: int, body: AppendIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    c = _own(db, cid, user)
    if c.title == "Percakapan baru":
        c.title = _title_from(body.messages)
    _add(c, body.messages)
    db.commit()
    return _summary(db, c)


@router.patch("/{cid}")
def rename_conversation(cid: int, body: TitleIn, db: Session = Depends(get_db), user: User = Depends(require_user)):
    c = _own(db, cid, user)
    c.title = body.title.strip()
    db.commit()
    return _summary(db, c)


@router.delete("/{cid}", status_code=204)
def delete_conversation(cid: int, db: Session = Depends(get_db), user: User = Depends(require_user)):
    db.delete(_own(db, cid, user))
    db.commit()


@router.delete("", status_code=204)
def delete_all(db: Session = Depends(get_db), user: User = Depends(require_user)):
    ids = db.scalars(select(Conversation.id).where(Conversation.owner_id == user.id)).all()
    if ids:
        db.execute(delete(ConversationMessage).where(ConversationMessage.conversation_id.in_(ids)))
        db.execute(delete(Conversation).where(Conversation.id.in_(ids)))
        db.commit()
