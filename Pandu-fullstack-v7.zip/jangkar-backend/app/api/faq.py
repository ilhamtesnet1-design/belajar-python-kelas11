from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Faq, User
from app.security import require_admin

router = APIRouter(prefix="/api/faq", tags=["faq"])


class FaqIn(BaseModel):
    question: str = Field(min_length=5, max_length=500)
    answer: str = Field(min_length=5)
    category: str = "Umum"
    is_published: bool = True
    sort_order: int = 0


class FaqUpdate(BaseModel):
    question: str | None = Field(None, min_length=5, max_length=500)
    answer: str | None = Field(None, min_length=5)
    category: str | None = None
    is_published: bool | None = None
    sort_order: int | None = None


class FaqOut(FaqIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
    updated_at: datetime


def _ordered():
    return select(Faq).order_by(Faq.sort_order, Faq.id)


@router.get("", response_model=list[FaqOut])
def list_published(db: Session = Depends(get_db)):
    """Publik: hanya FAQ yang ditampilkan."""
    return db.scalars(_ordered().where(Faq.is_published.is_(True))).all()


@router.get("/all", response_model=list[FaqOut])
def list_all(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return db.scalars(_ordered()).all()


@router.post("", response_model=FaqOut, status_code=201)
def create(body: FaqIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    f = Faq(**body.model_dump())
    db.add(f)
    db.commit()
    return f


@router.patch("/{faq_id}", response_model=FaqOut)
def update(faq_id: int, body: FaqUpdate, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    f = db.get(Faq, faq_id)
    if not f:
        raise HTTPException(404, "FAQ tidak ditemukan")
    for k, v in body.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(f, k, v)
    db.commit()
    return f


@router.delete("/{faq_id}", status_code=204)
def delete(faq_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    f = db.get(Faq, faq_id)
    if not f:
        raise HTTPException(404, "FAQ tidak ditemukan")
    db.delete(f)
    db.commit()
