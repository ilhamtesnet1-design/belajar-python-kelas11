import csv
import io

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import EvalQuestion, EvalRun, User
from app.rag.pipeline import RagConfig, answer_question
from app.schemas import EvalQuestionIn, EvalQuestionOut, EvalRunIn
from app.security import require_admin

router = APIRouter(prefix="/api/eval", tags=["evaluasi"])


@router.get("/questions", response_model=list[EvalQuestionOut])
def list_q(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return db.scalars(select(EvalQuestion).order_by(EvalQuestion.id)).all()


@router.post("/questions", response_model=EvalQuestionOut, status_code=201)
def add_q(body: EvalQuestionIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    q = EvalQuestion(**body.model_dump())
    db.add(q)
    db.commit()
    return q


@router.delete("/questions/{qid}", status_code=204)
def del_q(qid: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    q = db.get(EvalQuestion, qid)
    if not q:
        raise HTTPException(404)
    db.delete(q)
    db.commit()


@router.post("/questions/import")
async def import_csv(file: UploadFile = File(...), db: Session = Depends(get_db),
                     _: User = Depends(require_admin)):
    """CSV kolom: question,expected_answer,should_refuse,expected_document_id,expected_page,expected_section,category"""
    text = (await file.read()).decode("utf-8-sig")
    n = 0
    for row in csv.DictReader(io.StringIO(text)):
        if not row.get("question"):
            continue
        db.add(EvalQuestion(
            question=row["question"], expected_answer=row.get("expected_answer") or None,
            should_refuse=str(row.get("should_refuse", "")).strip().lower() in ("1", "true", "ya", "yes"),
            expected_document_id=int(row["expected_document_id"]) if row.get("expected_document_id") else None,
            expected_page=int(row["expected_page"]) if row.get("expected_page") else None,
            expected_section=row.get("expected_section") or None, category=row.get("category") or None))
        n += 1
    db.commit()
    return {"imported": n}


@router.post("/runs")
def run_eval(body: EvalRunIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    """Jalankan set evaluasi. Ubah parameter / matikan gerbang untuk uji ablasi."""
    cfg = RagConfig.default(top_k=body.top_k, similarity_threshold=body.similarity_threshold,
                            grounding_threshold=body.grounding_threshold,
                            use_similarity_gate=body.use_similarity_gate,
                            use_grounding_gate=body.use_grounding_gate)
    qs = db.scalars(select(EvalQuestion)).all()
    if not qs:
        raise HTTPException(409, "Set evaluasi kosong")
    results, refuse_ok, cite_ok, cite_n, lat = [], 0, 0, 0, []
    for q in qs:
        r = answer_question(db, q.question, cfg)
        lat.append(r.latency_ms)
        refusal_correct = r.refused == q.should_refuse
        refuse_ok += refusal_correct
        cite_correct = None
        if not q.should_refuse and not r.refused and q.expected_document_id:
            cite_n += 1
            cite_correct = any(c["document_id"] == q.expected_document_id and
                               (q.expected_page is None or c["page"] == q.expected_page)
                               for c in r.citations)
            cite_ok += cite_correct
        results.append({"question_id": q.id, "question": q.question, "answer": r.answer,
                        "refused": r.refused, "should_refuse": q.should_refuse,
                        "refusal_correct": refusal_correct, "citation_correct": cite_correct,
                        "citations": r.citations, "contexts": r.contexts,
                        "expected_answer": q.expected_answer,
                        "latency_ms": r.latency_ms})
    lat.sort()
    summary = {
        "n": len(qs),
        "refusal_accuracy": round(refuse_ok / len(qs), 3),
        "citation_accuracy": round(cite_ok / cite_n, 3) if cite_n else None,
        "latency_p95_ms": lat[min(len(lat) - 1, int(round(0.95 * (len(lat) - 1))))],
        "note": "Ketepatan jawaban & metrik RAGAS: python -m scripts.ragas_eval <run_id>",
    }
    run = EvalRun(config=cfg.__dict__, summary=summary, results=results)
    db.add(run)
    db.commit()
    return {"run_id": run.id, "config": cfg.__dict__, "summary": summary}


@router.get("/runs")
def list_runs(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    runs = db.scalars(select(EvalRun).order_by(EvalRun.created_at.desc())).all()
    return [{"id": r.id, "config": r.config, "summary": r.summary, "created_at": r.created_at} for r in runs]


@router.get("/runs/{run_id}")
def get_run(run_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    r = db.get(EvalRun, run_id)
    if not r:
        raise HTTPException(404)
    return {"id": r.id, "config": r.config, "summary": r.summary, "results": r.results}
