from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./jangkar.db"
    storage_dir: str = "./storage"

    jwt_secret: str = "dev-secret-change-me-minimal-32-karakter!!"
    jwt_expire_minutes: int = 480
    admin_email: str = "admin@jangkar.local"
    admin_password: str = "admin123"

    # Web (Vite) + aplikasi HP hasil bungkus Capacitor (Android: http(s)://localhost, iOS: capacitor://localhost)
    cors_origins: str = "http://localhost:5173,http://localhost,https://localhost,capacitor://localhost"

    embedding_provider: str = "fake"
    llm_provider: str = "fake"
    openai_base_url: str = "https://api.openai.com/v1"
    openai_api_key: str = ""
    embedding_model: str = "text-embedding-3-small"
    embedding_dim: int = 1536
    llm_model: str = "gpt-4o-mini"

    top_k: int = 5
    similarity_threshold: float = 0.35
    grounding_threshold: float = 0.5
    chunk_size: int = 800
    chunk_overlap: int = 150

    # Akses mahasiswa. Saat ini cukup email + kata sandi (SSO UNP belum tersedia).
    # ALLOWED_EMAIL_DOMAINS kosong = semua email boleh mendaftar; isi mis.
    # "student.unp.ac.id,unp.ac.id" untuk membatasi ke email kampus saja.
    require_student_login: bool = True
    allowed_email_domains: str = ""

    @property
    def email_domains(self) -> list[str]:
        return [d.strip().lower().lstrip("@") for d in self.allowed_email_domains.split(",") if d.strip()]

    # Dokumen pribadi mahasiswa (PDF yang diunggah untuk ditanyakan sendiri)
    user_document_ttl_hours: int = 72     # dihapus otomatis setelah ini
    max_user_documents: int = 5           # dokumen aktif per mahasiswa

    # Batas unggah (MB). GET /api/config/public membagikannya ke frontend, jadi
    # angka di layar admin selalu sama dengan yang ditegakkan di sini.
    max_upload_mb: int = 100      # satu dokumen PDF
    max_zip_mb: int = 200         # arsip ZIP untuk unggah banyak dokumen
    max_zip_entries: int = 50     # jumlah PDF maksimal di dalam satu ZIP
    max_scan_mb: int = 25         # berkas pindaian untuk OCR
    max_avatar_mb: int = 5

    # Pembatasan laju & anggaran (0 = nonaktif)
    chat_rate_per_minute: int = 20
    login_rate_per_15min: int = 10
    daily_question_limit: int = 0
    llm_timeout_seconds: float = 20.0

    refusal_message: str = (
        "Maaf, Pandu tidak menemukan jawaban atas pertanyaan ini di dokumen resmi "
        "yang terverifikasi. Silakan hubungi Bagian Akademik Fakultas Teknik UNP."
    )

    @property
    def is_postgres(self) -> bool:
        return self.database_url.startswith("postgresql")


@lru_cache
def get_settings() -> Settings:
    return Settings()
