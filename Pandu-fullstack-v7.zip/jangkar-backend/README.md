# Pandu — Backend API

Backend aplikasi **Pandu** (Asisten Layanan Akademik Berbasis Dokumen Resmi Kampus).
Peran: Backend & Data Engineer — API, basis data, deployment, registri dokumen.

**Stack:** FastAPI · PostgreSQL + pgvector · SQLAlchemy 2 · Docker · JWT.

## Pemetaan ke Project Charter

| Kebutuhan charter | Implementasi |
|---|---|
| Jawaban menyertakan dokumen, pasal, halaman | `citations[]` → `document_name`, `section` (BAB/Pasal), `page`, `quote` |
| Menolak bila bukti tidak memadai | 2 gerbang di `app/rag/pipeline.py`: kemiripan + penjangkaran → `refused: true` + arahan ke Bagian Akademik |
| Registri: asal, versi, masa berlaku, status keabsahan | tabel `documents` (`origin`, `version`, `valid_from/until`, `status`, `doc_type`, `supersedes_id`) |
| Hanya dokumen terverifikasi jadi dasar jawaban | filter SQL `Terverifikasi` + dalam masa berlaku, di setiap retrieval |
| Aturan (berlaku s.d. dicabut) vs pengumuman (berbatas waktu) | `doc_type = aturan / pengumuman`; pengumuman wajib `valid_until` |
| Pengeluaran otomatis pengumuman kedaluwarsa | job harian 00:05 WIB + saat startup (`services/registry.py`) |
| Versi baru menggantikan versi lama | verifikasi dokumen ber-`supersedes_id` → versi lama otomatis `Dicabut` |
| Log tanpa identitas pengguna | `query_logs` tidak menyimpan user/IP/user-agent |
| Waktu jawab < 5 dtk (95%) | `latency_ms` dicatat; dashboard menampilkan p95 & `under_5s_rate` |
| Set evaluasi 150 pertanyaan + uji ablasi | `/api/eval/*` — impor CSV, jalankan, matikan gerbang/ubah threshold |
| Dashboard ringkas | `/api/dashboard/summary`, `/unanswered`, `/logs` |
| Kunci API aman | hanya di `.env` (di-`.gitignore`) |
| Anggaran API terjaga | batas 20 tanya/menit per pengguna, kuota harian opsional (`DAILY_QUESTION_LIMIT`), batas percobaan login |
| Tidak mengarang saat model error | API model gagal/timeout → sistem **menolak** (`layanan_model_gagal`), bukan error 500 |
| Ketepatan jawaban, sitasi, menolak + RAGAS | `scripts/ragas_eval.py` → angka dibandingkan otomatis dengan target charter |
| Kode diperiksa tiap pull request | GitHub Actions `.github/workflows/backend-ci.yml` (SQLite + PostgreSQL) |

## Menjalankan

### Docker (disarankan)
```bash
cp .env.example .env        # lalu ganti JWT_SECRET & ADMIN_PASSWORD
docker compose up -d --build
docker compose exec api python -m scripts.seed_documents /app/seed   # opsional, lihat bawah
```
Swagger: http://localhost:8000/docs

### Lokal tanpa Docker (dev cepat, SQLite)
```bash
python -m venv .venv && .venv\Scripts\activate      # Windows
pip install -r requirements.txt
# tanpa .env -> otomatis SQLite + provider "fake" (gratis, offline)
uvicorn app.main:app --reload
python -m scripts.seed_documents ..\JANGKAR\public\documents
pytest -q
```
Login default dev: `admin@jangkar.local` / `admin123`.

### Provider model
- `fake` — embedding hashing + jawaban ekstraktif. Untuk dev & test, **bukan** untuk evaluasi.
- `openai` — API kompatibel OpenAI (OpenAI, Groq, OpenRouter, Ollama `http://host:11434/v1`). Isi `OPENAI_BASE_URL`, `OPENAI_API_KEY`, model, dan **`EMBEDDING_DIM` sesuai model** (ganti dim = reset tabel `chunks` + ingest ulang).

## Evaluasi (Milestone 2 & laporan)
1. Isi set evaluasi: impor CSV ke `POST /api/eval/questions/import` (contoh: `scripts/eval_template.csv`, kolom `expected_answer` wajib untuk ketepatan jawaban).
2. Jalankan: `POST /api/eval/runs` (body `{}`), catat `run_id`. Uji ablasi: ulangi dengan `{"use_grounding_gate": false}` dsb.
3. Hitung metrik: `python -m scripts.ragas_eval <run_id>` → ketepatan jawaban + CSV.
   Tambah `--ragas` (setelah `pip install ragas langchain-openai`) untuk faithfulness, answer relevancy, context recall.
4. Angka **hanya sah** bila `LLM_PROVIDER=openai` (provider fake hanya untuk uji alur).

## Migrasi database
- PostgreSQL: skema dikelola **Alembic**; migrasi otomatis jalan saat server start.
- Ubah model → buat migrasi baru: `alembic revision --autogenerate -m "keterangan"` → periksa file di `migrations/versions/` → commit.
- `EMBEDDING_DIM` ditetapkan saat migrasi pertama. Ganti model embedding berdimensi lain = migrasi baru + ingest ulang semua dokumen.
- SQLite (dev cepat/test): tabel dibuat otomatis tanpa Alembic.

## Runbook deployment (VPS)
1. VPS Ubuntu + Docker. `git clone`, `cp .env.example .env`, isi `JWT_SECRET` (acak ≥32 karakter: `python -c "import secrets;print(secrets.token_urlsafe(48))"`), `ADMIN_PASSWORD`, kunci API, `CORS_ORIGINS=https://domain-kalian`.
2. `docker compose up -d --build` → cek `curl localhost:8000/api/health`.
3. Pasang Nginx/Caddy di depan sebagai HTTPS reverse proxy: `/api` → `localhost:8000`, sisanya → hasil `npm run build` frontend. Jangan buka port 5432 ke publik (hapus `ports` pada service `db`).
4. Backup harian: `docker compose exec db pg_dump -U jangkar jangkar | gzip > backup_$(date +%F).sql.gz` (cron) + salin volume `storage` (berkas PDF).
5. Pantau: `docker compose logs -f api`; dashboard admin → `latency_p95_ms`, `under_5s_rate`, pertanyaan ditolak.
6. Kunci API bocor → cabut di penyedia, ganti di `.env`, `docker compose up -d`.

## Endpoint

Publik (mahasiswa, tanpa login):
| Method | Path | Fungsi |
|---|---|---|
| POST | `/api/chat/ask` | `{question}` → `{log_id, answer, refused, refusal_reason, citations[], latency_ms}` |
| POST | `/api/chat/{log_id}/feedback` | `{value: 1 / -1}` |
| GET | `/api/documents/public` | daftar dokumen yang sedang berlaku |
| GET | `/api/documents/{id}/file` | PDF (inline); sitasi memberi `#page=N` |

Admin (header `Authorization: Bearer <token>`):
| Method | Path | Fungsi |
|---|---|---|
| POST | `/api/auth/login` | `{email,password}` → token |
| GET | `/api/documents?status=&category=&q=` | registri |
| POST | `/api/documents` | multipart: `file` (PDF ≤ `MAX_UPLOAD_MB`, bawaan 100MB, di-stream ke disk) + metadata (+ `skip_pages` mis. `"1-2,90-103"` untuk melewati sampul/lampiran) → otomatis di-ingest |
| POST | `/api/documents/batch` | multipart: `file` ZIP (≤ `MAX_ZIP_MB`, bawaan 200MB, maks. `MAX_ZIP_ENTRIES`=50 PDF) + metadata bersama → `{created[], skipped[{file,reason}]}`; nama dokumen dari nama berkas, semua masuk "Menunggu Validasi" |
| GET/PATCH/DELETE | `/api/documents/{id}` | detail / ubah metadata / hapus |
| GET | `/api/documents/{id}/chunks?page=` | lihat hasil potongan (cek kualitas korpus) |
| POST | `/api/documents/{id}/verify` | → `Terverifikasi` (wajib ingest selesai) |
| POST | `/api/documents/{id}/revoke` | → `Dicabut` |
| POST | `/api/documents/{id}/reingest` | olah ulang PDF |
| POST | `/api/documents/{id}/ocr-text` | `{pages:[...]}` teks OCR per halaman (PDF hasil pindai) |
| POST | `/api/documents/maintenance/expire` | jalankan pengeluaran kedaluwarsa manual |
| GET | `/api/dashboard/summary?days=30` · `/unanswered` · `/logs` | dashboard (summary kini juga berisi `expiring_soon`, `eval_questions`) |
| GET | `/api/dashboard/activity?limit=10` | linimasa aktivitas registri & evaluasi |
| GET | `/api/dashboard/system` | konfigurasi aktif (hanya baca) untuk halaman Pengaturan |
| PATCH | `/api/auth/me` | `{name}` ubah nama admin |
| POST | `/api/auth/password` | `{current_password, new_password}` (min. 8 karakter, dibatasi laju) |
| GET | `/api/faq` | **publik** — FAQ yang ditampilkan (diisi 5 FAQ awal saat pertama start) |
| GET · POST · PATCH · DELETE | `/api/faq/all` · `/api/faq` · `/api/faq/{id}` | kelola FAQ (admin). Tabel `faqs` — PostgreSQL: migrasi `0002_faq`; SQLite dibuat otomatis |
| POST | `/api/auth/register` | `{name, email, password}` → akun mahasiswa + token. `ALLOWED_EMAIL_DOMAINS` membatasi domain |
| GET · POST | `/api/my-documents` | PDF pribadi mahasiswa: daftar / unggah (dibaca di latar belakang) |
| GET · DELETE | `/api/my-documents/{id}` · `/file?token=` | status / hapus / buka PDF (hanya pemilik; milik orang lain = 404) |
| POST | `/api/my-documents/{id}/ask` | `{question}` → jawaban hanya dari PDF itu, sitasi `private: true`, **tidak dicatat** ke query_logs |
| GET · POST · DELETE | `/api/conversations` | riwayat chat milik pengguna: daftar (`?q=` cari) / buat / hapus semua |
| GET · PATCH · DELETE | `/api/conversations/{id}` | buka / ganti judul / hapus satu percakapan (milik orang lain = 404) |
| POST | `/api/conversations/{id}/messages` | tambah pesan ke percakapan |
| DELETE | `/api/auth/me` | `{password}` hapus akun sendiri beserta riwayat & PDF pribadi (bukan admin) |
| GET | `/api/config/public` | **publik** — batas unggah; frontend membacanya saat start supaya angka di layar = angka di server |
| GET/POST/DELETE | `/api/eval/questions` · POST `/api/eval/questions/import` (CSV) | set evaluasi |
| POST/GET | `/api/eval/runs` · `/api/eval/runs/{id}` | jalankan & lihat hasil evaluasi/ablasi |

Status dokumen (sama dengan badge frontend): `Menunggu Validasi`, `Terverifikasi`, `Kedaluwarsa`, `Dicabut`.

## Pembagian kerja dengan tim
- **Ilham (pipeline RAG & evaluasi):** cukup ubah `app/rag/` — `providers.py` (model, prompt, juri penjangkaran), `pipeline.py` (gerbang, top-k). Kontrak `answer_question()` dipertahankan agar API tidak berubah. Metrik RAGAS dihitung dari `results` hasil `/api/eval/runs`.
- **Hanna (frontend & OCR):** semua halaman admin & mahasiswa utama sudah memakai endpoint di atas (FAQ dan halaman legacy masih statis). Bentuk `citations[]` sudah mengikuti `CitationCard` (`documentName→document_name`, `section`, `page`, `quote`, `status`). Hasil OCR dikirim ke `/ocr-text`.

## Catatan temuan
- `Pelaksanaan TA Mahasiswa UNP.pdf` **tidak punya lapisan teks** (hasil pindai) → status ingest `gagal`. Perlu OCR dulu, lalu kirim ke `/api/documents/{id}/ocr-text`.
- `Buku Panduan PKL.pdf`: 103 halaman, terdeteksi BAB/Pasal. Beberapa halaman lampiran (iklan/kontak perusahaan) ikut terindeks — pertimbangkan membuang halaman lampiran sebelum diverifikasi.
- `scripts/seed_documents.py` memverifikasi otomatis **hanya untuk dev**. Verifikasi resmi = bagian akademik.
- Sudah diuji di PostgreSQL 16 + pgvector (12 tes lulus di SQLite & PostgreSQL). Provider `openai` diuji dengan simulasi respons API; uji dengan kunci API asli tetap perlu dilakukan.
- Pembatas laju bersifat in-memory → jalankan 1 worker. Bila diskalakan ke banyak worker/server, pindahkan ke Redis.


## Akses mahasiswa & PDF pribadi
- `REQUIRE_STUDENT_LOGIN=true` (bawaan): `/api/chat/ask` butuh login. Pendaftaran pakai email apa pun sampai izin SSO UNP keluar;
  isi `ALLOWED_EMAIL_DOMAINS=student.unp.ac.id` untuk membatasi ke email kampus.
- Login hanya *diperiksa*, identitas tidak diteruskan ke handler chat — `query_logs` tetap tanpa user_id.
- PDF pribadi disimpan di tabel terpisah (`user_documents`, `user_chunks`), tidak pernah dicari untuk pertanyaan umum,
  dan dihapus otomatis setelah `USER_DOCUMENT_TTL_HOURS` (bawaan 72 jam). Maks. `MAX_USER_DOCUMENTS` aktif per mahasiswa.
- Permintaan ringkasan ("ringkas dokumen ini") memakai potongan yang tersebar di seluruh dokumen.

## Kualitas jawaban — penting
Mode `fake` hanya memotong satu kalimat dari dokumen; jawaban yang mengikuti permintaan pengguna butuh
`LLM_PROVIDER=openai` dan `EMBEDDING_PROVIDER=openai` (OpenAI, atau Ollama lokal). Lihat `.env.example`.
Setelah mengganti provider embedding: `python -m scripts.reingest_all`.

## Data awal
`seed/documents/` berisi 6 PDF; `jangkar.db` sudah terisi (embedding mode fake, dim 1536).
Untuk PostgreSQL/database baru: `python -m scripts.seed_documents`.
