"""Hitung metrik mutu jawaban dari satu eval run.

Pakai:
    python -m scripts.ragas_eval <run_id>            # ketepatan jawaban + ekspor CSV
    python -m scripts.ragas_eval <run_id> --ragas    # + metrik RAGAS (butuh: pip install ragas langchain-openai)

Target charter: ketepatan jawaban >= 0.85, sitasi >= 0.90, menolak >= 0.90,
RAGAS faithfulness & answer_relevancy >= 0.85, context_recall >= 0.80.
Hasil ditulis ke summary eval run (tampil di GET /api/eval/runs/{id}) dan ke eval_run_<id>.csv.
"""
import csv
import json
import sys

from app.config import get_settings
from app.db import SessionLocal
from app.models import EvalRun
from app.rag.providers import OpenAICompatLLM
from app.rag.text import tokenize

TARGETS = {"answer_accuracy": 0.85, "citation_accuracy": 0.90, "refusal_accuracy": 0.90,
           "faithfulness": 0.85, "answer_relevancy": 0.85, "context_recall": 0.80}

JUDGE_PROMPT = """Kamu penilai jawaban layanan akademik.
PERTANYAAN: {q}
JAWABAN ACUAN (kunci): {ref}
JAWABAN SISTEM: {ans}
Apakah JAWABAN SISTEM benar dan sejalan dengan JAWABAN ACUAN (boleh beda kata, tidak boleh beda fakta/angka)?
Balas JSON saja: {{"correct": true/false, "reason": "singkat"}}"""


def judge_correct(q: str, ref: str, ans: str) -> bool:
    s = get_settings()
    if s.llm_provider == "openai":
        raw = OpenAICompatLLM(s)._chat([{"role": "user", "content": JUDGE_PROMPT.format(q=q, ref=ref, ans=ans)}],
                                       max_tokens=80)
        try:
            return bool(json.loads(raw[raw.find("{"): raw.rfind("}") + 1])["correct"])
        except Exception:
            return False
    # mode offline: kemiripan kata kunci (hanya untuk uji alur, BUKAN angka resmi)
    r, a = set(tokenize(ref)), set(tokenize(ans))
    return bool(r) and len(r & a) / len(r) >= 0.6


def answer_accuracy(results: list[dict]) -> tuple[float | None, list]:
    flags = []
    for r in results:
        if r["should_refuse"] or not r.get("expected_answer"):
            flags.append(None)
            continue
        flags.append(False if r["refused"] else judge_correct(r["question"], r["expected_answer"], r["answer"]))
    scored = [f for f in flags if f is not None]
    return (round(sum(scored) / len(scored), 3) if scored else None), flags


def ragas_scores(results: list[dict]) -> dict:
    """RAGAS >= 0.2. Hanya pertanyaan yang dijawab & punya kunci jawaban."""
    from langchain_openai import ChatOpenAI, OpenAIEmbeddings
    from ragas import EvaluationDataset, evaluate
    from ragas.embeddings import LangchainEmbeddingsWrapper
    from ragas.llms import LangchainLLMWrapper
    from ragas.metrics import Faithfulness, LLMContextRecall, ResponseRelevancy

    s = get_settings()
    rows = [{"user_input": r["question"], "response": r["answer"],
             "retrieved_contexts": r.get("contexts") or [], "reference": r["expected_answer"]}
            for r in results if not r["refused"] and r.get("expected_answer") and r.get("contexts")]
    if not rows:
        return {}
    llm = LangchainLLMWrapper(ChatOpenAI(model=s.llm_model, base_url=s.openai_base_url,
                                         api_key=s.openai_api_key, temperature=0))
    emb = LangchainEmbeddingsWrapper(OpenAIEmbeddings(model=s.embedding_model, base_url=s.openai_base_url,
                                                      api_key=s.openai_api_key))
    res = evaluate(EvaluationDataset.from_list(rows),
                   metrics=[Faithfulness(), ResponseRelevancy(), LLMContextRecall()], llm=llm, embeddings=emb)
    df = res.to_pandas()
    rename = {"faithfulness": "faithfulness", "answer_relevancy": "answer_relevancy",
              "context_recall": "context_recall"}
    return {k: round(float(df[col].mean()), 3) for col, k in rename.items() if col in df}


def main(run_id: int, use_ragas: bool):
    with SessionLocal() as db:
        run = db.get(EvalRun, run_id)
        if not run:
            sys.exit(f"Eval run #{run_id} tidak ditemukan")
        results = run.results
        acc, flags = answer_accuracy(results)
        summary = dict(run.summary, answer_accuracy=acc)
        if use_ragas:
            summary.update(ragas_scores(results))
        summary["meets_target"] = {k: (summary.get(k) is not None and summary[k] >= t)
                                   for k, t in TARGETS.items() if summary.get(k) is not None}
        run.summary = summary
        db.commit()

    out = f"eval_run_{run_id}.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["question_id", "question", "should_refuse", "refused", "refusal_correct",
                    "citation_correct", "answer_correct", "answer", "expected_answer", "latency_ms", "sources"])
        for r, ok in zip(results, flags):
            w.writerow([r["question_id"], r["question"], r["should_refuse"], r["refused"], r["refusal_correct"],
                        r["citation_correct"], ok, r["answer"], r.get("expected_answer"), r["latency_ms"],
                        "; ".join(f'{c["document_name"]} {c.get("section") or ""} hlm.{c["page"]}'
                                  for c in r["citations"])])
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print("CSV:", out)
    if get_settings().llm_provider != "openai":
        print("PERINGATAN: LLM_PROVIDER=fake — angka ini hanya uji alur, bukan hasil evaluasi resmi.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(int(sys.argv[1]), "--ragas" in sys.argv)
