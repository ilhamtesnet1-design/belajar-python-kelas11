"""Olah ulang SEMUA dokumen (resmi + PDF pribadi mahasiswa) dengan provider embedding saat ini.

Wajib dijalankan setelah mengganti EMBEDDING_PROVIDER / EMBEDDING_MODEL / EMBEDDING_DIM:
vektor dari provider lama tidak bisa dibandingkan dengan vektor provider baru.

Pakai:  python -m scripts.reingest_all
Status verifikasi dokumen TIDAK diubah; hanya potongan teks & vektornya yang dibuat ulang.
"""
from sqlalchemy import select

from app.config import get_settings
from app.db import SessionLocal
from app.main import init_db
from app.models import Document, UserDocument
from app.rag.ingest import ingest_document, ingest_user_document


def main():
    init_db()
    s = get_settings()
    print(f"Provider embedding: {s.embedding_provider} ({s.embedding_model if s.embedding_provider != 'fake' else 'offline'})")
    with SessionLocal() as db:
        for d in db.scalars(select(Document).where(Document.file_path.is_not(None))).all():
            d = ingest_document(db, d)
            print(f"  [resmi]   {d.name}: {d.ingest_status.value}, {len(d.chunks)} potongan"
                  + (f" — {d.ingest_error}" if d.ingest_error else ""))
        for d in db.scalars(select(UserDocument)).all():
            d = ingest_user_document(db, d)
            print(f"  [pribadi] #{d.id}: {d.ingest_status.value}, {len(d.chunks)} potongan")


if __name__ == "__main__":
    main()
