"""Daftarkan + olah PDF awal ke registri.

Pakai:  python -m scripts.seed_documents                 (folder bawaan: seed/documents)
        python -m scripts.seed_documents <folder_pdf> [--no-verify]

Status setelah seed:
- dokumen yang masih berlaku dan teksnya terbaca -> Terverifikasi (catatan: WAJIB ditinjau ulang bagian akademik)
- pengumuman yang tanggal berakhirnya sudah lewat -> Kedaluwarsa (tidak dipakai menjawab)
- PDF hasil pindai tanpa teks -> tetap Menunggu Validasi, ingest "gagal" (lengkapi lewat halaman OCR admin)
CATATAN: verifikasi otomatis HANYA untuk dev. Di produksi, verifikasi dilakukan bagian akademik."""
import hashlib
import os
import shutil
import sys
import uuid
from datetime import date, datetime, timezone

from sqlalchemy import select

from app.config import get_settings
from app.db import SessionLocal
from app.main import init_db
from app.models import DocStatus, DocType, Document
from app.rag.ingest import ingest_document

UNP = "Universitas Negeri Padang"

META = {
    "Buku Panduan PKL.pdf": dict(
        name="Buku Panduan PKL", category="PKL / Magang", version="V.1.2", year=2026,
        origin="Fakultas Teknik UNP", doc_type=DocType.REGULATION,
        skip_pages="1-8"),  # sampul, kata pengantar, tim penyusun, daftar isi/gambar/tabel/lampiran
    "Pelaksanaan TA Mahasiswa UNP.pdf": dict(
        name="Pelaksanaan TA Mahasiswa UNP", category="Tugas Akhir", version="V.2.0", year=2025,
        origin=UNP, doc_type=DocType.REGULATION),
    "Kalender Akademik 2026-2027.pdf": dict(
        name="Kalender Akademik UNP 2026/2027", category="Kalender Akademik", version="V.1", year=2026,
        doc_number="286/UN35/DT.02.01/2026", origin="Rektor " + UNP,
        description="Keputusan Rektor tentang Kalender Akademik Tahun Akademik 2026/2027 "
                    "(Semester Ganjil Juli–Desember 2026, Semester Genap Januari–Juni 2027).",
        doc_type=DocType.ANNOUNCEMENT, valid_from=date(2026, 4, 2), valid_until=date(2027, 6, 30)),
    "Juknis Pendaftaran Yudisium.pdf": dict(
        name="Juknis Pendaftaran Yudisium (Portal Akademik)", category="Yudisium & Wisuda", version="V.1",
        year=2026, origin="Direktorat Akademik " + UNP,
        description="Langkah pendaftaran yudisium di portal akademik: clearing nilai, ACC PA, ACC Prodi, nomor ijazah.",
        doc_type=DocType.REGULATION),
    "Jadwal Tata Cara Daftar Yudisium.pdf": dict(
        name="Jadwal & Tata Cara Pendaftaran Yudisium Periode Januari–Juni 2026 (Wisuda 143)",
        category="Yudisium & Wisuda", version="Periode 143", year=2026, origin=UNP,
        description="Persyaratan umum yudisium dan skor bahasa Inggris. Halaman 2 (tabel jadwal) berupa gambar.",
        doc_type=DocType.ANNOUNCEMENT, valid_from=date(2026, 1, 1), valid_until=date(2026, 6, 30)),
    "Jadwal Tata Cara Daftar Wisuda 143.pdf": dict(
        name="Jadwal & Tata Cara Pendaftaran Wisuda Periode 143", category="Yudisium & Wisuda",
        version="Periode 143", year=2026, origin="Wakil Rektor Bidang Akademik " + UNP,
        description="Persyaratan, jadwal, dan predikat kelulusan Wisuda periode 143 (29–30 Juni 2026).",
        doc_type=DocType.ANNOUNCEMENT, valid_from=date(2026, 4, 7), valid_until=date(2026, 6, 30)),
}

DEFAULT_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "documents")


def main(folder: str, verify: bool = True):
    init_db()
    storage = get_settings().storage_dir
    os.makedirs(storage, exist_ok=True)
    today = date.today()
    with SessionLocal() as db:
        for fn in sorted(os.listdir(folder)):
            if not fn.lower().endswith(".pdf"):
                continue
            src = os.path.join(folder, fn)
            sha = hashlib.sha256(open(src, "rb").read()).hexdigest()
            if db.scalar(select(Document).where(Document.file_sha256 == sha)):
                print("lewati (sudah ada):", fn)
                continue
            dst = os.path.join(storage, f"{uuid.uuid4().hex}.pdf")
            shutil.copy(src, dst)
            meta = META.get(fn, dict(name=fn[:-4], origin=UNP))
            d = Document(**meta, file_path=dst, file_sha256=sha)
            db.add(d)
            db.commit()
            d = ingest_document(db, d)
            if d.valid_until and d.valid_until < today:
                d.status = DocStatus.EXPIRED
                d.status_note = f"Masa berlaku berakhir {d.valid_until:%d-%m-%Y}. Unggah jadwal periode berikutnya."
            elif verify and d.ingest_status.value == "selesai":
                d.status, d.verified_at = DocStatus.VERIFIED, datetime.now(timezone.utc)
                d.status_note = "Seed dev — WAJIB diverifikasi ulang oleh bagian akademik"
            db.commit()
            print(f"{fn}: {d.ingest_status.value}, {d.pages} hlm, {len(d.chunks)} potongan, {d.status.value}"
                  + (f" — {d.ingest_error}" if d.ingest_error else ""))


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    main(args[0] if args else DEFAULT_FOLDER, verify="--no-verify" not in sys.argv)
