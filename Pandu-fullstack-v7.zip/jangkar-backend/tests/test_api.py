from datetime import date, timedelta

from tests.conftest import make_pdf

TA_PDF = make_pdf([
    "BAB I\nKETENTUAN UMUM\nPasal 1\nPedoman ini mengatur pelaksanaan tugas akhir mahasiswa.",
    "BAB II\nPERSYARATAN\nPasal 5\nMahasiswa dapat mengambil tugas akhir apabila telah lulus\n"
    "paling sedikit 120 SKS dengan IPK minimal 2.00 dan tidak memiliki nilai E.\n"
    "Pasal 6\nPendaftaran tugas akhir dilakukan melalui portal akademik resmi.",
])


def upload(client, admin, pdf, **form):
    data = {"name": "Pedoman TA", "category": "Tugas Akhir", "version": "V.2", **form}
    return client.post("/api/documents", headers=admin, data=data,
                       files={"file": ("ta.pdf", pdf, "application/pdf")})


def test_auth(client, admin):
    assert client.post("/api/auth/login", json={"email": "admin@test.id", "password": "x"}).status_code == 401
    assert client.get("/api/documents").status_code == 401
    assert client.get("/api/auth/me", headers=admin).json()["role"] == "admin"


def test_full_flow(client, admin):
    r = upload(client, admin, TA_PDF)
    assert r.status_code == 201, r.text
    doc = client.get(f"/api/documents/{r.json()['id']}", headers=admin).json()
    assert doc["ingest_status"] == "selesai" and doc["pages"] == 2 and doc["chunk_count"] > 0
    assert doc["status"] == "Menunggu Validasi"
    tok = admin["Authorization"].split()[1]
    assert client.get(f"/api/documents/{doc['id']}/admin-file?token={tok}").status_code == 200
    assert client.get(f"/api/documents/{doc['id']}/admin-file?token=salah").status_code == 401

    chunks = client.get(f"/api/documents/{doc['id']}/chunks", headers=admin).json()
    assert any(c["section"] == "Pasal 5" and c["page"] == 2 for c in chunks), chunks

    q = {"question": "Berapa SKS minimal untuk mengambil tugas akhir?"}
    # belum terverifikasi -> wajib menolak
    a = client.post("/api/chat/ask", json=q).json()
    assert a["refused"]

    assert client.post(f"/api/documents/{doc['id']}/verify", headers=admin).json()["status"] == "Terverifikasi"
    a = client.post("/api/chat/ask", json=q).json()
    assert not a["refused"], a
    assert "120 SKS" in a["answer"]
    c = a["citations"][0]
    assert c["document_name"] == "Pedoman TA" and c["page"] == 2 and c["section"] == "Pasal 5"

    # di luar dokumen -> tolak
    a = client.post("/api/chat/ask", json={"question": "Kapan jadwal wisuda periode Desember?"}).json()
    assert a["refused"]

    # publik hanya melihat dokumen yang berlaku
    assert [d["name"] for d in client.get("/api/documents/public").json()] == ["Pedoman TA"]
    assert client.post(f"/api/chat/{a['log_id']}/feedback", json={"value": -1}).status_code == 204

    s = client.get("/api/dashboard/summary", headers=admin).json()
    assert s["questions"] == 3 and s["refused"] == 2

    # revoke -> tidak lagi dipakai
    client.post(f"/api/documents/{doc['id']}/revoke", headers=admin)
    assert client.post("/api/chat/ask", json=q).json()["refused"]


def test_duplicate_and_validation(client, admin):
    pdf = make_pdf(["Pasal 1\nPengumuman jadwal KRS semester ganjil dibuka tanggal 1 Agustus."])
    r = upload(client, admin, pdf, name="Pengumuman KRS", doc_type="pengumuman")
    assert r.status_code == 422  # pengumuman wajib valid_until
    r = upload(client, admin, pdf, name="Pengumuman KRS", doc_type="pengumuman",
               valid_until=str(date.today() + timedelta(days=3)))
    assert r.status_code == 201
    assert upload(client, admin, pdf, name="dup").status_code == 409
    assert client.post("/api/documents", headers=admin, data={"name": "x"},
                       files={"file": ("a.pdf", b"bukan pdf", "application/pdf")}).status_code == 415


def test_auto_expire(client, admin):
    from app.db import SessionLocal
    from app.models import Document
    from app.services.registry import expire_outdated
    pdf = make_pdf(["Pasal 1\nPengumuman batas pembayaran UKT adalah tanggal 20 Januari."])
    r = upload(client, admin, pdf, name="Pengumuman UKT", doc_type="pengumuman",
               valid_until=str(date.today() + timedelta(days=1)))
    did = r.json()["id"]
    client.post(f"/api/documents/{did}/verify", headers=admin)
    with SessionLocal() as db:
        assert expire_outdated(db, today=date.today() + timedelta(days=5)) >= 1
        assert db.get(Document, did).status.value == "Kedaluwarsa"


def test_supersede(client, admin):
    v1 = upload(client, admin, make_pdf(["Pasal 1\nCuti akademik paling lama dua semester."]),
                name="Pedoman Cuti", version="V.1").json()
    client.post(f"/api/documents/{v1['id']}/verify", headers=admin)
    v2 = upload(client, admin, make_pdf(["Pasal 1\nCuti akademik paling lama empat semester."]),
                name="Pedoman Cuti", version="V.2", supersedes_id=str(v1["id"])).json()
    client.post(f"/api/documents/{v2['id']}/verify", headers=admin)
    assert client.get(f"/api/documents/{v1['id']}", headers=admin).json()["status"] == "Dicabut"


def test_eval_run(client, admin):
    client.post("/api/eval/questions", headers=admin,
                json={"question": "Berapa lama cuti akademik paling lama?", "should_refuse": False})
    client.post("/api/eval/questions", headers=admin,
                json={"question": "Siapa rektor UNP saat ini?", "should_refuse": True})
    r = client.post("/api/eval/runs", headers=admin, json={}).json()
    assert r["summary"]["n"] == 2 and r["summary"]["refusal_accuracy"] == 1.0
    ab = client.post("/api/eval/runs", headers=admin, json={"use_grounding_gate": False}).json()
    assert ab["config"]["use_grounding_gate"] is False


def test_ocr_text_ingest(client, admin):
    from reportlab.pdfgen import canvas
    import io
    buf = io.BytesIO(); c = canvas.Canvas(buf); c.rect(10, 10, 50, 50); c.showPage(); c.save()
    r = upload(client, admin, buf.getvalue(), name="Scan Yudisium").json()
    r = client.get(f"/api/documents/{r['id']}", headers=admin).json()
    assert r["ingest_status"] == "gagal"
    r = client.post(f"/api/documents/{r['id']}/ocr-text", headers=admin,
                    json={"pages": ["Pasal 3\nYudisium dilaksanakan setiap akhir bulan oleh fakultas."]}).json()
    assert r["ingest_status"] == "selesai" and r["chunk_count"] == 1


def test_rate_limit(client, monkeypatch):
    from app import ratelimit
    from app.config import get_settings
    ratelimit.reset()
    monkeypatch.setattr(get_settings(), "chat_rate_per_minute", 2)
    codes = [client.post("/api/chat/ask", json={"question": "apa itu yudisium?"}).status_code for _ in range(3)]
    assert codes == [200, 200, 429]
    ratelimit.reset()


def test_login_rate_limit(client, monkeypatch):
    from app import ratelimit
    from app.config import get_settings
    ratelimit.reset()
    monkeypatch.setattr(get_settings(), "login_rate_per_15min", 3)
    codes = [client.post("/api/auth/login", json={"email": "x@y.z", "password": "a"}).status_code for _ in range(4)]
    assert codes == [401, 401, 401, 429]
    ratelimit.reset()


def test_skip_pages(client, admin):
    pdf = make_pdf(["Sampul dokumen beasiswa", "Pasal 1\nBeasiswa diberikan kepada mahasiswa berprestasi akademik.",
                    "Lampiran iklan perusahaan percetakan dan kontak telepon."])
    r = upload(client, admin, pdf, name="Pedoman Beasiswa", skip_pages="1,3").json()
    chunks = client.get(f"/api/documents/{r['id']}/chunks", headers=admin).json()
    assert {c["page"] for c in chunks} == {2}
    assert upload(client, admin, make_pdf(["x" * 50]), name="y", skip_pages="abc").status_code == 422


def test_openai_provider_and_failure(client, admin, monkeypatch):
    """Simulasi API kompatibel OpenAI (tanpa jaringan): jawaban normal & API mati -> menolak, bukan error 500."""
    import httpx
    from app.config import get_settings
    from app import ratelimit
    ratelimit.reset()
    s = get_settings()
    monkeypatch.setattr(s, "llm_provider", "openai")

    def fake_post(url, json=None, **kw):
        content = json["messages"][-1]["content"]
        if "Balas JSON saja" in content:
            out = '{"score": 0.9}'
        else:
            out = "Cuti akademik paling lama empat semester [1]."
        return httpx.Response(200, json={"choices": [{"message": {"content": out}}]},
                              request=httpx.Request("POST", url))
    monkeypatch.setattr(httpx, "post", fake_post)
    a = client.post("/api/chat/ask", json={"question": "Berapa lama cuti akademik paling lama?"}).json()
    assert not a["refused"] and a["citations"][0]["document_name"] == "Pedoman Cuti"

    def broken(*a, **k):
        raise httpx.ConnectTimeout("timeout")
    monkeypatch.setattr(httpx, "post", broken)
    a = client.post("/api/chat/ask", json={"question": "Berapa lama cuti akademik paling lama?"}).json()
    assert a["refused"] and a["refusal_reason"] == "layanan_model_gagal"


def test_ragas_script_offline(client, admin, tmp_path, monkeypatch):
    from scripts import ragas_eval
    client.post("/api/eval/questions", headers=admin,
                json={"question": "Berapa lama cuti akademik paling lama?",
                      "expected_answer": "Cuti akademik paling lama empat semester"})
    run = client.post("/api/eval/runs", headers=admin, json={}).json()
    monkeypatch.chdir(tmp_path)
    ragas_eval.main(run["run_id"], use_ragas=False)
    s = client.get(f"/api/eval/runs/{run['run_id']}", headers=admin).json()["summary"]
    assert s["answer_accuracy"] is not None
    assert (tmp_path / f"eval_run_{run['run_id']}.csv").exists()


# ---------- Batas unggah, ZIP batch, endpoint pendukung frontend ----------

def _zip(files: dict[str, bytes]) -> bytes:
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def test_public_config(client):
    r = client.get("/api/config/public").json()
    assert r["uploads"]["document"]["max_bytes"] == 100 * 1024 * 1024
    assert r["uploads"]["archive"]["max_entries"] == 50


def test_upload_limit(client, admin, monkeypatch):
    from app.config import get_settings
    monkeypatch.setattr(get_settings(), "max_upload_mb", 1)
    big = b"%PDF-1.4\n" + b"0" * (1024 * 1024 + 10)
    r = client.post("/api/documents", headers=admin, data={"name": "Besar"},
                    files={"file": ("besar.pdf", big, "application/pdf")})
    assert r.status_code == 413 and "1 MB" in r.json()["detail"]


def test_batch_zip(client, admin):
    a = make_pdf(["Pasal 1\nKuliah kerja nyata dilaksanakan pada semester tujuh."])
    b = make_pdf(["Pasal 2\nSeminar proposal dihadiri minimal dua dosen penguji."])
    payload = _zip({
        "Pedoman_KKN-2026.pdf": a,
        "folder/Panduan Seminar.pdf": b,
        "folder/salinan.pdf": b,              # duplikat isi -> dilewati
        "catatan.txt": b"bukan pdf",          # bukan PDF -> dilewati
        "palsu.pdf": b"tidak berisi pdf",     # ekstensi PDF, isi bukan -> dilewati
        "__MACOSX/._Pedoman.pdf": b"x",       # sampah macOS -> diabaikan
    })
    r = client.post("/api/documents/batch", headers=admin, data={"category": "Pedoman"},
                    files={"file": ("paket.zip", payload, "application/zip")})
    assert r.status_code == 201, r.text
    body = r.json()
    names = sorted(d["name"] for d in body["created"])
    assert names == ["Panduan Seminar", "Pedoman KKN 2026"]
    assert all(d["status"] == "Menunggu Validasi" and d["category"] == "Pedoman" for d in body["created"])
    reasons = {s["file"]: s["reason"] for s in body["skipped"]}
    assert "catatan.txt" in reasons and "palsu.pdf" in reasons and "salinan.pdf" in reasons
    assert not any("MACOSX" in f for f in reasons)

    # ZIP yang sama diunggah ulang: semua sudah terdaftar
    again = client.post("/api/documents/batch", headers=admin,
                        files={"file": ("paket.zip", payload, "application/zip")})
    assert again.status_code == 201 and again.json()["created"] == []


def test_batch_rejects_bad_zip(client, admin):
    r = client.post("/api/documents/batch", headers=admin,
                    files={"file": ("x.zip", b"bukan zip sama sekali", "application/zip")})
    assert r.status_code == 415
    r = client.post("/api/documents/batch", headers=admin,
                    files={"file": ("x.zip", _zip({"a.txt": b"halo"}), "application/zip")})
    assert r.status_code == 422


def test_dashboard_activity_and_summary(client, admin):
    s = client.get("/api/dashboard/summary", headers=admin).json()
    assert "expiring_soon" in s and "eval_questions" in s
    events = client.get("/api/dashboard/activity", headers=admin).json()
    assert events and {"at", "kind", "text", "status"} <= set(events[0])
    assert client.get("/api/dashboard/activity").status_code == 401


def test_profile_password_and_system(client):
    from app import ratelimit
    ratelimit.reset()
    tok = client.post("/api/auth/login", json={"email": "admin@test.id", "password": "rahasia"}).json()["access_token"]
    h = {"Authorization": f"Bearer {tok}"}
    assert client.patch("/api/auth/me", headers=h, json={"name": "Bu Rina"}).json()["name"] == "Bu Rina"
    assert client.post("/api/auth/password", headers=h,
                       json={"current_password": "salah", "new_password": "baru-12345"}).status_code == 400
    assert client.post("/api/auth/password", headers=h,
                       json={"current_password": "rahasia", "new_password": "pendek"}).status_code == 422
    assert client.post("/api/auth/password", headers=h,
                       json={"current_password": "rahasia", "new_password": "baru-12345"}).status_code == 204
    assert client.post("/api/auth/login", json={"email": "admin@test.id", "password": "baru-12345"}).status_code == 200
    # kembalikan kata sandi awal (7 karakter, di bawah minimum endpoint) langsung lewat DB
    from app.db import SessionLocal
    from app.models import User
    from app.security import hash_password
    with SessionLocal() as db:
        u = db.query(User).filter_by(email="admin@test.id").one()
        u.password_hash = hash_password("rahasia")
        db.commit()
    sysinfo = client.get("/api/dashboard/system", headers=h).json()
    assert sysinfo["llm_provider"] == "fake" and sysinfo["max_upload_mb"] == 100


def test_faq_crud(client, admin):
    public = client.get("/api/faq").json()
    assert len(public) >= 1                                   # seeded on startup
    r = client.post("/api/faq", headers=admin, json={"question": "Kapan admin membalas?", "answer": "Pada hari kerja.",
                                                     "category": "Layanan", "is_published": False})
    assert r.status_code == 201
    fid = r.json()["id"]
    assert fid not in [f["id"] for f in client.get("/api/faq").json()]      # hidden from students
    assert fid in [f["id"] for f in client.get("/api/faq/all", headers=admin).json()]
    assert client.patch(f"/api/faq/{fid}", headers=admin, json={"is_published": True}).json()["is_published"]
    assert fid in [f["id"] for f in client.get("/api/faq").json()]
    assert client.post("/api/faq", json={"question": "tanpa login", "answer": "harus ditolak"}).status_code == 401
    assert client.delete(f"/api/faq/{fid}", headers=admin).status_code == 204
    assert client.patch(f"/api/faq/{fid}", headers=admin, json={"category": "x"}).status_code == 404



def test_student_login_required(client, monkeypatch):
    from app import ratelimit
    from app.config import get_settings
    ratelimit.reset()
    s = get_settings()
    monkeypatch.setattr(s, "require_student_login", True)
    q = {"question": "Berapa SKS minimal untuk tugas akhir?"}

    assert client.get("/api/config/public").json()["auth"]["student_login_required"] is True
    assert client.post("/api/chat/ask", json=q).status_code == 401           # belum masuk

    r = client.post("/api/auth/register", json={"name": "Sari", "email": "Sari@Mail.com", "password": "rahasia-123"})
    assert r.status_code == 201 and r.json()["user"]["role"] == "mahasiswa"
    assert r.json()["user"]["email"] == "sari@mail.com"
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    assert client.post("/api/auth/register", json={"name": "Sari", "email": "sari@mail.com",
                                                   "password": "rahasia-123"}).status_code == 409
    assert client.post("/api/auth/login", json={"email": "sari@mail.com", "password": "rahasia-123"}).status_code == 200

    a = client.post("/api/chat/ask", json=q, headers=h)
    assert a.status_code == 200
    assert client.post(f"/api/chat/{a.json()['log_id']}/feedback", json={"value": 1}, headers=h).status_code == 204

    # pertanyaan tidak dikaitkan ke akun
    from app.db import SessionLocal
    from app.models import QueryLog
    with SessionLocal() as db:
        assert not hasattr(QueryLog, "user_id")
        assert db.get(QueryLog, a.json()["log_id"]).question == q["question"]

    # mahasiswa tidak bisa memakai endpoint admin
    assert client.get("/api/documents", headers=h).status_code == 403
    assert client.get("/api/auth/me", headers=h).json()["role"] == "mahasiswa"

    # pembatasan domain email kampus
    monkeypatch.setattr(s, "allowed_email_domains", "student.unp.ac.id")
    assert client.post("/api/auth/register", json={"name": "Budi", "email": "budi@gmail.com",
                                                   "password": "rahasia-123"}).status_code == 403
    assert client.post("/api/auth/register", json={"name": "Budi", "email": "budi@student.unp.ac.id",
                                                   "password": "rahasia-123"}).status_code == 201
    assert client.post("/api/auth/register", json={"name": "X", "email": "bukan-email",
                                                   "password": "rahasia-123"}).status_code == 422
    ratelimit.reset()


def _student(client, email):
    r = client.post("/api/auth/register", json={"name": "Mhs", "email": email, "password": "rahasia-123"})
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_private_documents(client):
    from app import ratelimit
    from app.db import SessionLocal
    from app.models import QueryLog
    ratelimit.reset()
    a, b = _student(client, "ani@test.id"), _student(client, "budi@test.id")
    pdf = make_pdf(["Catatan Pribadi Ani\nJadwal konsultasi skripsi dengan dosen pembimbing setiap hari Kamis pukul 10 pagi."])

    assert client.post("/api/my-documents", files={"file": ("x.pdf", pdf, "application/pdf")}).status_code == 401
    r = client.post("/api/my-documents", headers=a, files={"file": ("catatan_ani.pdf", pdf, "application/pdf")})
    assert r.status_code == 201, r.text
    did = r.json()["id"]
    doc = client.get(f"/api/my-documents/{did}", headers=a).json()
    assert doc["ingest_status"] == "selesai" and doc["chunk_count"] >= 1 and doc["name"] == "catatan ani"

    # pemilik bisa bertanya; jawaban & sitasi berasal dari dokumennya
    with SessionLocal() as db:
        logs_before = db.query(QueryLog).count()
    ans = client.post(f"/api/my-documents/{did}/ask", headers=a,
                      json={"question": "Kapan jadwal konsultasi skripsi dengan dosen pembimbing?"}).json()
    assert not ans["refused"], ans
    assert "Kamis" in ans["answer"] and ans["log_id"] is None
    assert ans["citations"][0]["private"] is True and ans["citations"][0]["status"] == "Dokumen Anda"
    with SessionLocal() as db:
        assert db.query(QueryLog).count() == logs_before      # tidak dicatat

    # orang lain: tidak bisa melihat, bertanya, mengunduh, atau menghapus (404, bukan 403)
    assert client.get(f"/api/my-documents/{did}", headers=b).status_code == 404
    assert client.post(f"/api/my-documents/{did}/ask", headers=b, json={"question": "jadwal konsultasi?"}).status_code == 404
    assert client.get(f"/api/my-documents/{did}/file", headers=b).status_code == 404
    assert client.delete(f"/api/my-documents/{did}", headers=b).status_code == 404
    assert client.get(f"/api/my-documents/{did}", headers=a).status_code == 200   # masih ada
    assert client.get("/api/my-documents", headers=b).json() == []

    # isi dokumen pribadi tidak pernah dipakai untuk chat umum
    pub = client.post("/api/chat/ask", headers=a, json={"question": "Kapan jadwal konsultasi skripsi hari Kamis pukul 10?"}).json()
    assert all(not c.get("private") for c in pub["citations"])
    assert "Kamis pukul 10" not in pub["answer"]

    tok = a["Authorization"].split()[1]
    assert client.get(f"/api/my-documents/{did}/file?token={tok}").status_code == 200

    # unggah ulang berkas yang sama -> dokumen yang sama
    again = client.post("/api/my-documents", headers=a, files={"file": ("lagi.pdf", pdf, "application/pdf")}).json()
    assert again["id"] == did

    assert client.delete(f"/api/my-documents/{did}", headers=a).status_code == 204
    assert client.get(f"/api/my-documents/{did}", headers=a).status_code == 404
    ratelimit.reset()


def test_private_documents_expire_and_limit(client, monkeypatch):
    from datetime import datetime, timedelta, timezone
    from app import ratelimit
    from app.config import get_settings
    from app.db import SessionLocal
    from app.models import UserDocument
    ratelimit.reset()
    h = _student(client, "citra@test.id")
    monkeypatch.setattr(get_settings(), "max_user_documents", 1)
    one = client.post("/api/my-documents", headers=h,
                      files={"file": ("a.pdf", make_pdf(["Dokumen pertama berisi catatan kuliah statistika."]), "application/pdf")})
    assert one.status_code == 201
    two = client.post("/api/my-documents", headers=h,
                      files={"file": ("b.pdf", make_pdf(["Dokumen kedua berisi catatan kuliah kalkulus."]), "application/pdf")})
    assert two.status_code == 409 and "Maksimal 1" in two.json()["detail"]
    with SessionLocal() as db:
        d = db.get(UserDocument, one.json()["id"])
        d.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.commit()
    assert client.get("/api/my-documents", headers=h).json() == []           # kedaluwarsa -> terhapus
    with SessionLocal() as db:
        assert db.get(UserDocument, one.json()["id"]) is None
    ratelimit.reset()


def test_private_document_summary_uses_private_prompt(client, monkeypatch):
    """Permintaan ringkasan atas PDF pribadi: konteks diambil dari seluruh dokumen, prompt khusus dokumen pribadi."""
    import httpx
    from app import ratelimit
    from app.config import get_settings
    ratelimit.reset()
    h = _student(client, "dewi@test.id")
    pdf = make_pdf(["Bab 1\nLatar belakang penelitian tentang irigasi sawah di Sumatera Barat.",
                    "Bab 2\nMetode survei terhadap 40 petani di Kabupaten Agam.",
                    "Bab 3\nHasil: debit air turun 20 persen pada musim kemarau."])
    did = client.post("/api/my-documents", headers=h, files={"file": ("skripsi.pdf", pdf, "application/pdf")}).json()["id"]

    seen = {}
    def fake_post(url, json=None, **kw):
        seen["system"] = json["messages"][0]["content"]
        seen["user"] = json["messages"][-1]["content"]
        return httpx.Response(200, json={"choices": [{"message": {"content": "Penelitian irigasi di Agam [1] [3]."}}]},
                              request=httpx.Request("POST", url))
    monkeypatch.setattr(get_settings(), "llm_provider", "openai")
    monkeypatch.setattr(httpx, "post", fake_post)
    a = client.post(f"/api/my-documents/{did}/ask", headers=h, json={"question": "Tolong ringkas dokumen ini"}).json()
    assert not a["refused"], a
    assert "DIUNGGAH SENDIRI" in seen["system"]
    assert "Agam" in seen["user"] and "kemarau" in seen["user"]       # konteks mencakup awal sampai akhir
    assert all(c["private"] for c in a["citations"])
    ratelimit.reset()


def test_conversation_history(client):
    from app import ratelimit
    ratelimit.reset()
    a, b = _student(client, "eka@test.id"), _student(client, "fajar@test.id")
    assert client.get("/api/conversations").status_code == 401
    msgs = [{"role": "user", "content": "Kapan KRS semester genap dibuka?"},
            {"role": "assistant", "content": "Pengisian KRS semester genap 6–23 Januari 2027 [1].",
             "meta": {"citations": [{"documentName": "Kalender Akademik", "page": 2}], "logId": 3}}]
    c = client.post("/api/conversations", headers=a, json={"messages": msgs}).json()
    assert c["title"] == "Kapan KRS semester genap dibuka?" and len(c["messages"]) == 2
    assert c["messages"][1]["meta"]["citations"][0]["page"] == 2

    s = client.post(f"/api/conversations/{c['id']}/messages", headers=a,
                    json={"messages": [{"role": "user", "content": "Kalau semester ganjil?"}]}).json()
    assert s["message_count"] == 3
    listed = client.get("/api/conversations", headers=a).json()
    assert listed[0]["id"] == c["id"] and listed[0]["preview"] == "Kalau semester ganjil?"
    assert client.get("/api/conversations?q=KRS", headers=a).json()[0]["id"] == c["id"]

    # orang lain tidak bisa melihat, menambah, mengganti judul, atau menghapus
    assert client.get("/api/conversations", headers=b).json() == []
    assert client.get(f"/api/conversations/{c['id']}", headers=b).status_code == 404
    assert client.post(f"/api/conversations/{c['id']}/messages", headers=b,
                       json={"messages": [{"role": "user", "content": "x"}]}).status_code == 404
    assert client.delete(f"/api/conversations/{c['id']}", headers=b).status_code == 404

    assert client.patch(f"/api/conversations/{c['id']}", headers=a, json={"title": "Jadwal KRS"}).json()["title"] == "Jadwal KRS"
    assert client.post("/api/conversations", headers=a, json={"messages": [{"role": "robot", "content": "x"}]}).status_code == 422

    client.post("/api/conversations", headers=a, json={"messages": msgs})
    assert len(client.get("/api/conversations", headers=a).json()) == 2
    assert client.delete("/api/conversations", headers=a).status_code == 204
    assert client.get("/api/conversations", headers=a).json() == []
    ratelimit.reset()


def test_delete_own_account(client):
    from app import ratelimit
    from app.db import SessionLocal
    from app.models import Conversation, User, UserDocument
    ratelimit.reset()
    h = _student(client, "gita@test.id")
    client.post("/api/conversations", headers=h, json={"messages": [{"role": "user", "content": "halo"}]})
    client.post("/api/my-documents", headers=h, files={"file": ("c.pdf", make_pdf(["Catatan pribadi Gita tentang jadwal sidang."]), "application/pdf")})
    assert client.request("DELETE", "/api/auth/me", headers=h, json={"password": "salah"}).status_code == 400
    assert client.request("DELETE", "/api/auth/me", headers=h, json={"password": "rahasia-123"}).status_code == 204
    with SessionLocal() as db:
        assert db.query(User).filter_by(email="gita@test.id").count() == 0
        assert db.query(Conversation).count() == db.query(Conversation).join(User, User.id == Conversation.owner_id).count()
        assert db.query(UserDocument).count() == db.query(UserDocument).join(User, User.id == UserDocument.owner_id).count()
    assert client.post("/api/auth/login", json={"email": "gita@test.id", "password": "rahasia-123"}).status_code == 401
    ratelimit.reset()
