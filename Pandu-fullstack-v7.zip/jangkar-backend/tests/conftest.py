import io
import os
import sys
import tempfile

import pytest

TMP = tempfile.mkdtemp()
os.environ.update(DATABASE_URL=os.environ.get("TEST_DATABASE_URL", f"sqlite:///{TMP}/test.db"), STORAGE_DIR=f"{TMP}/storage",
                  ADMIN_EMAIL="admin@test.id", ADMIN_PASSWORD="rahasia",
                  EMBEDDING_PROVIDER="fake", LLM_PROVIDER="fake", EMBEDDING_DIM="256",
                  SIMILARITY_THRESHOLD="0.15", GROUNDING_THRESHOLD="0.5",
                  # tes lama menguji chat tanpa login; alur wajib-login diuji di test_student_login_required
                  REQUIRE_STUDENT_LOGIN="false")
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402


def make_pdf(pages: list[str]) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    for text in pages:
        y = 800
        for line in text.split("\n"):
            c.drawString(50, y, line)
            y -= 16
        c.showPage()
    c.save()
    return buf.getvalue()


@pytest.fixture(scope="session")
def client():
    from sqlalchemy import text
    from app.db import Base, engine
    if engine.dialect.name == "postgresql":      # mulai dari DB bersih
        with engine.begin() as c:
            c.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        Base.metadata.drop_all(engine)
        with engine.begin() as c:
            c.execute(text("DROP TABLE IF EXISTS alembic_version"))
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def admin(client):
    r = client.post("/api/auth/login", json={"email": "admin@test.id", "password": "rahasia"})
    return {"Authorization": f"Bearer {r.json()['access_token']}"}
